#!/usr/bin/perl
use strict;

# adapted on Apr 25, 2012 for V3 model testing on US data

my ($site,$modelType,$confFile,$beginYear,$endYear,$donterase, $runSatModel, $runSatRank, $runSatDirect, $genXtra) = @ARGV;

sub checkExists
{
   my $file = shift;
   return -e $file;
}

if(!$site) { die "Need a sitename"; }
if(!$modelType) { die "Need a modelType"; }
if(!$confFile) { die "Need an confFile"; }
if(!$beginYear) { die "Need a begin year"; }
if(!$endYear) { die "Need an end year"; }
if(!$runSatModel && !$runSatRank && !$runSatDirect) { die "Nothing to do"; }

#my $confFile = "conf.testing/$site.conf";
my $codeDir = '/home/jim/satmod/source/satModel/v3';
$codeDir = '/home/jim/.netbeans/remote/sunspot.asrc.cestm.albany.edu/jim-schlemmers-macbook-pro.local-MacOSX-x86_64/Users/jimschlemmer/satmod/source/satModel/v3';
my $satGrid = "$codeDir/satGrid/satGrid"; 
my $satGrid_v3_4 = "/home/jim/satmod/v3/v3CI/v3.04/v3CI/satGrid"; 
my $satRank = "$codeDir/satRank/satRank"; 
my $satDirect = "$codeDir/satDirect/satDirect";
my $gridDump = "/home/jim/satmod/vers3/gridDump";
my $confFileFuzzy = $confFile;
$confFileFuzzy =~ s/normalSnow/fuzzySnow/g;

checkExists($satGrid) || die "no file named $satGrid";
checkExists($satRank) || die "no file named $satRank";
#checkExists($satDirect) || die "no file named $satDirect";
checkExists($confFile) || die "no file named $confFile";
#checkExists($confFileFuzzy) || die "no file named $confFileFuzzy";
checkExists($satGrid) || die "no file named $satGrid";

if($modelType ne 'regular') {
	$satGrid = $satGrid_v3_4;
}

my $args = join " ",@ARGV;
printf STDERR "Running [$0 %s] at [%s]\n", $args, scalar gmtime;
printf STDERR "site: $site\nmodelType: $modelType\nyears: $beginYear - $endYear\n";
printf STDERR "conf file: $confFile\n";
printf STDERR "conf file (fuzzy): $confFileFuzzy\n";
printf STDERR "clean up files and db's: %s\n", $donterase ? "no" : "yes";
printf STDERR "runSatModel: %s\n", $runSatModel ? "yes [$satGrid]" : "no";
printf STDERR "runSatRank: %s\n", $runSatRank ? "yes [$satRank]" : "no";
printf STDERR "runSatDirect: %s\n", $runSatDirect ? "yes [$satDirect]" : "no";
printf STDERR "generate extra data values: %s\n", $genXtra ? "yes" : "no";

#exit 1;

# modelType to be one of visOnly, irOnly, visIrBlend
#my $satGrid = "/home/jim/satmod/v3/v3CI/bin/satGrid.$modelType";
#-e $satGrid or die "Couldn't find binary $satGrid: assuming modelTypes of visOnly, irOnly, visIrBlend";

#my $confFile = "./conf.testing/usRank/$site.conf";
#my $confFile = "/home/jim/satmod/v3/conf/$site.conf";

# run v3 model
# first zap any old run data - same drill as above
sub zapDataDirectoryConf {
  my ($confFile,$varName) = @_;
  my $gridfilePath = `getConfVariable.pl $confFile $varName`;
  print STDERR  "\tremoving grid files in $gridfilePath\n";
  `/bin/rm -rf $gridfilePath`; mkdir($gridfilePath);
}

sub zapFileConf {
  my ($confFile,$varName) = @_;
  my $matches = `getConfVariable.pl $confFile $varName`;
  my @lines = split /\n/, $matches;
  foreach my $file (@lines) {
  	print STDERR  "\tremoving file $file\n";
	`/bin/rm -rf $file`;
  }
}

sub zapControlFilesConf {
  my ($confFile) = shift;
  my $matches = `getConfVariable.pl $confFile controlPoint`;
  my @lines = split /\n/, $matches;
  foreach my $line (@lines) {
#  controlPoint = rockyMountainHigh,52.55,-117.05 => rockyMountainHigh.modelInternals.csv
#  controlPoint = canada-west-v3-edmonton,53.55,-114.15
	my($filename,$lat,$lon) = split /,/, $line;
	$filename .= ".modelInternals.csv";
  	print STDERR  "\tremoving control point file $filename\n";
	`/bin/rm -rf $filename`;
  }
}

if(!$donterase) {
  print STDERR  "cleaning up for $site model run\n";
  zapDataDirectoryConf($confFile, 'unCorrectedGridfilePath');
  zapDataDirectoryConf($confFile, 'rankMonthlyGridfilePath');
  zapDataDirectoryConf($confFile, 'primaryCorrGridfilePath');
  zapDataDirectoryConf($confFile, 'directGridfilePath');
  print STDERR  "\tremoving albedo history in /home/jim/satmod/albedoHistory/$site\n";
  zapDataDirectoryConf($confFile, 'albedoHistoryPath');
  zapControlFilesConf($confFile);
  print STDERR  "\tzapping mysql entries from conf file $confFile\n";
  `/home/jim/bin/zapMysqlTableEntriesFromConf.pl $confFile`;
}


#my $irNormFlag = "-I";
my $irNormFlag = " ";

my $comm;
my $beginYearSatGrid = $beginYear - 1;
my $beginMonthDaySatGrid = '110100';
# if we're not starting from scratch don't go back 2 months to prime albedo list
#if($donterase) {
#   $beginMonthDaySatGrid = '010100';
#   $beginYearSatGrid = $beginYear;
#}
my $beginMonthDay = '010100';
my $endMonthDay = '123123';
#my $endMonthDay = '033123';

if($runSatModel) {
   my $xtraFlag = $genXtra ? "-x" : " ";
   #$comm = sprintf "$satGrid -x -c $confFile -v -a %s110100,%s123123 >& $site.$beginYear.$endYear.satGrid.out", $prevYear, $endYear;
   # -I => don't do regional IR normalization
   $comm = sprintf "$satGrid -c $confFile -v -R $irNormFlag $xtraFlag -a %s%s,%s%s >& $site.$beginYear.$endYear.satGrid.out", $beginYearSatGrid, $beginMonthDaySatGrid, $endYear, $endMonthDay;
   printf STDERR "\n===\nrunning v3 model for $site at [%s]\n$comm\n===\n", scalar gmtime;
   `$comm`;
}

if($runSatRank) {
      $comm = sprintf "$satRank -c $confFileFuzzy -v -a %s%s,%s%s >& $site.$beginYear.$endYear.satRank.out", $beginYear, $beginMonthDay, $endYear, $endMonthDay;
      printf STDERR "\n===\nrunning ranking for $site at [%s]\n$comm\n===\n", scalar gmtime;
      `$comm`;
}

if($runSatDirect) {
      $comm = sprintf "$satDirect -c $confFileFuzzy -v -a %s%s,%s%s >& $site.$beginYear.$endYear.satDirect.out", $beginYear,$beginMonthDay, $endYear, $endMonthDay;
      printf STDERR "\n===\nrunning direct model for $site at [%s]\n$comm\n===\n", scalar gmtime;
      `$comm`;
}

printf STDERR "\n===\nfinished processing for $site at [%s]\n===\n", scalar gmtime;

