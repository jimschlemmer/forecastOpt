#!/usr/bin/perl

($dateRange,$runSatGrid,$runSatRank,$zapData) = @ARGV;

$srcDir = '/home/jim/.netbeans/remote/sunspot.asrc.cestm.albany.edu/jim-schlemmers-macbook-pro.local-MacOSX-x86_64/Users/jimschlemmer/satmod/source/satModel/v3';
$satGrid = "$srcDir/satGrid/satGrid";
$satRank = "$srcDir/satRank/satRank";

$Rarg = $zapData ? "-R" : " ";

$Help = "$0 dateRange doSatGrid doSatRank";

$dateRangeArg = $dateRange ? "-a $dateRange" : " ";

(-e $satGrid) || die "No such file: $satGrid\n";
(-e $satRank) || die "No such file: $satRank\n";

my $dateTime = `date +'%Y%m%d_%T'`;
chomp($dateTime);

$eastConf = "/home/jim/mom/satModel/v3/conf/us-east-historical.conf";
$westConf = "/home/jim/mom/satModel/v3/conf/us-west-historical.conf";

$eastLogSatGrid = "./logs/satGrid.us-east.$dateTime.out";
$westLogSatGrid = "./logs/satGrid.us-west.$dateTime.out";
$eastLogSatRank = "./logs/satRank.us-east.$dateTime.out";
$westLogSatRank = "./logs/satRank.us-west.$dateTime.out";

$runEast = 0;
$runWest = 1;

if($runSatGrid) {
    if($runEast) {
	$comm = "$satGrid -c $eastConf $Rarg -v $dateRangeArg >& $eastLogSatGrid";
	print STDERR "Running $comm\n";
	`$comm`;
    }
    if($runWest) {
	$comm = "$satGrid -c $westConf -v $dateRangeArg >& $westLogSatGrid";
	print STDERR "Running $comm\n";
	`$comm`;
    }
}
if($runSatRank) {
    if($runEast) {
	$comm = "$satRank -w -c $eastConf $dateRangeArg -v >& $eastLogSatRank";
	print STDERR "Running $comm\n";
	`$comm`;
    }
    if($runWest) {
	$comm = "$satRank -w -c $westConf $dateRangeArg -v >& $westLogSatRank";
	print STDERR "Running $comm\n";
	`$comm`;
    }
}

print STDERR "$0 run successfully\n";
