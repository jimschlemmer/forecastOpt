#ifndef radiation_h
#define radiation_h

#include "sunae.h"

using namespace std;

double extraterr(int doy);
double GHI_CL (ae_pack *aep);
double GHI_CL (ae_pack aep);
double DNI_CL (ae_pack *aep);
double DNI_CL (ae_pack aep);


#endif /* radiation_h */

