/* movement.c */


#include <time.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "types.h"
#include "movement.h"

using namespace std;

TPoint **GenerateMovement(float **firstFrame, float **secondFrame, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, bool **uniqueMovement)
{
extern  TPoint** Movement0;
TPoint pFirst, pSecond, DPoint, bestMSE;
int i,j,totalPoints;
double bestMSEValue, **MSE;
bool ifMSE;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
int maxMoveX=0, maxMoveY=0;

//Movement0= new TPoint *[600];
for(i=0;i<600;i++){
 //Movement0[i]=new TPoint[600];
 for(j=0;j<600;j++){
        Movement0[i][j].x=Movement0[i][j].y=0;
 }
}

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

MSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MSE[i]=new double[2*DYCheckArea+1];
   

 //specify the initial point on the first frame
   for(pSecond.x=DXSample+DXCheckArea;pSecond.x<countCol-(DXSample+DXCheckArea);pSecond.x++){
   for(pSecond.y=DYSample+DYCheckArea;pSecond.y<countRow-(DYSample+DYCheckArea);pSecond.y++){
   
        //specify the possible related point on the second frame
	//#pragma parallel
	//#pragma shared(MSE,firstFrame,secondFrame)
	//#pragma shared (pSecond,DXCheckArea,DYCheckArea,DXSample,DYSample)
	//#pragma local(pFirst,DPoint)
	//#pragma pfor
        for(pFirst.x=pSecond.x-DXCheckArea;pFirst.x<=pSecond.x+DXCheckArea;pFirst.x++)
        for(pFirst.y=pSecond.y-DYCheckArea;pFirst.y<=pSecond.y+DYCheckArea;pFirst.y++){
             MSE[pFirst.x-pSecond.x+DXCheckArea][pFirst.y-pSecond.y+DYCheckArea]=0;
             //specify the comparison area
             for(DPoint.x=-DXSample;DPoint.x<=DXSample;DPoint.x++)
             for(DPoint.y=-DYSample;DPoint.y<=DYSample;DPoint.y++){
                 //calculate the mean square error along the area for all related points
                 MSE[pFirst.x-pSecond.x+DXCheckArea][pFirst.y-pSecond.y+DYCheckArea]+=pow(firstFrame[pFirst.x+DPoint.x][pFirst.y+DPoint.y]-secondFrame[pSecond.x+DPoint.x][pSecond.y+DPoint.y],2);
             }
        }

        //chooce a best related point if there is and calculate the movement vector for it
        bestMSE.x=countCol;
        bestMSE.y=countRow;
        ifMSE=true;
        bestMSEValue=bestMSE.x*bestMSE.y;
        for(i=0;i<2*DXCheckArea+1;i++)
        for(j=0;j<2*DYCheckArea+1;j++){
             if (MSE[i][j]<bestMSEValue) {
                bestMSEValue=MSE[i][j];
                ifMSE=true;
                bestMSE.x=i;
                bestMSE.y=j;
             }
        //     else if(MSE[i][j]==bestMSEValue){
                ifMSE=false;
        //     }
        }
      //  if (ifMSE){
           Movement0[pSecond.x][pSecond.y].x=-bestMSE.x+DXCheckArea;
           if (abs(Movement0[pSecond.x][pSecond.y].x)>abs(maxMoveX)) maxMoveX=Movement0[pSecond.x][pSecond.y].x;
           Movement0[pSecond.x][pSecond.y].y=-bestMSE.y+DYCheckArea;
           if (abs(Movement0[pSecond.x][pSecond.y].y)>abs(maxMoveY)) maxMoveY=Movement0[pSecond.x][pSecond.y].y;
           uniqueMovement[pSecond.x][pSecond.y]=true;
       // }
       // else{
       //    uniqueMovement[pSecond.x][pSecond.y]=false;
       // }
   }
   }

for(i=0;i<2*DXCheckArea+1;i++) delete[] MSE[i];
delete[] MSE;

return Movement0;

//for(i=0;i<600;i++) {
//    delete[] Movement0[i];
//}
//delete[] Movement0;

}
                                                                                                                                                                                                                                                                                                                                                                                         
