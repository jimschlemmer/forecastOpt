#include <cstdlib>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <string>
#include <cstring>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>
#include <dbi/dbi.h>
#include <omp.h>

#include "types.h"
#include "timeUtils.h"
#include "gridded.h"
#include "ioUtils.h"


#define MAXPATH 256

using namespace std;

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "pointIR.out <File>" << endl;
cout << "File - csv file;" << endl;
cout << "Example:" << endl;
cout << "tempNoise.out File.csv " << endl;
}

int main(int argc, char *argv[]){

time_t times;
struct tm *tm;
char timeStr[256];
int year,month,day,hour,minute,sec=0;
string DateTime,timeName,subS;
char cwd[MAXPATH];
float GHI, DNI, Energy, ClearSkyGHI, ClearSkyDNI, ClearSkyEnergy;
float Di; 

TData_prep fixA;
vector <TData_prep> fixVprev;
int i,j;

getcwd(cwd,MAXPATH);
string FileName,outDirName=cwd; outDirName=outDirName + "/";

if (argc>=2){
FileName=argv[1];
}
else{
help();
exit(1);
}

string InFileName1=outDirName; InFileName1=InFileName1+FileName;
string OutFileName1=outDirName; OutFileName1=OutFileName1+"fix_"+FileName;
ifstream inFile1(InFileName1.c_str());
ofstream outFile1(OutFileName1.c_str());

//reading the input file
int linenum=1, trnum=1, totalTr=0;
char linebuf[100000],datetime[20],date[11],time[9];
char * pch;
//fgets(linebuf, sizeof linebuf, inFile1);
inFile1.getline(linebuf,100000);
//outFile1 << linebuf << ",";
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
    //outFile1 << pch << ",";
    pch = strtok (NULL, ",");
		trnum++;
  }
totalTr=trnum;
trnum=1;

outFile1 << "time, Cl, Gl" << endl;

for (linenum = 2;inFile1.getline(linebuf,100000)!= NULL; linenum++){
//outFile1 << linebuf << ",";
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
	 	if(trnum==1) DateTime=pch;
		if(trnum==3) GHI=atof(pch);
		if(trnum==4) DNI=atof(pch);
	 	if(trnum==5) Energy=atof(pch);
	 	if(trnum==8) ClearSkyGHI=atof(pch);
		if(trnum==9) ClearSkyDNI=atof(pch);	
	 	if(trnum==10) ClearSkyEnergy=atof(pch);	
    pch = strtok (NULL, ",");
		trnum++;
  }
trnum=1;
subS=DateTime.substr (0,4); year=atoi(subS.c_str());
subS=DateTime.substr (4,2); month=atoi(subS.c_str());
subS=DateTime.substr (6,2); day=atoi(subS.c_str());
subS=DateTime.substr (8,2); hour=atoi(subS.c_str());
subS=DateTime.substr (10,2); minute=atoi(subS.c_str());

cout << datetime << " y=" << year << " m=" << month << " d=" << day << " h=" << hour << " m=" << minute << " s=" << sec << endl;

times = timeGm(year, month, day, hour, minute, sec);	
tm = gmtime(&times);	
strftime(timeStr, 256, "%Y-%m-%d %H:%M:%S", tm);
timeName=timeStr;

fixA.time=times;
fixA.year=year; fixA.month=month; fixA.day=day; fixA.hour=hour; fixA.min=minute; fixA.sec=sec; 
fixA.glAv=GHI; fixA.bAv=DNI; fixA.eAv=Energy; fixA.glCl=ClearSkyGHI; fixA.bCl=ClearSkyDNI; fixA.eCl=ClearSkyEnergy; 

if (GHI==-999) {fixVprev.push_back(fixA); continue;}

if (fixVprev.size()>1){
	 fixVprev.push_back(fixA);
		    for(i=1;i<fixVprev.size()-1;i++){
				   Di=(float)i/fixVprev.size();
					 if (fixVprev[0].glCl>0 && fixVprev[fixVprev.size()-1].glCl>0){ 
			          fixVprev[i].glAv=fixVprev[i].glCl*((1-Di)*(fixVprev[0].glAv/fixVprev[0].glCl)+Di*(fixVprev[fixVprev.size()-1].glAv/fixVprev[fixVprev.size()-1].glCl));
					 }
					 else if(fixVprev[0].glCl>0 && fixVprev[fixVprev.size()-1].glCl<=0){
						 		fixVprev[i].glAv=fixVprev[i].glCl*((1-Di)*(fixVprev[0].glAv/fixVprev[0].glCl));
					 }
					 else if(fixVprev[0].glCl<=0 && fixVprev[fixVprev.size()-1].glCl>0){
						 		fixVprev[i].glAv=fixVprev[i].glCl*(Di*(fixVprev[fixVprev.size()-1].glAv/fixVprev[fixVprev.size()-1].glCl));
					 }
					 else fixVprev[i].glAv=0;
				}
			  for(i=0;i<fixVprev.size()-1;i++){
					 tm = gmtime(&(fixVprev[i].time));	
					 strftime(timeStr, 256, "%Y-%m-%d %H:%M:%S", tm);
					 timeName=timeStr;
					 outFile1 << timeName << "," << fixVprev[i].glCl << "," << fixVprev[i].glAv << endl;
				} 
}
else if (fixVprev.size()==1) {
					 tm = gmtime(&(fixVprev[0].time));	
					 strftime(timeStr, 256, "%Y-%m-%d %H:%M:%S", tm);
					 timeName=timeStr;
					 outFile1 << timeName << "," << fixVprev[0].glCl << "," << fixVprev[0].glAv << endl;
}

fixVprev.clear();
fixVprev.push_back(fixA);

}

 outFile1.flush();
 outFile1.close();
fixVprev.clear();

}

