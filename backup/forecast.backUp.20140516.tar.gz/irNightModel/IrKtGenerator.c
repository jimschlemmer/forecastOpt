#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <sys/stat.h>
#include <string>
#include <cstring>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>
#include <dbi/dbi.h>
#include <omp.h>

#include "types.h"
#include "timeUtils.h"
#include "gridded.h"
#include "ioUtils.h"
#include "radiation.h"
#include "sunae.h"

#define MAXPATH 256
#define IrAdjust(x) (x > 176) ? (418 - x) : (330 - (x/2))

using namespace std;

float roundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float RoundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}

double ir4Model(double X1,double X2,double X3,double X4){
static double B1 = -18.1384129165531;
static double H1 = -1.34219621436455E-04;
static double IR4 = 0.164787629096172;
static double IR44 = -3.58351246811821E-04;
static double T1 = -0.129048779423508;
static double T2 = -9.5780777551147E-04;
static double Z1 = 0.234112246225631;
static double TIR4 = 5.49145762807361E-04;
double Kt;
/*
Kt = 1 - ( (IR4*X3+IR44*X3*X3+B1+T1*X2+T2*X2*X2+TIR4*X2*X3)*(1-Z1*X1)*(1+H1*X4) )
X1 = Cos (zenith angle)
X2 = Ground temperature (C)
X3 = IR4 channel_temperature_value
X4 = Site Elevation (m)
*/
Kt = 1 - ( (IR4*X3+IR44*X3*X3+B1+T1*X2+T2*X2*X2+TIR4*X2*X3)*(1-Z1*X1)*(1+H1*X4) );
if(Kt<0) Kt=0; if(Kt>1) Kt=1;
return Kt;
}

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "fiveHourPrediction.out <Location> <configFile> (output)" << endl;
cout << "where:" << endl;
cout << "Location - us-east, us-west, etc; It should be in the same way how it is shown in the database." << endl;
cout << "configFile - configuration file for us-east, us-west, etc." << endl;
cout << "output - the output folder path (optional). It has \"/predictions/\" value by default." << endl;
cout << "Example:" << endl;
cout << "fiveHourPrediction.out us-east us-east-hourly-cloudmotion.conf /predictions/" << endl;
}

int main(int argc, char *argv[]){

float lattitude=-200., longitude=-200., ch;
int i, j, k, l, m, countCol=0, countRow=0, ds=0;
int DXCheckArea, DYCheckArea;
float  lattitudeMin=180., longitudeMin=180., lattitudeMax=-180., longitudeMax=-180., **globalData;
string latulStr, lonulStr, latlrStr, lonlrStr, latlonStr;
string AODFile,UoFile,UwFile,AltFile,Dir;
char cwd[MAXPATH];

gridDataType gridMet, gridClear, gridIr, gridAlt, gridAOD, gridOut;
initGrid(&gridMet);
initGrid(&gridClear);
initGrid(&gridIr);
initGrid(&gridAlt);
initGrid(&gridAOD);
initGrid(&gridOut);
time_t rawtime, ptime, current_time;
struct tm *tm;
char timeStr[256], ref_time[256] ,valid_time[256], inserted[256], dataStr[256], latlonCh[256];
int year, month, mday, hour, min, sec=0, M_min, M_sec=0, Raw_min, Raw_sec=0, LookupHours=2;
long int obsTime;
float lat, lon, upperLeftLat, upperLeftLon, lowerRightLat, lowerRightLon;
int latpixMin, lonpixMin;
char yearStr[5], monthStr[3], mdayStr[3], hourStr[3], minStr[3], secStr[3];
string outGridName="", tempGridName="";
string clElement="", clArea="", element="", area="", username="";
bool ifClearSky;
int latWidth=0, lonWidth=0; 
double glCl;

ae_pack aep;
ae_pack * paep;
paep=&aep;

TSite SiteCh;
SiteCh.x=43.75;
SiteCh.y=-96.65;

getcwd(cwd,MAXPATH);
string outDirName=cwd; outDirName=outDirName+"/IRKt/";
string FileName,prepStr,outDirName1=cwd; outDirName1=outDirName1 + "/";
FileName=SiteCh.x;prepStr=SiteCh.y;FileName=FileName+"."+prepStr+".csv";
ofstream outFile1(FileName.c_str());

outFile1 << "timeStr , SiteCh.val ,  SiteCh.zen , SiteCh.ir4  , SiteCh.temp  , SiteCh.alt  ,  SiteCh.cl_val" << endl;


//string glDirName="";
//string clDirName="";
string MetFileName="";
string IrFileName="";
string AltFileName="";
string clFileName="";
string configFileName="";
string locName;
char* dataName;
string timeName;

//reading the command line
if (argc>=3){
locName=argv[1];
configFileName=argv[2];
 if (argc==4) outDirName=argv[3];
}
else{
help();
exit(1);
}
outDirName=outDirName+locName+"/";
int status = mkdir(outDirName.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IWOTH  );

//read the config file
string chString, DbName, BandName, CorrectedFilesDb, CorrectedSelectArea, ClearskyFilesDb, MetarFilesDb, RawFilesDb, OutputFilesDb;
int linenum=1, trnum=1;
char linebuf[100000];
bool isFile=false, Verbose=false;
char * pch;

DbName="satmod";
CorrectedFilesDb="corrected_global_grid_files";
MetarFilesDb="metar_grid_files_new";
RawFilesDb="sat_grid_files";
BandName="IR-4";
ClearskyFilesDb="clearsky_grid_files";
CorrectedSelectArea=locName;
OutputFilesDb="grid_files_cm";
clArea="north_america";
clElement="clearsky_global";
area=locName;

FILE * outGridFile; 
ifstream configFile(configFileName.c_str());
for (linenum=1;configFile.getline(linebuf,100000)!= NULL; linenum++){
  pch = strtok (linebuf,"=");
	trnum=1;
  while (pch != NULL)
  {
	 	if(trnum==1) chString=pch;
		if(trnum==2){ 
		  if (chString=="DbName") DbName=pch;
			if (chString=="CorrectedFilesDb") CorrectedFilesDb=pch;
		  if (chString=="CorrectedSelectArea") {CorrectedSelectArea=pch; locName=CorrectedSelectArea;}
			if (chString=="CorrectedTimeMin") min=atoi(pch);
			if (chString=="CorrectedTimeSec") sec=atoi(pch);
			if (chString=="MetarFilesDb") MetarFilesDb=pch;
			if (chString=="MetarTimeMin") M_min=atoi(pch);
			if (chString=="MetarTimeSec") M_sec=atoi(pch);
			if (chString=="RawFilesDb") RawFilesDb=pch;
			if (chString=="identBandName") BandName=pch;
			if (chString=="RawTimeMin") Raw_min=atoi(pch);
			if (chString=="RawTimeSec") Raw_sec=atoi(pch);
			if (chString=="ClearskyFilesDb") ClearskyFilesDb=pch;
			if (chString=="ClearskySelectArea") clArea=pch;
			if (chString=="ClearskySelectElement") clElement=pch;
			if (chString=="OutputFilesDb") OutputFilesDb=pch;
			if (chString=="OutputArea") area=pch;
			if (chString=="upperLeftLat") upperLeftLat=atof(pch);
			if (chString=="upperLeftLon") upperLeftLon=atof(pch);
			if (chString=="lowerRightLat") lowerRightLat=atof(pch);
			if (chString=="lowerRightLon") lowerRightLon=atof(pch);
                        if (chString=="LookupHours") LookupHours=atoi(pch);
			if (chString=="Verbose") Verbose=atoi(pch);
		}
    pch = strtok (NULL, "=");
		trnum++;
  }
}
if (linenum>10)isFile=true;
//ifstream.close;


if(Verbose)cout << "the config file:" << endl;
if(Verbose)cout << "DbName: " << DbName << endl;
if(Verbose)cout << "CorrectedFilesDb: " << CorrectedFilesDb << endl;
if(Verbose)cout << "CorrectedSelectArea: " << locName << endl;
if(Verbose)cout << "min: " << min << endl;
if(Verbose)cout << "sec: " << sec << endl;
if(Verbose)cout << "ClearskyFilesDb: " << ClearskyFilesDb << endl;
if(Verbose)cout << "clArea: " << clArea << endl;
if(Verbose)cout << "clElement: " << clElement << endl;
if(Verbose)cout << "OutputFilesDb: " << OutputFilesDb << endl;
if(Verbose)cout << "area: " << area << endl;
if(Verbose)cout << "upperLeftLat: " << upperLeftLat << endl;
if(Verbose)cout << "upperLeftLon: " << upperLeftLon << endl;
if(Verbose)cout << "lowerRightLat: " << lowerRightLat << endl;
if(Verbose)cout << "lowerRightLon: " << lowerRightLon << endl;
if(Verbose)cout << "Verbose: " << Verbose << endl;


if (!isFile){
cout << "the config file is not correct; using the defaulf settings instead of it...." << endl;
if (locName=="us-east") {
min=15;
sec=0;
}else if (locName=="us-west") {
min=0;
sec=0;
}else if (locName=="hawaii") {
min=0;
sec=0;
}else{
help();
exit(1);
}
}

//cout << area << "  " << min << "  " << sec << endl; 
//cout << DbName << "  " << CorrectedFilesDb << "  " << ClearskyFilesDb << "  " << OutputFilesDb << endl;

//database initialization
  char db_name[20];
  dbi_conn conn;
  dbi_result result,result1;
  long conn_id;
  char conn_id_str[256];

  strcpy(db_name,DbName.c_str());
	//strcpy(db_name,"satmod");
  dbi_initialize(NULL);
  conn = dbi_conn_new("mysql");

  dbi_conn_set_option(conn, "host", "localhost");
  //dbi_conn_set_option(conn, "username", "sergey");
  //dbi_conn_set_option(conn, "password", "masterkey");
  dbi_conn_set_option(conn, "dbname", db_name);
  dbi_conn_set_option(conn, "encoding", "UTF-8");
  //username=dbi_conn_get_option(conn, "username");
  if (dbi_conn_connect(conn) < 0) {
                cout << "Problems opening forecast db" << endl;
								exit(1); 
  }

vector< vector< vector<float> > > MapMas(2, vector< vector<float> >(1000, vector<float>(1000,0)));
vector< vector< vector<float> > > globalIR(2, vector< vector<float> >(1000, vector<float>(1000,0)));
vector< vector< vector<float> > > clearSky(3, vector< vector<float> >(1000, vector<float>(1000,0)));

vector< vector<float> > alt (1000, vector<float>(1000,0));
vector< vector<float> > tau (1000, vector<float>(1000,0));
vector< vector<float> > uw (1000, vector<float>(1000,0));
vector< vector<float> > uo (1000, vector<float>(1000,0));
vector< vector<float> > CoZen (1000, vector<float>(1000,0));

//dbi_conn_query(conn,"SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;");
dbi_conn_query(conn,"START TRANSACTION;");

result1 = dbi_conn_query(conn,"SHOW PROCESSLIST;");
while(dbi_result_next_row(result1)){
 conn_id=dbi_result_get_longlong(result1, "id");
 result=dbi_conn_queryf(conn,"select * from processes where id='%ld' and location='%s';",conn_id,locName.c_str());
 if(dbi_result_next_row(result)){
  if(Verbose)  cout << "the process has already been started" << endl;
dbi_conn_query(conn,"ROLLBACK;");
  dbi_result_free(result);
  dbi_result_free(result1);
  dbi_conn_close(conn);
  dbi_shutdown();
  exit(1);
 }
}

 result = dbi_conn_query(conn,"SELECT CONNECTION_ID();");
while(dbi_result_next_row(result)){
 conn_id=dbi_result_get_longlong(result, "CONNECTION_ID()");
 sprintf(conn_id_str, "%d",conn_id);
}

 time(&ptime);
 tm = gmtime(&ptime);
 strftime(inserted, 256, "%Y-%m-%d %H:%M:%S", tm);
//result1 = dbi_conn_queryf(conn,"insert into processes(id,time_start,location) values('%s','%s','%s');", conn_id_str,inserted,locName.c_str());
result1 = dbi_conn_queryf(conn,"insert into processes(id,time_start,time_end,location) values('%s','%s','%s','%s');", conn_id_str,inserted,inserted,locName.c_str());
//  printf("%2ld \n", dbi_result_get_longlong(result, "CONNECTION_ID()") );

dbi_conn_query(conn,"COMMIT;");

sprintf(dataStr,"%.3f",upperLeftLat+1);latulStr=dataStr;
sprintf(dataStr,"%.3f",upperLeftLon-1);lonulStr=dataStr;
sprintf(dataStr,"%.3f",lowerRightLat-1);latlrStr=dataStr;
sprintf(dataStr,"%.3f",lowerRightLon+1);lonlrStr=dataStr;
latlonStr=latulStr+","+lonulStr+","+latlrStr+","+lonlrStr;
strcpy(latlonCh,latlonStr.c_str());
if(Verbose) cout << "check latlonCh:" << latlonCh << endl;
	
if(Verbose)  cout << "current time generator: " << endl;
time(&current_time);
tm = gmtime(&current_time);
strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
strftime(inserted, 256, "%Y-%m-%d %H:%M:%S", tm);
year=tm->tm_year+1900;
month=tm->tm_mon+1;
mday=tm->tm_mday;
hour=tm->tm_hour-LookupHours;
if(Verbose)  cout << year << "-" << month << "-" << mday << " " << hour << ":" << min << ":" << sec << endl;
   rawtime = timeGm(year, month, mday, hour, min, sec);
while (rawtime<current_time){
hour++;

//checking presence / consistence of the Temperature, IR4, Altitude files for IR_KT generation

   rawtime = timeGm(year, month, mday, hour, M_min, M_sec);
   tm = gmtime(&rawtime);
   strftime(ref_time, 256, "%Y-%m-%d %H:%M:%S", tm);
 result=dbi_conn_queryf(conn,"select * from %s where valid_time='%s' and element='%s' and area='%s';",MetarFilesDb.c_str(),ref_time,"temp","us-canada");
 if(dbi_result_next_row(result)){
  MetFileName=dbi_result_get_string_copy(result,"filename");
  if(Verbose) cout << "the Temp_grid_files: " << MetFileName << endl; 
 }else{
  if(Verbose) cout << "there are no entries Temp in the " << MetarFilesDb << " for: " << ref_time << endl;
  continue;
 }
dbi_result_free(result);

   rawtime = timeGm(year, month, mday, hour, Raw_min, Raw_sec);
   tm = gmtime(&rawtime);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
   strftime(ref_time, 256, "%Y-%m-%d %H:%M:%S", tm);
	 strftime(valid_time, 256, "%Y-%m-%d %H:%M:%S", tm);
	 
 result=dbi_conn_queryf(conn,"select * from %s where imageTime='%s' and identBandName='%s';",RawFilesDb.c_str(),ref_time,BandName.c_str());
 if(dbi_result_next_row(result)){
  IrFileName=dbi_result_get_string_copy(result,"gridFilename");
  if(Verbose) cout << "the IR_grid_files for 2: " << IrFileName << endl; 
 }else{
  if(Verbose) cout << "there are no entries IR in the " << RawFilesDb << " for: " << ref_time << endl;
  continue;
 }
dbi_result_free(result);

AltFileName="/home/jim/satmod/auxillaryData/us/us-east.altitude.grid";
 
   rawtime = timeGm(year, month, mday, hour, Raw_min, Raw_sec);
   tm = gmtime(&rawtime);
   strftime(timeStr, 256, "%j", tm); 
   result=dbi_conn_queryf(conn,"select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str(),clArea.c_str());	 
 if(dbi_result_next_row(result)){
   clFileName=dbi_result_get_string_copy(result,"gridFilename");
   if(Verbose) cout << "the clearsky_grid_files for 1: " << clFileName << endl;
//printf ("select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,hour,min,clElement.c_str(),clArea.c_str());
 }
 else{
  if(Verbose) cout << "there are no entries in the " << ClearskyFilesDb << " for: " << ref_time << endl;

  if(Verbose) fprintf (stderr, "select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str()),clArea.c_str();
  //continue;
 }
dbi_result_free(result);


   gridMet.fileName = (char*)MetFileName.c_str();
   if (!openReadGridfile(&gridMet)){
	 if(Verbose) cout << "can't open Temp " << MetFileName << endl;
  continue;
	 }
	 
   gridClear.fileName = (char*)clFileName.c_str();
   if (!openReadGridfile(&gridClear)){
	 if(Verbose) cout << "can't open Cl " << clFileName << endl;
  continue;
	 }
	 
   gridIr.fileName = (char*)IrFileName.c_str();
   if (!openReadGridfile(&gridIr)){
	 if(Verbose) cout << "can't open IR " << IrFileName << endl;
  continue;
	 }
	 
   gridAlt.fileName = (char*)AltFileName.c_str();
   if (!openReadGridfile(&gridAlt)){
	 if(Verbose) cout << "can't open Alt " << AltFileName << endl;
  continue;
	 }


dbi_conn_query(conn,"START TRANSACTION;");
   ptime = timeGm(year, month, mday, hour, Raw_min, Raw_sec);
   tm = gmtime(&ptime);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
   outGridName=outDirName; outGridName=outGridName+locName+"."+timeStr+".irkt.grid";
   result = dbi_conn_queryf(conn,"select element,area,gridFilename from %s where gridFilename='%s';",OutputFilesDb.c_str(),outGridName.c_str());

 if(!result) {
     if(Verbose) cout << "problems doing select" << endl;
     if(Verbose) printf ("select element,area,gridFilename from %s where gridFilename='%s';",OutputFilesDb.c_str(),outGridName.c_str());

  }
 if (dbi_result_next_row(result)){
  if(Verbose) cout << "the file" << outGridName.c_str()  << " already exists" << endl;
dbi_conn_query(conn,"ROLLBACK;");
  continue;
 }
dbi_result_free(result);

 //reach and open actual IR file   
   gridIr.fileName = (char*)IrFileName.c_str();
	 setGridSubwindow(&gridIr, latlonCh);
        if (openReadGridfile(&gridIr)){
            for(int latpix=0; latpix<gridIr.readRows; latpix++)
            for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
                globalIR[0][lonpix][latpix]=IrAdjust(gridIr.data[latpix][lonpix].value);	
								lat=clearSky[1][lonpix][latpix]=gridIr.data[latpix][lonpix].lat;
								lon=clearSky[2][lonpix][latpix]=gridIr.data[latpix][lonpix].lon;			
        if (pow(lat-SiteCh.x,2)<=0.0025 && pow(lon-SiteCh.y,2)<=0.0025) {
            SiteCh.ir4=globalIR[0][lonpix][latpix];
						SiteCh.latpix=latpix;
						SiteCh.lonpix=lonpix;
        }					                     
  					}
					lattitudeMin=gridIr.data[0][0].lat;
					longitudeMin=gridIr.data[0][0].lon;		
        }
				
	countCol=gridIr.readCols;
	countRow=gridIr.readRows;
	
 //reach and open actual Met file   
   gridMet.fileName = (char*)MetFileName.c_str();
     if (openReadGridfile(&gridMet)){
            for(int latpix=0; latpix<gridMet.readRows; latpix++)
            for(int lonpix=0; lonpix<gridMet.readCols; lonpix++) {				
                lat = gridMet.data[latpix][lonpix].lat;
                lon = gridMet.data[latpix][lonpix].lon;
        if (pow(lat-SiteCh.x,2)<=0.0025 && pow(lon-SiteCh.y,2)<=0.0025) {
            SiteCh.temp=gridMet.data[latpix][lonpix].value;
        }	
          		  if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
		       }
           for(int latpix=0; latpix<gridIr.readRows; latpix++)
           for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
       		 MapMas[0][lonpix][latpix]=gridMet.data[latpixMin+latpix][lonpixMin+lonpix].value;		
		       }
	   }

   //reach and open actual Alt file
   gridAlt.fileName = (char*)AltFileName.c_str();
     if (openReadGridfile(&gridAlt)){
            for(int latpix=0; latpix<gridAlt.readRows; latpix++)
            for(int lonpix=0; lonpix<gridAlt.readCols; lonpix++) {				
                lat = gridAlt.data[latpix][lonpix].lat;
                lon = gridAlt.data[latpix][lonpix].lon;
        if (pow(lat-SiteCh.x,2)<=0.0025 && pow(lon-SiteCh.y,2)<=0.0025) {
            SiteCh.alt=gridAlt.data[latpix][lonpix].value;
        }	
          		  if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
		       }
           for(int latpix=0; latpix<gridIr.readRows; latpix++)
           for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
       		 MapMas[1][lonpix][latpix]=gridAlt.data[latpixMin+latpix][lonpixMin+lonpix].value;
		       }
	   }
		 
sprintf(monthStr, "%2.2d", tm->tm_mon+1);
Dir="/home/jim/satmod/auxillaryData/us/";
AODFile=Dir+"us-east.aod.";AODFile=AODFile + monthStr; AODFile=AODFile+ ".grid";
UwFile=Dir+"us-east.watervapor.";UwFile=UwFile + monthStr; UwFile=UwFile+ ".grid";
UoFile=Dir+"us-east.ozone.";UoFile=UoFile + monthStr; UoFile=UoFile+ ".grid";
//TAU
gridAOD.fileName = (char*)AODFile.c_str();
if (openReadGridfile(&gridAOD)){
   for(int latpix=0; latpix<gridAOD.readRows; latpix++)
   for(int lonpix=0; lonpix<gridAOD.readCols; lonpix++) {
        lat = gridAOD.data[latpix][lonpix].lat;
        lon = gridAOD.data[latpix][lonpix].lon;
				if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
	}
  for(int latpix=0; latpix<gridIr.readRows; latpix++)
  for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
            tau[lonpix][latpix]=gridAOD.data[latpixMin+latpix][lonpixMin+lonpix].value;
  }
}
else{cout << "there is no Tau: " << AODFile << endl;}
//UW
gridAOD.fileName = (char*)UwFile.c_str();
if (openReadGridfile(&gridAOD)){
   for(int latpix=0; latpix<gridAOD.readRows; latpix++)
   for(int lonpix=0; lonpix<gridAOD.readCols; lonpix++) {
        lat = gridAOD.data[latpix][lonpix].lat;
        lon = gridAOD.data[latpix][lonpix].lon;
	      if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
	}
  for(int latpix=0; latpix<gridIr.readRows; latpix++)
  for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
            uw[lonpix][latpix]=gridAOD.data[latpixMin+latpix][lonpixMin+lonpix].value;
  }
}
else{cout << "there is no Uw: " << UwFile << endl;}
//UO
gridAOD.fileName = (char*)UoFile.c_str();
if (openReadGridfile(&gridAOD)){
   for(int latpix=0; latpix<gridAOD.readRows; latpix++)
   for(int lonpix=0; lonpix<gridAOD.readCols; lonpix++) {
        lat = gridAOD.data[latpix][lonpix].lat;
        lon = gridAOD.data[latpix][lonpix].lon;
				if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
	}
  for(int latpix=0; latpix<gridIr.readRows; latpix++)
  for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
            uo[lonpix][latpix]=gridAOD.data[latpixMin+latpix][lonpixMin+lonpix].value/100.0;
  }
}
else{cout << "there is no Uo: " << UoFile << endl;}		 

   //reach and open actual clearsky file
   gridClear.fileName = (char*)clFileName.c_str();
     if (openReadGridfile(&gridClear)){
            for(int latpix=0; latpix<gridClear.readRows; latpix++)
            for(int lonpix=0; lonpix<gridClear.readCols; lonpix++) {				
                lat = gridClear.data[latpix][lonpix].lat;
                lon = gridClear.data[latpix][lonpix].lon;
        if (pow(lat-SiteCh.x,2)<=0.0025 && pow(lon-SiteCh.y,2)<=0.0025) {
            SiteCh.cl_val=gridClear.data[latpix][lonpix].value;
        }
          		  if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
		       }
           for(int latpix=0; latpix<gridIr.readRows; latpix++)
           for(int lonpix=0; lonpix<gridIr.readCols; lonpix++) {
       		 clearSky[0][lonpix][latpix]=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
					 
					 aep.lat=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].lat;
					 aep.lon=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].lon;
					 aep.year=tm->tm_year+1900;
					 aep.month=tm->tm_mon+1;
					 aep.day=tm->tm_mday;
					 aep.hour=tm->tm_hour;
					 aep.min=tm->tm_min;
					 aep.sec=tm->tm_sec;
					 strftime(timeStr, 256, "%j", tm);
					 timeName=timeStr;
					 aep.doy=atoi(timeName.c_str());
					 aep.alt=MapMas[1][lonpix][latpix];
					 aep.tau=tau[lonpix][latpix];
					 aep.uw=uw[lonpix][latpix];
					 aep.uo=uo[lonpix][latpix];
					 glCl=0; //bCl=0;
					 glCl=GHI_CL(paep);
					 //bCl=DNI_CL(paep);
					 CoZen[lonpix][latpix]=cos(aep.zen);
					 if(aep.el<0) CoZen[lonpix][latpix]=0;
        if (SiteCh.latpix==latpix && SiteCh.lonpix==lonpix) {
            SiteCh.zen=CoZen[lonpix][latpix];
        }
		       }
	   }
		 
if(Verbose) cout << "lattitudeMin=" << lattitudeMin << "   longitudeMin=" << longitudeMin << endl;
	
   lattitudeMin=180.;longitudeMin=180.;lattitudeMax=-180.;longitudeMax=-180;
   gridOut.fileName = (char*)IrFileName.c_str();
	 setGridSubwindow(&gridOut, latlonCh);
        if (openReadGridfile(&gridOut)){
            for(int latpix=0; latpix<gridOut.readRows; latpix++)
            for(int lonpix=0; lonpix<gridOut.readCols; lonpix++) {
          lat = gridOut.data[latpix][lonpix].lat;
          lon = gridOut.data[latpix][lonpix].lon;
				  if(lattitudeMin>lat)lattitudeMin=lat;
				  if(longitudeMin>lon)longitudeMin=lon;
				  if(lattitudeMax<lat)lattitudeMax=lat;
				  if(longitudeMax<lon)longitudeMax=lon;		
					                     
  					}	
        }

gridOut.hed.maxlat=lattitudeMax;
gridOut.hed.minlon=longitudeMin;
gridOut.hed.minlat=lattitudeMin;
gridOut.hed.maxlon=longitudeMax;

latWidth=gridOut.readRows-1;
lonWidth=gridOut.readCols-1;
strcpy(gridOut.hed.description, "IR4 Kt");

globalData= new float *[latWidth];
for(int i=0;i<latWidth;i++){
 globalData[i]=new float[lonWidth];
 for(int j=0;j<lonWidth;j++)
   {globalData[i][j]=0;}
}

   ptime = timeGm(year, month, mday, hour, Raw_min, Raw_sec);
   tm = gmtime(&ptime);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);	
outGridName=outDirName; outGridName=outGridName+locName+"."+timeStr+".irkt.grid";
outGridFile=fopen(outGridName.c_str(),"w");
SiteCh.val=-999;
if(Verbose) cout << " globalData starts" << endl; 
   for(int latpix=0; latpix<gridOut.readRows-1; latpix++)
   for(int lonpix=0; lonpix<gridOut.readCols-1; lonpix++){ 
				globalData[latpix][lonpix]=ir4Model(CoZen[lonpix][latpix],MapMas[0][lonpix][latpix],globalIR[0][lonpix][latpix],MapMas[1][lonpix][latpix]);
        if (SiteCh.latpix==latpix && SiteCh.lonpix==lonpix) {
            SiteCh.val=globalData[latpix][lonpix];
        }
   }
	 
if(Verbose) cout << " globalData output starts: " << outGridName << endl;	 
element=BandName+"_Kt";
        //result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user,isSynthetic) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,IrFileName.c_str(),"Ir_Kt",inserted,"F");
				result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,IrFileName.c_str(),"Ir_Kt",inserted);
  if (result){
gridWriteHeaderFloat(outGridFile,&gridOut.hed);
gridWriteDataFloat(outGridFile,globalData,latWidth,lonWidth);
dbi_result_free(result);
  }
if(Verbose) cout << " globalData output finishes" << endl;		
fclose(outGridFile);

outFile1 << timeStr << "," << SiteCh.val << "," <<  SiteCh.zen << "," << SiteCh.ir4  << "," << SiteCh.temp  << "," << SiteCh.alt  << "," <<  SiteCh.cl_val << endl;

for(int i=0;i<latWidth;i++) {
        delete[] globalData[i];
}
delete[] globalData;

dbi_conn_query(conn,"COMMIT;");

} //end while time

 outFile1.flush();
 outFile1.close();

//dbi_conn_query(conn,"SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;");
dbi_conn_query(conn,"START TRANSACTION;");
result1 = dbi_conn_queryf(conn,"delete from processes where id='%s';",conn_id_str);
dbi_conn_query(conn,"COMMIT;");


  if (dbi_conn_connect(conn) >= 0) {
   //fprintf(stderr,"Problems opening forecast db\n");
   //print_db_error(conn);
  dbi_result_free(result);  
  dbi_conn_close(conn);
  dbi_shutdown();
  } 
	
}
