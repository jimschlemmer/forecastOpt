/* predict_c */

#include <time.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "types.h"

#include "predict.h"

using namespace std;

float **GeneratePredictionFrom(float **actualFrame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth)
{
TPoint mapPoint, predictPoint, fromPoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
float **smoothPredict;
extern  float **PredictFrom;

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictFrom=new float *[600];
for(i=0;i<600;i++){
// PredictFrom[i]=new float[600];
 for(j=0;j<600;j++){
     PredictFrom[i][j]=0;
 }
}


   for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){

      fromPoint.x=mapPoint.x-Dh*Movement[mapPoint.x][mapPoint.y].x;
      fromPoint.y=mapPoint.y-Dh*Movement[mapPoint.x][mapPoint.y].y;
      
      if(0<=fromPoint.x && fromPoint.x<600)if(0<=fromPoint.y && fromPoint.y<600)
      PredictFrom[mapPoint.x][mapPoint.y]=actualFrame[fromPoint.x][fromPoint.y];

   }



   if(smooth){
        smoothPredict= new float *[600];
        for(i=0;i<600;i++) smoothPredict[i]=new float[600];

        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictFrom[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                        PredictFrom[i][j]=smoothPredict[i][j];
        }

        for(i=0;i<600;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }

   return PredictFrom;

//   for(i=0;i<600;i++) delete[] PredictFrom[i];
//   delete[] PredictFrom;
};



float **GeneratePredictionTO(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto)
{
TPoint mapPoint, predictPoint, fromPoint, closePoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
double closeValue;
float **secondPredict, **thirdPredict,  **smoothPredict;
extern  float **PredictTo;
bool **isPredicted, **isSecondPredicted, **isThirdPredicted; 

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictTo=new float *[600];
secondPredict=new float *[600];
thirdPredict=new float *[600];
isPredicted=new bool *[600];
isSecondPredicted=new bool *[600];
isThirdPredicted=new bool *[600];
for(i=0;i<600;i++){
 //PredictTo[i]=new float[600];
 secondPredict[i]=new float[600];
 thirdPredict[i]=new float[600];
 isPredicted[i]=new bool[600];
 isSecondPredicted[i]=new bool[600];
 isThirdPredicted[i]=new bool[600];
 for(j=0;j<600;j++){
     PredictTo[i][j]=0;
     secondPredict[i][j]=0;
     thirdPredict[i][j]=0;
     isPredicted[i][j]=false;
     isSecondPredicted[i][j]=false;
     isThirdPredicted[i][j]=false;
 }
}

   for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
      predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
      predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
      
      if(0<=predictPoint.x && predictPoint.x<600)if(0<=predictPoint.y && predictPoint.y<600)
      if(!isPredicted[predictPoint.x][predictPoint.y]){
        PredictTo[predictPoint.x][predictPoint.y]==0;
        PredictTo[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
        secondPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isSecondPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
        thirdPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isThirdPredicted[predictPoint.x][predictPoint.y]=true;
      }

   }

   if(maxto){
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<599)if(1<=predictPoint.y && predictPoint.y<599)
                if(isSecondPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isSecondPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=secondPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<599)if(1<=predictPoint.y && predictPoint.y<599)
                if(isThirdPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isThirdPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=thirdPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
   }


   if(smooth){
        smoothPredict= new float *[600];
        for(i=0;i<600;i++) smoothPredict[i]=new float[600];

        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictTo[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                        PredictTo[i][j]=smoothPredict[i][j];
        }
     

        for(i=0;i<600;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }


   for(i=0;i<600;i++){ 
	delete[] secondPredict[i];
	delete[] thirdPredict[i];
	delete[] isPredicted[i];
	delete[] isSecondPredicted[i];
	delete[] isThirdPredicted[i];
   }
   delete[] secondPredict;
   delete[] thirdPredict;
   delete[] isPredicted;
   delete[] isSecondPredicted;
   delete[] isThirdPredicted;


   return PredictTo;

   //for(i=0;i<600;i++) delete[] PredictTo[i];
   //delete[] PredictTo;
};


float **GeneratePredictionMix(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto)
{
TPoint mapPoint, predictPoint, fromPoint, closePoint, checkPoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea, maxSize=1000;
double closeValue;
float **secondPredict, **thirdPredict,  **smoothPredict;
extern  float **PredictTo, **PredictFrom, **PredictMix; 
bool **isPredicted, **isSecondPredicted, **isThirdPredicted;

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictTo=new float *[600];
//PredictFrom=new float *[600];
//PredictMix=new float *[600];
secondPredict=new float *[maxSize];
thirdPredict=new float *[maxSize];
isPredicted=new bool *[maxSize];
isSecondPredicted=new bool *[maxSize];
isThirdPredicted=new bool *[maxSize];
for(i=0;i<maxSize;i++){
 //PredictTo[i]=new float[600];
 //PredictFrom[i]=new float[600];
 //PredictMix[i]=new float[600];
 secondPredict[i]=new float[maxSize];
 thirdPredict[i]=new float[maxSize];
 isPredicted[i]=new bool[maxSize];
 isSecondPredicted[i]=new bool[maxSize];
 isThirdPredicted[i]=new bool[maxSize];
 for(j=0;j<maxSize;j++){
     PredictTo[i][j]=t0Frame[i][j];
     PredictFrom[i][j]=t0Frame[i][j];
     PredictMix[i][j]=t0Frame[i][j];
     secondPredict[i][j]=0;
     thirdPredict[i][j]=0;
     isPredicted[i][j]=false;
     isSecondPredicted[i][j]=false;
     isThirdPredicted[i][j]=false;
 }
}

//with  boundaries
   //for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   //for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){

//without boundaries
   for(mapPoint.x=0;mapPoint.x<countCol;mapPoint.x++)
   for(mapPoint.y=0;mapPoint.y<countRow;mapPoint.y++){

			if(mapPoint.x<DXSample+DXCheckArea && mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=DYSample+DYCheckArea;			  
			}
			else if(mapPoint.x<DXSample+DXCheckArea && mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;				 	  
			}
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea) && mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=DYSample+DYCheckArea;	  
			}
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea) && mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;	  
			} 			
			else if(mapPoint.x<DXSample+DXCheckArea){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=mapPoint.y;				 
			}	
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea)){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=mapPoint.y;		 
			}
			else if(mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=mapPoint.x; checkPoint.y=DYSample+DYCheckArea;				 
			}	
			else if(mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=mapPoint.x; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;
			}
			else{
			 checkPoint.x=mapPoint.x; checkPoint.y=mapPoint.y;
      }			
       predictPoint.x=mapPoint.x+Dh*Movement[checkPoint.x][checkPoint.y].x;
       predictPoint.y=mapPoint.y+Dh*Movement[checkPoint.x][checkPoint.y].y;
       fromPoint.x=mapPoint.x-Dh*Movement[checkPoint.x][checkPoint.y].x;
       fromPoint.y=mapPoint.y-Dh*Movement[checkPoint.x][checkPoint.y].y;

			
      if(0<=predictPoint.x && predictPoint.x<maxSize)if(0<=predictPoint.y && predictPoint.y<maxSize)
      if(!isPredicted[predictPoint.x][predictPoint.y]){
        PredictTo[predictPoint.x][predictPoint.y]==0;
        PredictTo[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
  	secondPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isSecondPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
        thirdPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isThirdPredicted[predictPoint.x][predictPoint.y]=true;
      }
			
      if(0<=fromPoint.x && fromPoint.x<maxSize)if(0<=fromPoint.y && fromPoint.y<maxSize) 
			PredictFrom[mapPoint.x][mapPoint.y]=t0Frame[fromPoint.x][fromPoint.y];
			PredictMix[mapPoint.x][mapPoint.y]=PredictFrom[mapPoint.x][mapPoint.y];
   }

   if(maxto){
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<maxSize-1)if(1<=predictPoint.y && predictPoint.y<maxSize-1)
                if(isSecondPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isSecondPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=secondPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<maxSize-1)if(1<=predictPoint.y && predictPoint.y<maxSize-1)
                if(isThirdPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isThirdPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=thirdPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
   }

   for(mapPoint.x=DXSample;mapPoint.x<countCol-DXSample;mapPoint.x++)
   for(mapPoint.y=DYSample;mapPoint.y<countRow-DYSample;mapPoint.y++){
         if(PredictTo[mapPoint.x][mapPoint.y]>0 && PredictMix[mapPoint.x][mapPoint.y]>0) PredictMix[mapPoint.x][mapPoint.y]=(PredictMix[mapPoint.x][mapPoint.y]+PredictTo[mapPoint.x][mapPoint.y])/2;
         if(PredictTo[mapPoint.x][mapPoint.y]>0 && PredictMix[mapPoint.x][mapPoint.y]==0) PredictMix[mapPoint.x][mapPoint.y]=PredictTo[mapPoint.x][mapPoint.y];
   } 

   if(smooth){
        smoothPredict= new float *[maxSize];
        for(i=0;i<maxSize;i++) smoothPredict[i]=new float[maxSize];

        for(i=1;i<maxSize-1;i++)
        for(j=1;j<maxSize-1;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictMix[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<maxSize-1;i++)
        for(j=1;j<maxSize-1;j++){
                        PredictMix[i][j]=smoothPredict[i][j];
        }

        for(i=0;i<maxSize;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }


   for(i=0;i<maxSize;i++){ 
	//delete[] PredictTo[i];
	//delete[] PredictFrom[i];
	delete[] secondPredict[i];
	delete[] thirdPredict[i];
	delete[] isPredicted[i];
	delete[] isSecondPredicted[i];
	delete[] isThirdPredicted[i];
   }
   //delete[] PredictTo;
   //delete[] PredictFrom;
   delete[] secondPredict;
   delete[] thirdPredict;
   delete[] isPredicted;
   delete[] isSecondPredicted;
   delete[] isThirdPredicted;

   return PredictMix;

   //for(i=0;i<600;i++) delete[] PredictMix[i];
   //delete[] PredictMix;

}

