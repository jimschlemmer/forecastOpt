/* predict_h */

#ifndef predict_h 
#define predict_h 

#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;


float **GeneratePredictionFrom(float **actualFrame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth);
float **GeneratePredictionTO(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);
float **GeneratePredictionMix(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);

#endif /* predict_h */

