#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <sys/stat.h>
#include <string>
#include <cstring>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>
#include <dbi/dbi.h>

#define MAXPATH 256

using namespace std;

float roundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float RoundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "cleanWind.out <area> <element> (output)" << endl;
cout << "where:" << endl;
cout << "Location - us-east, us-west, etc; It should be in the same way how it is shown in the database." << endl;
cout << "element - global, direct, wind, etc." << endl;
cout << "output - the output folder path (optional). It has \"/predictions/\" value by default." << endl;
cout << "Example:" << endl;
cout << "cleanWind.out us-east WindSN /predictions/" << endl;
}

int main(int argc, char *argv[]){

int i;
time_t valid_time, ref_time;
string element="WindSN", area="us_east";
string DbName="satmod", OutputFilesDb="grid_files_cm";
string glFileName1="";
ofstream outFile1,outFile2;
char cwd[MAXPATH];

//reading the command line
if (argc>=4){
area=argv[1];
element=argv[2];
OutputFilesDb=argv[3];
}
else{
help();
exit(1);
}

getcwd(cwd,MAXPATH);
string outDirName=cwd; outDirName=outDirName+"/predictions/";
string OutFileName1=outDirName; OutFileName1=OutFileName1 + area + "_" + element + "_" + OutputFilesDb + "_delete-files" + ".txt";
outFile1.open(OutFileName1.c_str());
string OutFileName2=outDirName; OutFileName2=OutFileName2 + area + "_" + element + "_" + OutputFilesDb + "_delete-error" + ".txt";
outFile2.open(OutFileName2.c_str());

//database initialization
  char db_name[20];
  dbi_conn conn;
  dbi_result result,result1;
  long conn_id;
  char conn_id_str[256];

  strcpy(db_name,"satmod");
  dbi_initialize(NULL);
  conn = dbi_conn_new("mysql");

  dbi_conn_set_option(conn, "host", "localhost");
  dbi_conn_set_option(conn, "dbname", db_name);
  dbi_conn_set_option(conn, "encoding", "UTF-8");
	
  if (dbi_conn_connect(conn) < 0) {
                cout << "Problems opening forecast db" << endl; 
  }
	
 result=dbi_conn_queryf(conn,"select * from %s where area='%s' and element='%s';",OutputFilesDb.c_str(),area.c_str(),element.c_str());
  if(!result) {
    cout << "problems doing select" << endl;
    printf ("select * from %s where area='%s' and element='%s';",OutputFilesDb.c_str(),area.c_str(),element.c_str());
  }
 
 while (dbi_result_next_row(result)){
 glFileName1=dbi_result_get_string_copy(result,"gridFilename");
 valid_time=dbi_result_get_datetime(result,"valid_time");
 ref_time=dbi_result_get_datetime(result,"ref_time");
 //cout << valid_time << " - " << ref_time << "  " << glFileName1 << endl;
 
 if (valid_time-ref_time>4000){

      dbi_conn_query(conn,"START TRANSACTION;"); 

			result1 = dbi_conn_queryf(conn,"delete from %s where gridFilename='%s';",OutputFilesDb.c_str(),glFileName1.c_str());
			
      if( remove( glFileName1.c_str() ) != 0 ) {
			  dbi_conn_query(conn,"ROLLBACK;");
				outFile2 << "error deleting: " << glFileName1 << endl;
			}
      else {
			  dbi_conn_query(conn,"COMMIT;");
				outFile1 << "success deleting: " << glFileName1 << endl;
			}
			dbi_result_free(result1);
 }
 }
  dbi_result_free(result); 
  dbi_conn_close(conn);
  dbi_shutdown();
	
	outFile1.close();
	outFile2.close();

}

