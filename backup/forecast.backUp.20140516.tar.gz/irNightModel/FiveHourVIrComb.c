#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <sys/stat.h>
#include <string>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>
#include <dbi/dbi.h>

#include "types.h"
#include "timeUtils.h"
#include "gridded.h"
#include "ioUtils.h"

#define MAXPATH 256
#define PI 3.14159265

using namespace std;

float roundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float RoundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "Wind.out <lat> <lon> <area> (output)" << endl;
cout << "where:" << endl;
cout << "Location - us-east, us-west, etc; It should be in the same way how it is shown in the database." << endl;
cout << "element - global, direct, wind, etc." << endl;
cout << "output - the output folder path (optional). It has \"/predictions/\" value by default." << endl;
cout << "Example:" << endl;
cout << "Wind.out lat lon us-east file.csv /predictions/" << endl;
}

int main(int argc, char *argv[]){

time_t time, valid_time, ref_time;
struct tm *tm;
char timeStr[256];
string model="CM_VIR", element="global_irrad", area="us-east";
string DbName="satmod", OutputFilesDb="grid_files_cm";
string glFileName1="", snFileName1="", FileName, csvFileName, valid_time0, ref_time0;
string WFileNameSN0="",WFileNameWE0="";
ofstream outFile1;
char cwd[MAXPATH];
float lat, lon, Gl, Sn, LatVL, LonVL,WindSN,WindWE,windPixSpeed,windSpeed,windDirect;
int year, month, mday, hour, min, sec;
string latStr, lonStr;
bool first,second,third,fourth,fifth,once;

gridDataType gridGl,gridSn,gridWind;
initGrid(&gridGl);
initGrid(&gridSn);
initGrid(&gridWind);

TSite siteChosen;

//reading the command line
if (argc>=4){
siteChosen.x=atof(argv[1]);
latStr=argv[1];
siteChosen.y=atof(argv[2]);
lonStr=argv[2];
area=argv[3];
csvFileName=argv[4];
// if (argc==6) outDirName=argv[5];
}
else{
help();
exit(1);
}

//cout << "filename / path / date generator" << endl;
min=15;
sec=0;
if (area=="GOES-west" | area=="us-west"){
area="us-west";
min=0;
sec=0;
}

getcwd(cwd,MAXPATH);
string outDirName=cwd; outDirName=outDirName+"/predictions/";
string OutFileName1=outDirName; OutFileName1=OutFileName1+latStr+"_"+lonStr+"_global.csv"; 
string InFileName1=outDirName; InFileName1=InFileName1+csvFileName;
ifstream inFile1(InFileName1.c_str());
outFile1.open(OutFileName1.c_str());

outFile1 << "Lat,Lon,valid_time,Snow,Gl_1,Gl_2,Gl_3,Gl_4,Gl_5" << endl;

//database initialization
  char db_name[20];
  dbi_conn conn;
  dbi_result result,result_ref,result_SNw0,result_WEw0;
  long conn_id;
  char conn_id_str[256];

  strcpy(db_name,"satmod");
  dbi_initialize(NULL);
  conn = dbi_conn_new("mysql");

  dbi_conn_set_option(conn, "host", "localhost");
  dbi_conn_set_option(conn, "dbname", db_name);
  dbi_conn_set_option(conn, "encoding", "UTF-8");
	
  if (dbi_conn_connect(conn) < 0) {
      cout << "Problems opening forecast db" << endl; 
  }
	
	
//reading the input file
int linenum=1, trnum=1, totalTr=0;
char linebuf[100000];
char * pch;
//fgets(linebuf, sizeof linebuf, inFile1);
inFile1.getline(linebuf,100000);
outFile1 << linebuf << ",";
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
    //outFile1 << pch << ",";
    pch = strtok (NULL, ",");
		trnum++;
  }
totalTr=trnum;
trnum=1;	
outFile1 << "Lat,Lon,valid_time,Snow,WindSN,WindWE,windPixSpeed,windSpeed,windDirect,Gl_1,Gl_2,Gl_3,Gl_4,Gl_5" << endl;

//combining data together
//for (linenum = 2;fgets(linebuf, sizeof linebuf, inFile1) != NULL; linenum++){
for (linenum = 2;inFile1.getline(linebuf,100000)!= NULL; linenum++){
outFile1 << linebuf << ",";
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
	 	if(trnum==1) valid_time0=pch;
    pch = strtok (NULL, ",");
		trnum++;
  }
trnum=1;
  
	outFile1 << latStr << "," << lonStr << "," << valid_time0;	
	first=false;second=false;third=false;fourth=false;fifth=false;once=true;
  result_ref=dbi_conn_queryf(conn,"select * from %s where area='%s' and model='%s' and element='%s' and valid_time='%s' order by ref_time desc;",OutputFilesDb.c_str(),area.c_str(),model.c_str(),element.c_str(),valid_time0.c_str());
   while (dbi_result_next_row(result_ref)){
   glFileName1=dbi_result_get_string_copy(result_ref,"gridFilename");
	 valid_time=dbi_result_get_datetime(result_ref,"valid_time");
   ref_time=dbi_result_get_datetime(result_ref,"ref_time");
   tm = gmtime(&ref_time);
   strftime(timeStr, 256, "%Y-%m-%d %H:%M:%S", tm);
   ref_time0=timeStr;	 
   //cout << valid_time0 << "-" << ref_time0 << "  " << glFileName1 << endl;
	 
	 if(once){
	 	 //time = timeGm(year, month, mday, hour, min, sec);
	 tm = gmtime(&valid_time);
	 strftime(timeStr, 256, "%Y%m%d", tm);
	 snFileName1="/home/kmh/snow/data/Grid/nohrsc_ims/US_CAN/snow.nohrsc_ims.US_CAN."; snFileName1+=timeStr; snFileName1+=".grid";
   //reach and open snow files  
	 Sn=-999; 
   gridSn.fileName = (char*)snFileName1.c_str();
     if (openReadGridfile(&gridSn)){
       for(int latpix=0; latpix<gridSn.readRows; latpix++)
       for(int lonpix=0; lonpix<gridSn.readCols; lonpix++) {
         lat = gridSn.data[latpix][lonpix].lat;
         lon = gridSn.data[latpix][lonpix].lon;				 
	       if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025){
						LatVL=lat;
						LonVL=lon;
            Sn=gridSn.data[latpix][lonpix].value;	
	       }															                     
	     }
     }		
		 
 WFileNameSN0="";WFileNameWE0="";
result_SNw0 = dbi_conn_queryf(conn,"select gridFilename from %s where area='%s' and element='%s' and valid_time='%s' and ref_time='%s';",OutputFilesDb.c_str(),area.c_str(),"wind_SN",valid_time0.c_str(),ref_time0.c_str());
result_WEw0 = dbi_conn_queryf(conn,"select gridFilename from %s where area='%s' and element='%s' and valid_time='%s' and ref_time='%s';",OutputFilesDb.c_str(),area.c_str(),"wind_WE",valid_time0.c_str(),ref_time0.c_str());
while(dbi_result_next_row(result_SNw0) && dbi_result_next_row(result_WEw0)){
WFileNameSN0=dbi_result_get_string_copy(result_SNw0,"gridFilename");
WFileNameWE0=dbi_result_get_string_copy(result_WEw0,"gridFilename");
}
dbi_result_free(result_SNw0);dbi_result_free(result_WEw0);
cout << "SN: " << WFileNameSN0 << endl;
cout << "WE: " << WFileNameWE0 << endl;		 
 //reach and open wind files   
   gridWind.fileName = (char*)WFileNameSN0.c_str();
     if (openReadGridfile(&gridWind)){
       for(int latpix=0; latpix<gridWind.readRows; latpix++)
       for(int lonpix=0; lonpix<gridWind.readCols; lonpix++) {
         lat = gridWind.data[latpix][lonpix].lat;
         lon = gridWind.data[latpix][lonpix].lon;				 
	       if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025){
						LatVL=lat;
						LonVL=lon;
            WindSN=gridWind.data[latpix][lonpix].value;	
	       }															                     
	     }
     }
   gridWind.fileName = (char*)WFileNameWE0.c_str();
     if (openReadGridfile(&gridWind)){
       for(int latpix=0; latpix<gridWind.readRows; latpix++)
       for(int lonpix=0; lonpix<gridWind.readCols; lonpix++) {
         lat = gridWind.data[latpix][lonpix].lat;
         lon = gridWind.data[latpix][lonpix].lon;
	       if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025){
            WindWE=gridWind.data[latpix][lonpix].value;	
	       }																									                     
	     }
     }		 
		 windPixSpeed=sqrt(WindSN*WindSN + WindWE*WindWE);
     windSpeed=10*sqrt(WindSN*WindSN + cos(LatVL*PI/180)*cos(LatVL*PI/180)*WindWE*WindWE);
		 if (WindSN!=0 || WindWE!=0) windDirect=atan2(cos(LatVL*PI/180)*WindWE,-WindSN)*180/PI;
		 else windDirect=-999;		 
		 outFile1 << "," << Sn << "," << WindSN << "," << WindWE << "," << windPixSpeed << "," << windSpeed << "," << windDirect;
		 once=false;
	 }
	 
	 if (valid_time-ref_time<3601){
	  first=true;	
	 }
	 if (valid_time-ref_time>3601 && valid_time-ref_time<7201){
	 second=true;
	 if (!first) { outFile1 << "," << -999;  first=true;}
	 }	
	 if (valid_time-ref_time>7201 && valid_time-ref_time<10801){
	 third=true;
	 if (!first) { outFile1 << "," << -999;  first=true;}
	 if (!second) { outFile1 << "," << -999;  second=true;}
	 }	
	 if (valid_time-ref_time>10801 && valid_time-ref_time<14401){
	 fourth=true;
	 if (!first) { outFile1 << "," << -999;  first=true;}
	 if (!second) { outFile1 << "," << -999;  second=true;}
	 if (!third) { outFile1 << "," << -999;  third=true;}
	 }	
	 if ( valid_time-ref_time>14401){ 
	 fifth=true;
	 if (!first) { outFile1 << "," << -999;  first=true;}
	 if (!second) { outFile1 << "," << -999;  second=true;}
	 if (!third) { outFile1 << "," << -999;  third=true;}
	 if (!fourth) { outFile1 << "," << -999;  fourth=true;}
	 }	
	 
	 cout << valid_time0 << "-" << ref_time0 << "  " << first << second << third << fourth << fifth << "   " << glFileName1 << endl;
	 
   //reach and open wind files   
   gridGl.fileName = (char*)glFileName1.c_str();
     if (openReadGridfile(&gridGl)){
       for(int latpix=0; latpix<gridGl.readRows; latpix++)
       for(int lonpix=0; lonpix<gridGl.readCols; lonpix++) {
         lat = gridGl.data[latpix][lonpix].lat;
         lon = gridGl.data[latpix][lonpix].lon;				 
	       if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025){
						LatVL=lat;
						LonVL=lon;
            Gl=gridGl.data[latpix][lonpix].value;	
	       }															                     
	     }
     }		 		 
		 outFile1 << "," << Gl; 
	 
	 
   }//while
	 outFile1 << endl;
   dbi_result_free(result_ref); 
 }//while
  
  dbi_conn_close(conn);
  dbi_shutdown();
	
	outFile1.close();

}

