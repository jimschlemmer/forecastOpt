#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <string>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>

#include "types.h"
//#include "movement.h"
//#include "predict.h"
#include "timeUtils.h"
#include "gridded.h"
#include "ioUtils.h"

#define MAXPATH 256

using namespace std;

float  **PredictFrom, **PredictTo, **PredictMix;
TPoint **Movement0;


//float **GeneratePredictionFrom(float **actualFrame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth);
//float **GeneratePredictionTO(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);
//float **GeneratePredictionMix(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);

//TPoint **GenerateMovement(float **firstFrame, float **secondFrame, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, bool **uniqueMovement);

float roundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float RoundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float ChVal(float value){
return value>=0?value:-999;
}

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "sevenSites <Site> <csvFile> (output)" << endl;
cout << "where:" << endl;
cout << "Site:" << endl;
cout << "Penn_State:1" << endl;
cout << "Bondville:2" << endl;
cout << "Goodwin_Creek:3" << endl;
cout << "Sioux_Falls:4" << endl;
cout << "Fort_Peck_east:5" << endl;
cout << "Boulder_east:6" << endl;
cout << "Desert_Rock:7" << endl;
cout << "Boulder_west:8" << endl;
cout << "Fort_Peck_west:9" << endl;
cout << "csvFile - csv file name for the site;" << endl;
cout << "output - the output folder path (optional). It has \"/predictions/\" value by default." << endl;
cout << "Example:" << endl;
cout << "sevenSites.out 6 boulder_east.csv /predictions/" << endl;
}

int main(int argc, char *argv[]){

float lattitude=-200., longitude=-200., ch;
char next;
  dirent** de;
  DIR* dp;
int i, j, k, l, m, countCol=0, countRow=0, ds=0;
int firstImage, lastImage, DXSample, DYSample, DXCheckArea, DYCheckArea;
float  lattitudeMin=180., longitudeMin=180., lattitudeMax=-180., longitudeMax=-180.;
float **Predict, **PredictGl, ***MapMas, ***clearSky, ***globalIR;
TPoint **Movement;
bool **uniqueMovement;
TPoint mSample, mCheckArea, pSample, pCheckArea, pMiddle, pCheck, DPoint, tMBE, tRMSE;
double **MSE, **MBE, **pMSE, **pMBE;
double RMSE, ME, pRMSE, pME, totalCount, cloudIndex0[6], cloudIndex[6], CI0, CI, bestMBE, bestRMSE;
char cwd[MAXPATH];
bool isEnoughData;

gridDataType gridCorr;
time_t time;
struct tm *tm;
char timeStr[256];
int year, month, mday, hour, min, sec=0;
float lat, lon;
char yearStr[5], monthStr[3], mdayStr[3], hourStr[3], minStr[3], secStr[3];

TSite Penn_State, Bondville, Goodwin_Creek, Sioux_Falls, Fort_Peck, Boulder, Desert_Rock, siteChosen;
Penn_State.x=40.72; Penn_State.y=-77.93; 
Bondville.x=40.05; Bondville.y=-88.37;
Goodwin_Creek.x=34.25; Goodwin_Creek.y=-89.87;
Sioux_Falls.x=43.73; Sioux_Falls.y=-96.62;
Fort_Peck.x=48.31; Fort_Peck.y=-105.05;//-105.10;
Boulder.x=40.13; Boulder.y=-105.24;
Desert_Rock.x=36.63; Desert_Rock.y=-116.02;
int siteNum;
char* siteName;
char* csvFileName;
float sf_global[7]={0,0,0,0,0,0,0}, sf_persist;

/*
vector<TSite> e_sites;
vector<TSite>::iterator site_it;
e_sites.push_back(Penn_State);
e_sites.push_back(Bondville);
e_sites.push_back(Goodwin_Creek);
e_sites.push_back(Sioux_Falls);
e_sites.push_back(Fort_Peck);
e_sites.push_back(Boulder);
*/

//take command string
getcwd(cwd,MAXPATH);
string outDirName=cwd; outDirName=outDirName+"/predictions/";

if (argc>=3){
siteNum=atoi(argv[1]);
csvFileName=argv[2];
 if (argc==4) outDirName=argv[3];
}
else{
help();
exit(1);
}

cout << "filename / path / date generator" << endl;
string glDirName="/home/jim/satmod/data/us-east/primeCorrTS/";
string ir2DirName="/home/kmh/area2grid/data/grid/GOES-east/IR-2/";
string ir4DirName="/home/kmh/area2grid/data/grid/GOES-east/IR-4/";
string clDirName="/home/jim/satmod/data/us-east/unCorrected/";
string locName="us-east";
string locIRName="GOES-east";
min=15;
sec=0;
if (siteNum==1)siteChosen=Penn_State;
if (siteNum==2)siteChosen=Bondville;
if (siteNum==3)siteChosen=Goodwin_Creek;
if (siteNum==4)siteChosen=Sioux_Falls;
if (siteNum==5)siteChosen=Fort_Peck;
if (siteNum==6)siteChosen=Boulder;
if (siteNum==7 || siteNum==8 || siteNum==9){
glDirName="/home/jim/satmod/data/us-west/primeCorrTS/";
ir2DirName="/home/kmh/area2grid/data/grid/GOES-west/IR-2/";
ir4DirName="/home/kmh/area2grid/data/grid/GOES-west/IR-4/";
clDirName="/home/jim/satmod/data/us-west/unCorrected/";
locName="us-west";
locIRName="GOES-west";
min=0;
sec=0;
if (siteNum==7) siteChosen=Desert_Rock;
if (siteNum==8) siteChosen=Boulder;
if (siteNum==9) siteChosen=Fort_Peck;
}

string glFileName1="";
string clFileName1="";
string glFileName2="";
string clFileName2="";
string psFileName1="";
char* dataName;
char* timeName;

string OutFileName1=outDirName; OutFileName1=OutFileName1+"combined_"+csvFileName;
ofstream outFile1(OutFileName1.c_str());
cout << OutFileName1 << endl;
string InFileName1=outDirName; InFileName1=InFileName1+csvFileName;
//FILE * inFile1; inFile1=fopen(InFileName1.c_str(),"r");
ifstream inFile1(InFileName1.c_str());
cout << InFileName1 << endl;

cout << "initialization" << endl;

DXSample=0;
DYSample=0;
DXCheckArea=0;
DYCheckArea=0;
pSample.x=pSample.y=4;
mSample.x=mSample.y=4;
pCheckArea.x=pCheckArea.y=7;
mCheckArea.x=mCheckArea.y=7;


MapMas = new float **[2];
globalIR = new float **[2];
for (j=0; j<2; j++) {
		MapMas[j] = new float *[1000];
		globalIR[j] = new float *[1000];
    for (i=0;i<1000;i++) {
        MapMas[j][i] = new float[1000];
				globalIR[j][i] = new float[1000];
        for (k=0;k<1000;k++) {
		 				MapMas[j][i][k]=0;
		 				globalIR[j][i][k]=0;
				}
     }
}

clearSky = new float **[9];
for (j=0; j<9; j++) {
		clearSky[j]= new float *[1000];
    for (i=0;i<1000;i++) {
				clearSky[j][i]=new float[1000];
        for (k=0;k<1000;k++) {
						clearSky[j][i][k]=0;
				}
     }
}

Movement= new TPoint *[1000];
Movement0= new TPoint *[1000];
for(i=0;i<1000;i++){
 Movement[i]=new TPoint[1000];
 Movement0[i]=new TPoint[1000];
 for(j=0;j<1000;j++){
        Movement[i][j].x=Movement[i][j].y=0;
 }
}
uniqueMovement= new bool *[1000];
for(i=0;i<1000;i++){
 uniqueMovement[i]=new bool[1000];
 for(j=0;j<1000;j++){
        uniqueMovement[i][j]=true;
 }
}

Predict= new float *[1000];
PredictGl= new float *[1000];
PredictFrom= new float *[1000];
PredictTo= new float *[1000];
PredictMix= new float *[1000];
for(i=0;i<1000;i++){
 Predict[i]=new float[1000];
 PredictGl[i]=new float[1000];
 PredictFrom[i]=new float[1000];
 PredictTo[i]=new float[1000];
 PredictMix[i]=new float[1000];
 for(j=0;j<1000;j++) 
   {Predict[i][j]=0.5; PredictGl[i][j]=0.5;}
}

MSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MSE[i]=new double[2*DYCheckArea+1];
MBE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MBE[i]=new double[2*DYCheckArea+1];
pMSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) pMSE[i]=new double[2*DYCheckArea+1];
pMBE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) pMBE[i]=new double[2*DYCheckArea+1];
CI0=0; CI=0;

cout << "reading the input file" << endl;
int linenum=1, trnum=1, totalTr=0;
char linebuf[100000];
char * pch;
//fgets(linebuf, sizeof linebuf, inFile1);
inFile1.getline(linebuf,100000);
outFile1 << linebuf << ",";
cout << linebuf << endl;
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
    //outFile1 << pch << ",";
    pch = strtok (NULL, ",");
		trnum++;
  }
totalTr=trnum;
trnum=1;

outFile1 << "actSAT" << "," << "clear sky" << "," << "IR2" << "," << "IR4" << endl;
//combining data together
//for (linenum = 2;fgets(linebuf, sizeof linebuf, inFile1) != NULL; linenum++){
for (linenum = 2;inFile1.getline(linebuf,100000)!= NULL; linenum++){
for (int ii=0;ii<6;ii++) sf_global[6-ii]=sf_global[5-ii];
outFile1 << linebuf << ",";
cout << linebuf << endl;
  pch = strtok (linebuf,",");
  while (pch != NULL)
  {
	 	if(trnum==1) year=atoi(pch);
		if(trnum==2) month=atoi(pch);
		if(trnum==3) mday=atoi(pch);
		if(trnum==5) hour=atoi(pch);
		if(trnum==8) {sf_global[0]=atof(pch);}
    //outFile1 << pch << ",";
    pch = strtok (NULL, ",");
		trnum++;
  }

//	if (trnum<totalTr){
//		 for(int ii=trnum; ii<totalTr; ii++) outFile1 << " ,";
//	}
trnum=1;

//	for (int ii=0;ii<=6;ii++) cout << sf_global[ii] << " ";

//cout << "DATA: " << " ";
   time = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&time);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
cout << timeStr << endl;
   psFileName1=locName+"."; psFileName1+=timeStr; psFileName1+=".primeCorr.global.grid"; psFileName1=glDirName+psFileName1;
initGrid(&gridCorr);
        gridCorr.fileName = (char*)psFileName1.c_str();
        if (openReadGridfile(&gridCorr)){
                countCol=gridCorr.readCols;
                countRow=gridCorr.readRows;
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;

if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025) {outFile1 << gridCorr.data[latpix][lonpix].value << ",";}
               }
        }
        else {
                outFile1 << -999 << ",";
        }


   time = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&time);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
   clFileName2=locName+"."; clFileName2+=timeStr; clFileName2+=".clearsky.grid"; clFileName2=clDirName+clFileName2;
initGrid(&gridCorr);
        gridCorr.fileName = (char*)clFileName2.c_str();
        if (openReadGridfile(&gridCorr)){
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;

if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025) {
outFile1 << gridCorr.data[latpix][lonpix].value << ","; 
siteChosen.cl_val=gridCorr.data[latpix][lonpix].value;
}
          }
        }
        else {
                outFile1 << -999 << ",";
        }
				
//for(int k=1;k<=6;k++) 
{
isEnoughData=true;

   time = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&time);
   strftime(timeStr, 256, "%Y%m%d%H%M", tm);
   glFileName1=locIRName+".IR-2."; glFileName1+=timeStr; glFileName1+=".grid"; glFileName1=ir2DirName+glFileName1;
cout << timeStr << " ";
   time = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&time);
   strftime(timeStr, 256, "%Y%m%d%H%M", tm);
   glFileName2=locIRName+".IR-4."; glFileName2+=timeStr; glFileName2+=".grid"; glFileName2=ir4DirName+glFileName2;

 //reach and open actual global irradiance file for t-1   
initGrid(&gridCorr);
        gridCorr.fileName = (char*)glFileName1.c_str();
        if (openReadGridfile(&gridCorr)){
       		countCol=gridCorr.readCols;
        	countRow=gridCorr.readRows;
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
                globalIR[0][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;
                MapMas[0][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;						                     }
        }
	else {
		isEnoughData=false;
	}

 //reach and open actual global irradiance file for t0   
initGrid(&gridCorr);
        gridCorr.fileName = (char*)glFileName2.c_str();
        if (openReadGridfile(&gridCorr)){
        	countCol=gridCorr.readCols;
        	countRow=gridCorr.readRows;
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
                globalIR[1][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;
                MapMas[1][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;	
               
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;

if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025) {
siteChosen.val=siteChosen.cl_val*gridCorr.data[latpix][lonpix].value;
sf_persist=siteChosen.cl_val*sf_global[k];}
	}		 
        }
	else {
		isEnoughData=false;
	}


	if (!isEnoughData){
		outFile1 << -999 << "," << -999 << ",";
		continue;
	}

 
   for(int latpix=0; latpix<gridCorr.readRows; latpix++)
   for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++){ 
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;

if (pow(lat-siteChosen.x,2)<=0.0025 && pow(lon-siteChosen.y,2)<=0.0025)	 outFile1 << ChVal(RoundTo(MapMas[0][lonpix][latpix],-2)) << "," << ChVal(RoundTo(MapMas[1][lonpix][latpix],-2));
   }


 //cout << k << "-hour prediction generation ends" << endl;
} //for k

	 outFile1 << endl;

} //for input file lines

 outFile1.flush();
 outFile1.close();

// clear variables

for (j=0; j<2; j++) {
    for (i=0; i<1000; i++) {
         delete[] MapMas[j][i];
	 delete[] globalIR[j][i];
    }
    delete[] MapMas[j];
    delete[] globalIR[j];
}
delete[] MapMas;
delete[] globalIR;

for (j=0; j<9; j++) {
    for (i=0; i<1000; i++) {
	delete[] clearSky[j][i];
    }
	delete[] clearSky[j];
}
delete[] clearSky;

for(i=0;i<1000;i++) {
        delete[] Movement[i];
        //delete[] Movement0[i];
        delete[] uniqueMovement[i];
}
delete[] Movement;
//delete[] Movement0;
delete[] uniqueMovement;

for(i=0;i<1000;i++) {
        delete[] Predict[i];
        delete[] PredictGl[i];
        //delete[] PredictFrom[i];
        //delete[] PredictTo[i];
        //delete[] PredictMix[i];
}
delete[] Predict;
delete[] PredictGl;
//delete[] PredictFrom;
//delete[] PredictTo;
//delete[] PredictMix;

for(i=0;i<2*DXCheckArea+1;i++) delete[] MSE[i];
delete[] MSE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] MBE[i];
delete[] MBE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] pMSE[i];
delete[] pMSE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] pMBE[i];
delete[] pMBE;
}
