#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <cstring>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>

#include "types.h"
#include "radiation.h"
#include "sunae.h"
#include "gridded.h"

using namespace std;


double extraterr(int doy);
double GHI_CL (ae_pack *aep);
double GHI_CL (ae_pack aep);
double DNI_CL (ae_pack *aep);
double DNI_CL (ae_pack aep);


double GHI_CL (ae_pack *aep){

double GHI=0, Io=0, tst=0, uw=0, uo=0, tau=0, alt=0;
double iomod, glotau, gloa;
string month;

//cout << "GHI: " << aep->year << " " << aep->month << " " << aep->day << " " << aep->hour << " " << aep->min << " " << aep->sec << " " << aep->lat << " " << aep->lon << " " << aep->doy << endl;

tst=sunae(aep);
Io=extraterr(aep->doy);

//iomod = Io*((0.393*uw^0.348)*tau^2+(1.188*uw^0.036)*tau+(1.078*uw^0.00659)) -(1-(1 - alt/10000))*111;                                                                                                                                                                                    
//glotau= 0.144*(1-(1 -alt / 10000)) +(-0.0042*uw^2+0.0103*uw-1.214)*tau+(0.00422*uw^2-0.0522*uw-0.215);
//gloa  = - 0.071*tau+(0.0006*uw^2-0.0091*uw+0.381);
//GHI   = iomod * EXP(glotau / (cosZ)^gloa)*cosZ;

//cout << " Alt= " << alt << " AOD= " << tau << " Uwater= " << uw << endl;
if (M_RTOD*aep->zen<89.9){
iomod=Io*(0.393*pow(aep->uw,0.348)*aep->tau*aep->tau+1.188*pow(aep->uw,0.036)*aep->tau+1.078*pow(aep->uw,0.00659))-(aep->alt/10000.0)*111;
glotau=0.144*(aep->alt/10000.0)+(-0.0042*aep->uw*aep->uw+0.0103*aep->uw-1.214)*aep->tau+(0.00422*aep->uw*aep->uw-0.0522*aep->uw-0.215);
gloa=-0.071*aep->tau+(0.0006*aep->uw*aep->uw-0.0091*aep->uw+0.381);
GHI=iomod*exp(glotau/pow(cos(aep->zen),gloa))*cos(aep->zen);
}else{
GHI=0;
}
return GHI;

}

double GHI_CL (ae_pack aep){

double GHI=0, Io=0, tst=0, uw=0, uo=0, tau=0, alt=0;
double iomod, glotau, gloa;
string month;

ae_pack gaep;
ae_pack *pgaep;
pgaep = &gaep;
gaep=aep;

//cout << "GHI: " << aep->year << " " << aep->month << " " << aep->day << " " << aep->hour << " " << aep->min << " " << aep->sec << " " << aep->lat << " " << aep->lon << " " << aep->doy << endl;

tst=sunae(pgaep);
Io=extraterr(aep.doy);

//iomod = Io*((0.393*uw^0.348)*tau^2+(1.188*uw^0.036)*tau+(1.078*uw^0.00659)) -(1-(1 - alt/10000))*111;                                                                                                                                                                                    
//glotau= 0.144*(1-(1 -alt / 10000)) +(-0.0042*uw^2+0.0103*uw-1.214)*tau+(0.00422*uw^2-0.0522*uw-0.215);
//gloa  = - 0.071*tau+(0.0006*uw^2-0.0091*uw+0.381);
//GHI   = iomod * EXP(glotau / (cosZ)^gloa)*cosZ;

//
if(M_RTOD*gaep.zen<89.9){
iomod=Io*(0.393*pow(aep.uw,0.348)*aep.tau*aep.tau+1.188*pow(aep.uw,0.036)*aep.tau+1.078*pow(aep.uw,0.00659))-(aep.alt/10000.0)*111;
glotau=0.144*(aep.alt/10000.0)+(-0.0042*aep.uw*aep.uw+0.0103*aep.uw-1.214)*aep.tau+(0.00422*aep.uw*aep.uw-0.0522*aep.uw-0.215);
gloa=-0.071*aep.tau+(0.0006*aep.uw*aep.uw-0.0091*aep.uw+0.381);
GHI=iomod*exp(glotau/pow(cos(gaep.zen),gloa))*cos(gaep.zen);
}else{
GHI=0;
}

//cout << " Alt= " << aep.alt << " AOD= " << aep.tau << " Uwater= " << aep.uw << " Z= " << M_RTOD*gaep.zen << " AM= " << gaep.am << " Io= " << Io << " GHI= " << GHI << endl;
return GHI;

}


double DNI_CL (ae_pack *aep){

double DNI=0, Io=0, tst=0, uw=0, uo=0, tau=0, alt=0;
double xw,xo,eam,tr,to,tum,tw,ta;
string month;

tst=sunae(aep);
Io=extraterr(aep->doy);

//cout << " Alt= " << alt << " AOD= " << tau << " Uwater= " << uw << " Uozone= " << uo << endl;

//xw   = uw * am;         
//xo   = uo * am;                                                                                                                                                                           
//eam  = (1 -alt/ 10000) * am                                                                                                                                                                                          
//tr        = exp(-0.0903 * pow(eam, 0.84) * (1.0 + eam - pow(eam,1.01)));                                                                                                                                                                                   
//to        = 1.0 - (0.1611 * xo * pow((1.0 + 139.48 * xo),-0.3035)) -(0.002715 * xo *pow((1.0 + (0.044 * xo)) + (0.0003 * (pow(xo,2.0))), -1.0));                                                                                                                                                                                    
//tum = exp(-0.0127 * pow(eam,0.26));                                                                                                                                                                                    
//tw        = 1.0 - 1.668 * xw *pow(pow(1.0 + 54.6 * xw, 0.637) + 4.042 * xw, -1.0);                                                                                                                                                                                    
//ta        = exp(-(tau) * am);         
//DNIclear  =          tr * to * tum * tw * ta * Io * 0.9751
if (M_RTOD*aep->zen<89.9){
xw=aep->uw*(aep->am);
xo=aep->uo*(aep->am);
eam=(1-aep->alt/10000)*(aep->am);
tr=exp(-0.0903*pow(eam,0.84)*(1.0+eam-pow(eam,1.01)));
to=1.0-(0.1611*xo*pow((1.0+139.48*xo),-0.3035))-(0.002715*xo*pow((1.0+0.044*xo+0.0003*xo*xo),-1.0));
tum=exp(-0.0127*pow(eam,0.26));
tw=1.0-1.668*xw*pow(pow(1.0+54.6*xw,0.637)+4.042*xw,-1.0);
ta=exp(-aep->tau*(aep->am));
DNI=tr*to*tum*tw*ta*Io*0.9751;
}else{
DNI=0;
}
return DNI;

}

double DNI_CL (ae_pack aep){

double DNI=0, Io=0, tst=0, uw=0, uo=0, tau=0, alt=0;
double xw,xo,eam,tr,to,tum,tw,ta;
string month;

ae_pack gaep;
ae_pack *pgaep;
pgaep = &gaep;
gaep=aep;

tst=sunae(pgaep);
Io=extraterr(aep.doy);

//cout << " Alt= " << alt << " AOD= " << tau << " Uwater= " << uw << " Uozone= " << uo << endl;

//xw   = uw * am;         
//xo   = uo * am;                                                                                                                                                                           
//eam  = (1 -alt/ 10000) * am                                                                                                                                                                                          
//tr        = exp(-0.0903 * pow(eam, 0.84) * (1.0 + eam - pow(eam,1.01)));                                                                                                                                                                                   
//to        = 1.0 - (0.1611 * xo * pow((1.0 + 139.48 * xo),-0.3035)) -(0.002715 * xo *pow((1.0 + (0.044 * xo)) + (0.0003 * (pow(xo,2.0))), -1.0));                                                                                                                                                                                    
//tum = exp(-0.0127 * pow(eam,0.26));                                                                                                                                                                                    
//tw        = 1.0 - 1.668 * xw *pow(pow(1.0 + 54.6 * xw, 0.637) + 4.042 * xw, -1.0);                                                                                                                                                                                    
//ta        = exp(-(tau) * am);         
//DNIclear  =          tr * to * tum * tw * ta * Io * 0.9751
if(M_RTOD*gaep.zen<89.9){
xw=aep.uw*(gaep.am);
xo=aep.uo*(gaep.am);
eam=(1-aep.alt/10000)*(gaep.am);
tr=exp(-0.0903*pow(eam,0.84)*(1.0+eam-pow(eam,1.01)));
to=1.0-(0.1611*xo*pow((1.0+139.48*xo),-0.3035))-(0.002715*xo*pow((1.0+0.044*xo+0.0003*xo*xo),-1.0));
tum=exp(-0.0127*pow(eam,0.26));
tw=1.0-1.668*xw*pow(pow(1.0+54.6*xw,0.637)+4.042*xw,-1.0);
ta=exp(-aep.tau*(gaep.am));
DNI=tr*to*tum*tw*ta*Io*0.9751;
}else{
DNI=0;
}

//cout << " Alt= " << aep.alt << " AOD= " << aep.tau << " Uwater= " << aep.uw << " Z= " << M_RTOD*gaep.zen << " AM= " << gaep.am << " Io= " << Io << " DNI= " << DNI << endl;
return DNI;

}


double extraterr(int doy){

double Io;
Io=1367*(1+0.033*cos(0.0172*(double)doy));
return Io;

}

