#!/usr/bin/perl
#
my $dateTime = `date +'%Y%m%d_%T'`;
chomp($dateTime);

$eastLog = "./logs/irKtGen.us-east.$dateTime.out";
$westLog = "./logs/irKtGen.us-west.$dateTime.out";

`../IrKtGenerator.out us-east ./us-east-hourly-IR.conf >& $eastLog`;
#`../IrKtGenerator.out us-west ./us-west-hourly-IR.conf >& $westLog`;
