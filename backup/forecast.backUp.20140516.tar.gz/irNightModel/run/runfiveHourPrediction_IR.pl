#!/usr/bin/perl
#
my $dateTime = `date +'%Y%m%d_%T'`;
chomp($dateTime);

$eastLog = "./logs/fiveHourPrediction_IR.us-east.$dateTime.out";
$westLog = "./logs/fiveHourPrediction_IR.us-west.$dateTime.out";

`../fiveHourPrediction_IR.out us-west ./us-west-hourly-cloudmotion-ir.conf >& $westLog`;
`../fiveHourPrediction_IR.out us-east ./us-east-hourly-cloudmotion-ir.conf >& $eastLog`;
