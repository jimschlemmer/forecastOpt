/* movement_h */

#ifndef movement_h 

#define movement_h 

#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

TPoint **GenerateMovement(float **firstFrame, float **secondFrame, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, bool **uniqueMovement);


#endif /* movement_h */

