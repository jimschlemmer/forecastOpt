#!/usr/bin/perl
#
my $sumWtCalls = 0;
my $printWtCalls = 0;

sub sumWts
{
   my @wts = @_;
   my $sum;

   $sumWtCalls++;
   $sum += $_ for @wts;
   return $sum;
}

sub printWts
{
   my @wts = @_;

   $printWtCalls++;
   my $sum = sumWts(@wts);
   for(my $i=4;$i>=0;$i--) {
	printf "%3d ", $wts[$i];
   }
   printf "sum = %d\n", $sum;
}

my @wts;
my ($d1,$d2,$d3,$d4);

for($d4=0;$d4<5;$d4++) {
   $wts[3] = 25 * $d4;
   for($d3=0;$d3<5;$d3++) {
      $wts[2] = 25 * $d3;
      for($d2=0;$d2<5;$d2++) {
         $wts[1] = 25 * $d2;
         for($d1=0;$d1<5;$d1++) {
            $wts[0] = 25 * $d1;
            printWts(@wts);
         }
      }
   }
}

printf "\nTotal possible calls = %d\n", 5 ** 4;
printf "Total printWt calls = %d\n", $printWtCalls;
printf "Total sumWt calls = %d\n", $sumWtCalls;
