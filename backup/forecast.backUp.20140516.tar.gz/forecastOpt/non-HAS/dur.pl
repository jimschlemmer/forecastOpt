#!/usr/bin/perl
#
my @array = (3, 5, 4, 7);

my $score = 1;
$score *= $_ for @array;
print ($score / @array), "\n";
