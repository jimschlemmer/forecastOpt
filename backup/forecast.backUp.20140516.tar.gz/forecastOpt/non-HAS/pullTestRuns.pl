#!/usr/bin/perl
#
$outputDir = "/home/jim/mom/forecastOpt/non-HAS";

# forecastSummary.Desert_Rock_NV.20130622-20130622.div=5.hours=1-36.csv
# forecastSummary.Goodwin_Creek_MS.20130622-20130622.div=5.hours=1-36.csv
# forecastSummary.Hanford_CA.20130622-20130622.div=5.hours=1-36.csv
# forecastSummary.Penn_State_PA.20130622-20130622.div=5.hours=1-36.csv


#site=Desert_Rock_NV lat=36.630 lon=-116.020 divisions=5 start date=20130622.000000end date=20140205.000000
#hoursAhead,group N,sat RMSE,p1RMSE,p2RMSE,p1SumWts calls,p1RMSE calls,p2SumWts calls,p2RMSE calls,ncep_RAP_DSWRF model, ncep_RAP_DSWRF status,ncep_RAP_DSWRF N,ncep_RAP_DSWRF RMSE,ncep_RAP_DSWRF weight 1,ncep_RAP_DSWRF weight 2,persistence model, persistence status,persistence N,persistence RMSE,persistence weight 1,persistence weight 2,ncep_NAM_hires_DSWRF_inst model, ncep_NAM_hires_DSWRF_inst status,ncep_NAM_hires_DSWRF_inst N,ncep_NAM_hires_DSWRF_inst RMSE,ncep_NAM_hires_DSWRF_inst weight 1,ncep_NAM_hires_DSWRF_inst weight 2,ncep_NAM_DSWRF model, ncep_NAM_DSWRF status,ncep_NAM_DSWRF N,ncep_NAM_DSWRF RMSE,ncep_NAM_DSWRF weight 1,ncep_NAM_DSWRF weight 2,ncep_GFS_sfc_DSWRF_surface_avg model, ncep_GFS_sfc_DSWRF_surface_avg status,ncep_GFS_sfc_DSWRF_surface_avg N,ncep_GFS_sfc_DSWRF_surface_avg RMSE,ncep_GFS_sfc_DSWRF_surface_avg weight 1,ncep_GFS_sfc_DSWRF_surface_avg weight 2,ncep_GFS_sfc_DSWRF_surface_inst model, ncep_GFS_sfc_DSWRF_surface_inst status,ncep_GFS_sfc_DSWRF_surface_inst N,ncep_GFS_sfc_DSWRF_surface_inst RMSE,ncep_GFS_sfc_DSWRF_surface_inst weight 1,ncep_GFS_sfc_DSWRF_surface_inst weight 2,ncep_GFS_DSWRF model, ncep_GFS_DSWRF status,ncep_GFS_DSWRF N,ncep_GFS_DSWRF RMSE,ncep_GFS_DSWRF weight 1,ncep_GFS_DSWRF weight 2,NDFD_global model, NDFD_global status,NDFD_global N,NDFD_global RMSE,NDFD_global weight 1,NDFD_global weight 2,cm model, cm status,cm N,cm RMSE,cm weight 1,cm weight 2,ecmwf_ghi model, ecmwf_ghi status,ecmwf_ghi N,ecmwf_ghi RMSE,ecmwf_ghi weight 1,ecmwf_ghi weight 2

@sites = ('Desert_Rock_NV', 'Goodwin_Creek_MS', 'Hanford_CA', 'Penn_State_PA');
@divisions = (5,7,10,12);

foreach $site (@sites) {
   $haData = ();
   $outfileName = "granularityTest.$site.csv";
   open(OUT, ">$outfileName") || die "Couldn't open $outfileName";
   foreach $division (@divisions) {
      $fileName = sprintf "$outputDir/new-test%d/output/forecastSummary.%s.20130622-20130622.div=%d.hours=1-36.csv", $division, $site, $division;
      if(! -e $fileName) {
	 die "couldn't find $fileName\n";
      }
      @data = split /\n/,`cut -d',' -f1-5 $fileName`;
      shift(@data); 
      shift(@data); 
      foreach $line (@data) {
        ($hoursAhead,$N,$satRMSE,$p1RMSE,$p2RMSE) = split(",", $line);
      	$haData->{$hoursAhead}->{$division} = join(",", ($hoursAhead,$N,$satRMSE,$p1RMSE,$p2RMSE));
      }
   }

   printf OUT "#Comparison on different weight division sizes on forecastOpt for site %s\n", $site;
   print  OUT "#HA,Sat-RMSE,d5_RMSE_1,d5_RMSE_2,d7_RMSE_1,d7_RMSE_2,d10_RMSE_1,d10_RMSE_2,d12_RMSE_1,d12_RMSE_2,\n";
   foreach $ha (sort { $a <=> $b } keys %{$haData}) {
        $firstDiv = 1;
	foreach $div (sort { $a <=> $b } keys %{$haData->{$ha}}) {
		($hoursAhead,$N,$satRMSE,$p1RMSE,$p2RMSE) = split(",", $haData->{$ha}->{$div});
                if($firstDiv) {
			$firstDiv = 0;
			printf OUT "$ha,$satRMSE";
		}
		printf OUT ",$p1RMSE,$p2RMSE";
        }
        print OUT "\n";
   }
   close OUT;
}
