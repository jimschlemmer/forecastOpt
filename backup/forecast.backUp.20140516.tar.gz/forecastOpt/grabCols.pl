#!/usr/bin/perl
#
$column = shift @ARGV;
$forecastFile = shift @ARGV;

$len = length($column);
@colNames = split /\n/, `cat /home/jim/mom/forecastOpt/head`;
#$forecastFile = '/var/www/html/kmh/data/adam/forecast.desert_rock.csv';

$cutArg = "-f5,7";
$cutArg = "-f5";

for($i=0;$i<=$#colNames;$i++) {
    $substr = substr($colNames[$i], 0, $len);
    if($substr eq $column) {
    	#printf "$colNames[$i] column %d\n", $i+1;
	$cutArg .= sprintf ",%d", $i+1;
    }
} 

#print "cutArg = $cutArg\n";

$comm = "cut $cutArg $forecastFile";
#print "$comm\n";
$res = `$comm`;
$res =~ s/\t/,/g;
print $res;
