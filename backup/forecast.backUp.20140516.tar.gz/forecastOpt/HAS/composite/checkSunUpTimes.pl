#!/usr/bin/perl
#
@input = split /\n/, `cat $ARGV[0]`;

foreach $line(@input) {
# Hanford_CA,36.31,-119.63,time=2014/02/04 18:00:00,sunrise=2014/02/04 14:57:00,hoursAfterSunrise=4
    ($site,$lat,$lon,$currTime,$sunrise,$hoursAfterSunrise) = split(",",$line);
    $currTime =~ s/time=//g;
    $sunrise =~ s/sunrise=//g;
    $hoursAfterSunrise =~ s/hoursAfterSunrise=//g;
    ($date,$time) = split(" ", $sunrise);
    ($y,$m,$d) = split("/", $date);
    ($h,$min,$s) = split(":", $time);
    $jd = `jd $m/$d/$y`;
    chomp($jd);
    $jd = $jd + $h/24.0 + $min/1440.0 + $s/86400.0;
    $comm = "airmass -t $lat -g $lon -qd $jd";
    #print "$comm\n";
    $res = `$comm`;
    chomp($res);
    ($jd,$az,$el,@rest) = split(" ", $res);
    print STDERR "$line : el = $el\n" if(1 || $el > .5 || $el < -.5);
}
