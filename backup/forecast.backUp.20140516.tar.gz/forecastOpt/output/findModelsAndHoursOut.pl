#!/usr/bin/perl

$header = `head -1 /var/www/html/kmh/data/adam/forecast.sioux_falls.csv`;
@header = split("	", $header);
@models = grep(/_1$/, @header);
printf STDERR "Found %d models.\n", $#models + 1;

foreach $model (@models) {
    $model =~ s/_1/_/g;
    @matches = grep(/$model/, @header);
# registerSiteModel(&fci->allSiteInfo[fci->numSites], "ncep_HRRR_DSWRF_", 15);
    @elts = split("_", $matches[-1]);
    $lastHour = $elts[-1];
    printf STDERR "registerSiteModel(&fci->allSiteInfo[fci->numSites], \"$model\", $lastHour);\n";
}
