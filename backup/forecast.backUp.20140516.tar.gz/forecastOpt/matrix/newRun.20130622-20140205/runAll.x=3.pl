#!/usr/bin/perl
$startRow = 0;
$endRow = 11;
#@sites = ('goodwin_creek', 'desert_rock');
@sites = ('hanford', 'goodwin_creek', 'penn_state', 'desert_rock');
$divisions = 7;

@rows = ($startRow..$endRow);
#@rows = (0,1,3,11);
#@rows = (1,9,11);
#@rows = (0..11);

$forecastSourceDir = "/var/www/html/kmh/data/adam";
#$forecastSourceDir = "/var/www/html/kmh/data/adam/pre.fin.gfs.ndfd";
#$forecastSourceDir = "/home/jim/matrix/run/forecastTableFix";

$beginDate = '2013062200';
$endDate   = '2014020500';

#for($row=$startRow;$row<=$endRow;$row++) {
foreach $row (@rows) {
   # x=1
   # if row==0, do HA-only on all hours
   if($row == 0 || $row == 11) {
        $HA_range = "0,37";
   } else {
	$HA_range = "16,37";
   }

   $outDirHas = sprintf "./output.row=%d.x=3.HAS", $row;
   `/bin/rm -rf $outDirHas`;
   `mkdir $outDirHas`;
   $outDirHaOnly = sprintf "./output.row=%d.x=3.HA-only", $row;
   `/bin/rm -rf $outDirHaOnly`;
   `mkdir $outDirHaOnly`;

   $confFile = sprintf "../conf/dev_test.%dx.conf", $row;
   if(! -e $confFile) {
	die "Couldn't find file $confFile";
   }

   foreach $site (@sites) {

     # output.composite.3.1_HA-only/MultiSite-sites=4.modelMix.HA.csv
     # output.composite.3.1_HAS/MultiSite-sites=4.modelMix.HA_HAS.csv
     
     if($row > 0 && $row < 11) {
	$weightsFileHas = sprintf "./output.composite.row=%d.x=2.HAS/MultiSite-sites=4.modelMix.HA_HAS.csv", $row;
	if(! -e $weightsFileHas) {
		die "No such file: $weightsFileHas";
	}
        $outfile = sprintf "log.$site.row=%02d.x=3.HAS.txt", $row;
   	$comm = "./forecastOpt -t -b $divisions -a $beginDate,$endDate -c $confFile -o $outDirHas -w $weightsFileHas $forecastSourceDir/forecast.$site.csv >& $outfile";
        print "$comm\n";
	`$comm`;
     }

     $weightsFileHaOnly = sprintf "./output.composite.row=%d.x=2.HA-only/MultiSite-sites=4.modelMix.HA.csv", $row;
     if(! -e $weightsFileHaOnly) {
		die "No such file: $weightsFileHaOnly";
     }
     $outfile = sprintf "log.$site.row=%02d.x=3.HA.txt", $row;
     $comm = "./forecastOpt -t -b $divisions -a $beginDate,$endDate -c $confFile -o $outDirHaOnly -w $weightsFileHaOnly $forecastSourceDir/forecast.$site.csv >& $outfile";
     print "$comm\n";
     `$comm`;
  }
}
