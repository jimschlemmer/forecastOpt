#!/usr/bin/perl
$startRow = 0;
$endRow = 11;
#$startRow = 1;
#$endRow = 1;
#$endRow = 1;
$divisions = 7;

$forecastSourceDir = "/var/www/html/kmh/data/adam";
#$forecastSourceDir = "/var/www/html/kmh/data/adam/pre.fin.gfs.ndfd";
#$forecastSourceDir = "/home/jim/matrix/run/forecastTableFix";

print STDERR ">>> Using sources from $forecastSourceDir\n\n";

$beginDate = '2013062200';
$endDate   = '2014020500';

$inputComposite = "forecast.composite.csv";
`cat $forecastSourceDir/{forecast.penn_state.csv,forecast.goodwin_creek.csv,forecast.desert_rock.csv,forecast.hanford.csv} > $inputComposite`;

for($row=$startRow;$row<=$endRow;$row++) {
   # x=1
   # if row==0, do HA-only on all hours
   $doHAS = ($row > 0 && $row < 11);
   if($doHAS) {
	$HA_range = "16,37";
   }
   else {
        $HA_range = "0,37";
   }

   $outDirHas = sprintf "./output.composite.row=%d.x=2.HAS", $row;
   `/bin/rm -rf $outDirHas`;
   `mkdir $outDirHas`;
   $outDirHaOnly = sprintf "./output.composite.row=%d.x=2.HA-only", $row;
   `/bin/rm -rf $outDirHaOnly`;
   `mkdir $outDirHaOnly`;

   $confFile = sprintf "../conf/dev_test.%dx.conf", $row;

   if(! -e $confFile) {
	die "Couldn't find file $confFile";
   }

   if($doHAS) {
        $outfile = sprintf "log.composite.row=%02d.x=2.HAS.txt", $row;
   	$comm = "./forecastOpt -t -b $divisions -s 16 -m -a $beginDate,$endDate -c $confFile -o $outDirHas $inputComposite >& $outfile";
        print "$comm\n";
	`$comm`;
   }
   $outfile = sprintf "log.composite.row=%02d.x=2.HA.txt", $row;
   $comm = "./forecastOpt -t -b $divisions -r $HA_range -m -a $beginDate,$endDate -c $confFile -o $outDirHaOnly $inputComposite >& $outfile";
   print "$comm\n";
   `$comm`;
}
