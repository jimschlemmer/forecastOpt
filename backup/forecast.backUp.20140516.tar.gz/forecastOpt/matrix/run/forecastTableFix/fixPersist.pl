#!/usr/bin/perl
#
$forecastInDir = '/var/www/html/kmh/data/adam';

#/var/www/html/kmh/data/adam/forecast.desert_rock.csv
#/var/www/html/kmh/data/adam/forecast.goodwin_creek.csv
#/var/www/html/kmh/data/adam/forecast.hanford.csv
#/var/www/html/kmh/data/adam/forecast.penn_state.csv

@sites = ('desert_rock', 'goodwin_creek', 'hanford', 'penn_state');

$cols = q{
0 siteGroup
1 siteName
2 lat
3 lon
4 valid_time
5 sr_zen
6 sr_global
sr_direct
sr_diffuse
sr_temp
sr_wspd
sr_rh
lat
lon
validTime
sat_ghi
16 clear_ghi
CosSolarZenithAngle
ncep_RAP_DSWRF_1
ncep_HRRR_DSWRF_1
ncep_HRRR_LCDC_1
ncep_HRRR_HCDC_1
ncep_HRRR_TCDC_1
ncep_HRRR_MCDC_1
24 persistence_1
};

foreach $site (@sites) {
	$forecastFile = "forecast.$site.csv";
	$infile = "$forecastInDir/$forecastFile";
	print STDERR "reprocessing $infile\n";

	open(OUT, ">$forecastFile");
	open(DEBUG, ">debug.$forecastFile");
	print DEBUG "#dateTime,groundGHI,clearSky,last_kt,persistence_1\n";

	# p(h) = kt(h-1) * clr(h);
	open(IN, "<$infile");
	@in = <IN>;

	print OUT shift @in;  # copy header

	$ktLast = 1.0;
	$lineCount = 0;
	foreach $l (@in) {
		#chomp $l;
		@vals = split /\t/, $l;
		if($#vals < 1000) {
			printf STDERR "Got bad line:$lineCount with only %d values\n", $#vals+1;
			die "bye";
		}
		$ghi = $vals[6];
		$clr = $vals[16];
		if($ghi > 10) {
			$vals[24] = $ktLast * $clr;
		}
		printf OUT "%s", join("\t", @vals);
		printf DEBUG "%s\t%.2f\t%.2f\t%.4f\t%.2f\n", $vals[4], $vals[6], $vals[16], $ktLast, $vals[24];
		if($clr > 10 && $ghi > 10) {
			if($ghi > ($clr * 1.05)) {
				$ktLast = 1.05;
			} else {
				$ktLast = $ghi/$clr;
			}
		}
		$lineCount++;
	}

	close(OUT);
	close(DEBUG);
}
