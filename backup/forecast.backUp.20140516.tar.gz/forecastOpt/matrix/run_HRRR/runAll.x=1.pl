#!/usr/bin/perl
$startRow = 0;
$endRow = 11;
@sites = ('hanford', 'goodwin_creek', 'penn_state', 'desert_rock');
#@sites = ('desert_rock');
$divisions = 7;

@rows = ($startRow..$endRow);

$forecastSourceDir = "/var/www/html/kmh/data/adam";
#$forecastSourceDir = "/var/www/html/kmh/data/adam/pre.fin.gfs.ndfd";
#$forecastSourceDir = "/home/jim/matrix/run/forecastTableFix";

print STDERR ">>> Using sources from $forecastSourceDir\n\n";

#for($row=$startRow;$row<=$endRow;$row++) {
foreach $row (@rows) {
   # x=1
   # if row==0, do HA-only on all hours
   if($row == 0 || $row == 11) {
        $HA_range = "0,37";
   } else {
	$HA_range = "16,37";
   }

   $outDirHas = sprintf "./output.row=%d.x=1.HAS", $row;
   `/bin/rm -rf $outDirHas`;
   `mkdir $outDirHas`;
   $outDirHaOnly = sprintf "./output.row=%d.x=1.HA-only", $row;
   `/bin/rm -rf $outDirHaOnly`;
   `mkdir $outDirHaOnly`;

   $confFile = sprintf "../conf/conf_HRRR/dev_test.%dx.conf", $row;
   if(! -e $confFile) {
	die "Couldn't find file $confFile";
   }

   foreach $site (@sites) {
     if($row > 0 && $row < 11) {
        $outfile = sprintf "log.$site.row=%02d.x=1.HAS.txt", $row;
   	$comm = "./forecastOpt -t -b $divisions -s 16 -a 2013112000,2014041823 -c $confFile -o $outDirHas $forecastSourceDir/forecast.$site.csv >& $outfile";
        print "$comm\n";
	`$comm`;
     }
     $outfile = sprintf "log.$site.row=%02d.x=1.HA.txt", $row;
     $comm = "./forecastOpt -t -b $divisions -r $HA_range -a 2013112000,2014041823 -c $confFile -o $outDirHaOnly $forecastSourceDir/forecast.$site.csv >& $outfile";
     print "$comm\n";
     `$comm`;
  }
}
