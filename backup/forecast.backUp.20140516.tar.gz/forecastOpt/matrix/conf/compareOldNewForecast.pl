#!/usr/bin/perl
#

$site = shift @ARGV;

$site = 'forecast.goodwin_creek.csv';
$oldDir = '/var/www/html/kmh/data/adam/pre.fin.gfs.ndfd';
$newDir = '/var/www/html/kmh/data/adam';

# -rw-rw-r--.  1 kmh kmh 37259195 May  9 07:56 forecast.goodwin_creek.csv

$comm = "grabCols.pl persistence_126 $oldDir/$site ";
print STDERR "$comm\n";
@oldMeas = split /\n/, `$comm`;
$comm = "grabCols.pl persistence_126 $newDir/$site ";
print STDERR "$comm\n";
@newMeas = split /\n/, `$comm`;

for($i=0; $i<=$#oldMeas; $i++) {
	$oldLine = $oldMeas[$i];
	$newLine = $newMeas[$i];
	if($oldLine ne $newLine) {
		print STDERR "old: $oldLine\n";
		print STDERR "new: $newLine\n";
	}
}
