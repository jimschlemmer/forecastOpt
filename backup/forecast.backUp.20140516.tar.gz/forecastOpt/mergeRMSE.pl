#!/usr/bin/perl

@sites = ('Desert_Rock_NV', 'Goodwin_Creek_MS', 'Penn_State_PA', 'Hanford_CA');

chdir("HAS/new-test");
`filter`;
chdir("../..");

foreach $site (@sites) {
   $HA_file = `ls non-HAS/new-test7/output/forecastSummary.$site.*.csv`;
   chomp($HA_file);
   # HAS/desert_rock.HAS.results.csv
   $HAS_file = "HAS/new-test/$site.HAS.results.csv";

   if(! -e $HA_file || -z $HA_file) { die "couldn't find $HA_file"; }
   if(! -e $HAS_file || -z $HAS_file) { die "couldn't find $HAS_file"; }

   @HA_data  = split /\n/, `cut -d',' -f1,2,3,5,13,19,25,31,37,43,49,55,61,67 $HA_file`;
   @HAS_data = split /\n/, `cat $HAS_file`;

# HA:
# #site=Desert_Rock_NV lat=36.630 lon=-116.020 divisions=7 start date=20130622.000000end date=20140205.000000
# #hoursAhead,group N,sat RMSE,p1RMSE,p2RMSE,p1SumWts calls,p1RMSE calls,p2SumWts calls,p2RMSE calls,ncep_RAP_DSWRF model, ncep_RAP_DSWRF status,ncep_RAP_DSWRF N,ncep_RAP_DSWRF RMSE,ncep_RAP_DSWRF weight 1,ncep_RAP_DSWRF weight 2,persistence model, persistence status,persistence N,persistence RMSE,persistence weight 1,persistence weight 2,ncep_NAM_hires_DSWRF_inst model, ncep_NAM_hires_DSWRF_inst status,ncep_NAM_hires_DSWRF_inst N,ncep_NAM_hires_DSWRF_inst RMSE,ncep_NAM_hires_DSWRF_inst weight 1,ncep_NAM_hires_DSWRF_inst weight 2,ncep_NAM_DSWRF model, ncep_NAM_DSWRF status,ncep_NAM_DSWRF N,ncep_NAM_DSWRF RMSE,ncep_NAM_DSWRF weight 1,ncep_NAM_DSWRF weight 2,ncep_GFS_sfc_DSWRF_surface_avg model, ncep_GFS_sfc_DSWRF_surface_avg status,ncep_GFS_sfc_DSWRF_surface_avg N,ncep_GFS_sfc_DSWRF_surface_avg RMSE,ncep_GFS_sfc_DSWRF_surface_avg weight 1,ncep_GFS_sfc_DSWRF_surface_avg weight 2,ncep_GFS_sfc_DSWRF_surface_inst model, ncep_GFS_sfc_DSWRF_surface_inst status,ncep_GFS_sfc_DSWRF_surface_inst N,ncep_GFS_sfc_DSWRF_surface_inst RMSE,ncep_GFS_sfc_DSWRF_surface_inst weight 1,ncep_GFS_sfc_DSWRF_surface_inst weight 2,ncep_GFS_DSWRF model, ncep_GFS_DSWRF status,ncep_GFS_DSWRF N,ncep_GFS_DSWRF RMSE,ncep_GFS_DSWRF weight 1,ncep_GFS_DSWRF weight 2,NDFD_global model, NDFD_global status,NDFD_global N,NDFD_global RMSE,NDFD_global weight 1,NDFD_global weight 2,cm model, cm status,cm N,cm RMSE,cm weight 1,cm weight 2,ecmwf_ghi model, ecmwf_ghi status,ecmwf_ghi N,ecmwf_ghi RMSE,ecmwf_ghi weight 1,ecmwf_ghi weight 2
#
#site=Hanford_CA lat=36.310 lon=-119.630 start date=20130622.000000end date=20140205.000000
#hoursAhead,phase 1 RMSE
#1,8.62
#2,10.06
#3,10.97
#4,10.47

# HAS:
# 1,=1..16 ,1530, sumModel_Ground_2=9187797.3, meanMeasuredGHI=506.8, RMSE=77.5, 15.29
# 2,=1..16 ,1524, sumModel_Ground_2=10346969.5, meanMeasuredGHI=510.2, RMSE=82.4, 16.15
# 3,=1..16 ,1520, sumModel_Ground_2=11207288.1, meanMeasuredGHI=511.7, RMSE=85.9, 16.78
# 4,=1..16 ,1476, sumModel_Ground_2=11314421.9, meanMeasuredGHI=515.0, RMSE=87.6, 17.00

   $header =  shift(@HA_data);
   $header2 = shift(@HA_data);
   $HA_ind = 0;

   open(MERGED, ">$site.RMSE.merged.HA_HAS.csv");
   print MERGED "#RMSE %error for HA-only and all HAS\n";
   print MERGED "$header\n";
   print MERGED "#hours ahead,Sat RMSE,HA-only RMSE,HAS 1..16 RMSE,N,\n";
   @headerParts = split(",", $header2);
   shift(@headerParts);
   shift(@headerParts);
   shift(@headerParts);
   shift(@headerParts);
   $modelHeader = join(",", @headerParts);
   print MERGED "$modelHeader\n";

   for($HAS_ind=0; $HAS_ind <= $#HAS_data; $HAS_ind++) {
        $line = $HAS_data[$HAS_ind];
	(@HAS_elts) = split(",", $line);
	$HAS_ha = $HAS_elts[0];
	$HAS_N = $HAS_elts[2];
	$HAS_RMSE = $HAS_elts[6];
	($HA_ha,$HA_N,$Sat_RMSE,$HA_RMSE,@modelsRMSE) = split(",", $HA_data[$HAS_ind]);
        
 	if($HAS_ha != $HA_ha) { die("problem with HA's getting out of synch for $HA_file and $HAS_file"); }
        #print MERGED "$HA_ha,$Sat_RMSE,$HA_RMSE,$HAS_RMSE,$HAS_N\n";
        printf MERGED "$HA_ha,%.1f,%.1f,%.1f,$HAS_N", $Sat_RMSE,$HA_RMSE,$HAS_RMSE;
        foreach $rmse (@modelsRMSE) {
            printf MERGED ",%.1f", $rmse;
	}
        printf MERGED "\n";
   }
   close MERGED;
}
