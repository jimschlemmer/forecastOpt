#!/usr/bin/perl

@sites = ('Desert_Rock_NV', 'Goodwin_Creek_MS', 'Penn_State_PA', 'Hanford_CA');

foreach $site (@sites) {
   $HA_file  = "non-HAS/output/$site.modelMix.HA.csv";
   $HAS_file = "HAS/output/$site.modelMix.HA_HAS.csv";
   if(! -e $HA_file || -z $HA_file) { die "couldn't find $HA_file"; }
   if(! -e $HAS_file || -z $HAS_file) { die "couldn't find $HAS_file"; }
   @HA_data  = split /\n/, `cat $HA_file`;
   @HAS_data = split /\n/, `cat $HAS_file`;
   shift(@HA_data);
   $header = shift(@HAS_data);
   $HA_ind = 0;
   ($HA_ha,@HA_rest) = split(",", $HA_data[$HA_ind]);
   open(MERGED, ">$site.modelMix.merged.HA_HAS.csv");
   print MERGED "#model mixes for $site HAS and HA-only\n";
   print MERGED "$header\n";
   for($HAS_ind=0; $HAS_ind <= $#HAS_data; $HAS_ind++) {
        $line = $HAS_data[$HAS_ind];
	($HAS_ha,$HAS_has,@HAS_rest) = split(",", $line);
 	if($HAS_ha > $HA_ha) {
		printf MERGED "$HA_ha,HA-only,%s\n", join(",", @HA_rest);
		$HA_ind++;
		($HA_ha,@HA_rest) = split(",", $HA_data[$HA_ind]);
	}
        print MERGED "$line\n";
   }
   printf MERGED "$HA_ha,HA-only,%s\n", join(",", @HA_rest);
   close MERGED;
}

$info = q{
[sunspot]:/home/jim/mom/forecastOpt/non-HAS/output> m *modelMix*
::::::::::::::
Desert_Rock_NV.modelMix.HA.csv
::::::::::::::
HA,ncep_RAP_DSWRF,ncep_NAM_hires_DSWRF_inst,ncep_NAM_DSWRF,ncep_GFS_sfc_DSWRF_surface_avg,ncep_GFS_sfc_DSWRF_surface_inst,ncep
_GFS_DSWRF,NDFD_global,cm,ecmwf_ghi,N
1,0,0,10,0,10,0,20,60,0,1530

[sunspot]:/home/jim/mom/forecastOpt> m HAS/output/Des*Mix*
HA,HAS,ncep_RAP_DSWRF,ncep_NAM_hires_DSWRF_inst,ncep_NAM_DSWRF,ncep_GFS_sfc_DSWRF_surface_avg,ncep_GFS_sfc_DSWRF_surface_inst,
ncep_GFS_DSWRF,NDFD_global,cm,ecmwf_ghi,N
1,1,10,0,20,0,70,0,0,0,0,63
1,2,0,0,10,0,30,0,30,30,0,128
1,3,0,0,0,0,10,0,20,60,10,127
1,4,0,10,20,0,0,0,10,20,40,125
1,5,0,0,10,0,0,0,0,40,50,129
1,6,10,20,0,0,0,0,20,50,0,126
1,7,0,10,10,0,0,0,10,40,30,125
1,8,0,0,20,0,10,0,20,50,0,130
1,9,0,0,10,0,10,0,20,60,0,129
1,10,0,0,30,0,0,0,0,50,20,124
1,11,0,0,20,0,0,0,0,70,10,100
1,12,0,0,0,10,20,0,10,50,10,103
1,13,0,0,0,0,10,0,20,40,30,70
1,14,0,0,0,0,10,0,10,80,0,51
2,1,10,0,20,0,70,0,0,0,0,63
};
