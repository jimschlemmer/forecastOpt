#!/usr/bin/perl
#
my $dateTime = `date +'%Y%m%d_%T'`;
chomp($dateTime);

$eastLog = "./logs/cloudMotionModel.us-east.$dateTime.out";
$westLog = "./logs/cloudMotionModel.us-west.$dateTime.out";

`../fiveHourPrediction_H.out us-west-v3 ./us-west-hourly-cloudmotion.conf >& $westLog &`;
`../fiveHourPrediction_H.out us-east-v3 ./us-east-hourly-cloudmotion.conf >& $eastLog &`;

#/home/jim/satmod/vers3/newSat/satDirect -c us-east-hourly-cloudmodel-direct.conf
#./fiveHourPrediction_H.out us-west us-west-hourly-cloudmotion.conf
#/home/jim/satmod/vers3/newSat/satDirect -c us-west-hourly-cloudmodel-direct.conf
#./fiveHourPrediction.out hawaii hawaii-hourly-cloudmotion.conf
#/home/jim/satmod/vers3/newSat/satDirect -c us-hawaii-hourly-cloudmodel-direct.conf

