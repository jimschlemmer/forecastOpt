select min(ref_time),max(ref_time),area,model,element,count(*) from grid_files_cm where element='global_irrad' or element='IR-4_Kt' group by area,model,element;
