#include "time.h"
#include <cstring>
#include <string>

struct TPoint
{

  int  x;
  int  y;
};

struct TSite
{
  float  x;
  float  y;
  float val;
  float av_val;
  float cl_val;
  int count;
  char* name;
  int latpix;
  int lonpix;
  float wind_pr_SN;
  float wind_pr_WE;
	float wind_ne_SN;
  float wind_ne_WE;
	float distance;
	float D_time;
	float mean;
	float vari;
	float cov;
	float corr;
	time_t time;
};

struct TData
{
float kt;
float kb;
float std;
};

struct TData_prep
{
int year;
int month;
int day;
int hour;
int min;
int sec;
double glAv;
double glCl;
double bAv;
double bCl;
double wSpd;
double wDir;
time_t time;
};

struct TSite_prep{
		float x_s;
		float y_s;
		time_t time;
		int doy;
		int year;
		int month;
		int mday;
		int hour;
		int min;
		int sec;
		
		float glAv;
		float bAv;
		float glCl;
		float bCl;
		float CIGL;
		float CIB;
		float D_GL;
		float D_B;
		time_t satTime;
		float satGl;

		float satB;
		float satKt;
		float satLat;
		float satLon;
		float windSN;
		float windWE;
		float windPix;
		float wSpd;
		float wDir;
		
		time_t time100m;
		float Kt100m;
		float Kb100m;
		float D_Kt100m;
		float D_Kb100m;
		
		time_t time500m;
		float Kt500m;
		float Kb500m;
		float D_Kt500m;
		float D_Kb500m;

		time_t time1k;
		float Kt1k;
		float Kb1k;
		float D_Kt1k;
		float D_Kb1k;
		
		time_t time2k;
		float Kt2k;
		float Kb2k;
		float D_Kt2k;
		float D_Kb2k;
		
		time_t time5k;
		float Kt5k;
		float Kb5k;
		float D_Kt5k;
		float D_Kb5k;
		
		time_t time10k;
		float Kt10k;
		float Kb10k;
		float D_Kt10k;
		float D_Kb10k;
		
		time_t time20k;
		float Kt20k;
		float Kb20k;
		float D_Kt20k;
		float D_Kb20k;
		
		time_t time50k;
		float Kt50k;
		float Kb50k;
		float D_Kt50k;
		float D_Kb50k;
		
		time_t time100k;
		float Kt100k;
		float Kb100k;
		float D_Kt100k;
		float D_Kb100k;
		
		time_t time200k;
		float Kt200k;
		float Kb200k;
		float D_Kt200k;
		float D_Kb200k;
};

