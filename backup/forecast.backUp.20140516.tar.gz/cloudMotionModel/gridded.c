

/* new gridded satellite reader code -- 5/15/2006 -- js */
// NOT BACKWARD COMPATIBLE

// meant to work independently from satModel.h stuff so that programs can be
// written that operate on gridded files w/out all the stuff of satelliteType

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gridded.h"
#include "ioUtils.h"

#define FLOAT_TOL 0.01

int openReadGridfile(gridDataType *grid)
{

    if(grid->fileName == NULL) {
        //fprintf(stderr, "openReadGridfile: no grid filename to open.\n");
        return False;
    }
     
    if(grid->initDone != True)
        initGrid(grid);

    if ((grid->fp = fopen(grid->fileName, "rb")) == NULL) {
	//fprintf(stderr, "openReadGridfile: can't open '%s' file\n", grid->fileName);
	return False;
    }

//#define DUMPFIRST512
#ifdef DUMPFIRST512
    fprintf(stderr, "First 512 bytes of %s\n", grid->fileName);
    unsigned char buff[512];
    if (fread(buff, 512, 1, grid->fp) != 1) 
        exit(1);

    int i;
    for(i=0;i<512;i++) {
        fprintf(stderr, "%u ", buff[i]);
        if(i && !(i % 16))
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
    
    fseek(grid->fp, 0, SEEK_SET);
#endif

    // size_t gridHeadSize = sizeof(gridHeaderType);
    if (fread(&grid->hed, sizeof(gridHeaderType), 1, grid->fp) != 1) {
	//fprintf(stderr, "openReadGridfile: Can't read header from '%s'\n", grid->fileName);
	fclose(grid->fp);
	return False;
    }
 
    // are we trying to read a 32-bit file on a 64-bit machine?
    // note that this is a different issue from byte order
    if(grid->hed.is64bitFlag != GRID_64BIT_FLAG_VAL && is64bitArch()) {
        read32bitHeader(grid);
    }
    
    // take care of byte swapping in header here
    if(!checkHeaderSanity(grid)) 
        return False;

    // forget all the version check stuff for right now

    int retval = readGrid(grid);

    // finally, load struct tm 
    struct tm *tm = gmtime((time_t *) &grid->hed.obs_time);
    grid->tm = *tm;  // make a permanent copy

    fclose(grid->fp);  // make sure we leave the file closed

    return retval;
}

/* Byte Swapping Code -- used for reading files wrtten on a different architecture
   i.e., sparc => intel
 */
void byteSwap(unsigned char * b, int n)
{
   unsigned char tmp;
   void swap();
   int i = 0;
   int j = n-1;
   while (i<j)
   {
      tmp = b[i];
      b[i] = b[j];
      b[j] = tmp;
      i++, j--;
   }
}

void swap(unsigned char *a, unsigned char *b)
{
        unsigned char *tmp;

        *tmp = *a;
        *a = *b;
        *b = *tmp;
}


    /* the header is assumed to be in grid->hed already 
       we have to make assumptions about the size of 32bit data types here
       I will use what comes back from solaris 10
       Here's what we get:
        char = 1
        short = 2
        int = 4
        long = 4
        time_t = 4
        float = 4
        double = 8
       Now, on a 64bit intel redheat system:
        char = 1
        short = 2
        int = 4
        long = 8
        time_t = 8
        float = 4
        double = 8

    And the header:
     
    char	version[8];
    time_t	obs_time, arch_time;
    double	grid_size_deg, minlat, maxlat, minlon, maxlon;
    data_t	data_type;
    int		bytes_element;
    char	description[64];
    double      is64bitFlag;
    */

void read32bitHeader(gridDataType *grid)
{    
    // the upshot is that only time_t and long have changed size
    unsigned char buff[GRID_HEADER_SIZE], *ptr;
    int i;
    
    ptr = (unsigned char *) &grid->hed;
    
    for(i=0;i<sizeof(gridHeaderType); i++) {
        buff[i] = ptr[i];
        ptr[i] = 0;  // backfill with nulls
    }

    int offset=0;
    memcpy(grid->hed.version, buff, 8); offset+=8;
    ptr = (unsigned char *) &grid->hed.obs_time;
    memcpy(ptr, buff+offset, 4);        offset+=4;
    ptr = (unsigned char *) &grid->hed.arch_time;
    memcpy(ptr, buff+offset, 4);        offset+=4;    
    ptr = (unsigned char *) &grid->hed.grid_size_deg;
    memcpy(ptr, buff+offset, 8);        offset+=8;        
    ptr = (unsigned char *) &grid->hed.minlat;
    memcpy(ptr, buff+offset, 8);        offset+=8; 
    ptr = (unsigned char *) &grid->hed.maxlat;
    memcpy(ptr, buff+offset, 8);        offset+=8;  
    ptr = (unsigned char *) &grid->hed.minlon;
    memcpy(ptr, buff+offset, 8);        offset+=8;  
    ptr = (unsigned char *) &grid->hed.maxlon;
    memcpy(ptr, buff+offset, 8);        offset+=8;
    ptr = (unsigned char *) &grid->hed.data_type;
    memcpy(ptr, buff+offset, 4);        offset+=4; 
    ptr = (unsigned char *) &grid->hed.bytes_element;
    memcpy(ptr, buff+offset, 4);        offset+=4; 
    memcpy(grid->hed.description, buff+offset, 64);        offset+=64;
    ptr = (unsigned char *) &grid->hed.is64bitFlag;
    memcpy(ptr, buff+offset, 8); 

}
int isBigEndian(void)
{
    int i = 1;
    char *p = (char *)&i;    
    
    // under big endian, i => 0x 0x 0x 1x
    // under little end, i => 1x 0x 0x 0x
    
    if(p[0] == 1)
        return False;
    
    return True;
}

int is64bitArch(void)
{
    return(sizeof(char *) == 8);
}

/* Byte Swapping Code */

int checkHeaderSanity(gridDataType *grid)
{
    int retVal = True;
//    char errMsg[4096] = {'\0'};
    
    // first we assume that bad header values are due to byte order 
    if( (grid->hed.bytes_element < 1 || grid->hed.bytes_element > 16) &&
          (grid->hed.grid_size_deg < 0.001 || grid->hed.grid_size_deg > 100) ) {
        grid->swapByteOrder = True;
        swapHeaderBytes(grid);       
    }
    
    // often double garbage are very small numbers which wouldn't be caught by tests like these
    if(grid->hed.minlat < -90 || grid->hed.minlat > 90) {
        fprintf(stderr, "Header looks funny in %s: minlat = %.2f\n", grid->fileName, grid->hed.minlat);
        retVal = False;
    }
    if(grid->hed.maxlat < -90 || grid->hed.maxlat > 90) {
        fprintf(stderr, "Header looks funny in %s: maxlat = %.2f\n", grid->fileName, grid->hed.maxlat);
        retVal = False;
    }
    if(grid->hed.minlon < -180 || grid->hed.minlon > 180) {
        fprintf(stderr, "Header looks funny in %s: minlon = %.2f\n", grid->fileName, grid->hed.minlon);
        retVal = False;
    }
    if(grid->hed.maxlon < -180 || grid->hed.maxlon > 180) {
        fprintf(stderr, "Header looks funny in %s: maxlon = %.2f\n", grid->fileName, grid->hed.maxlon);
        retVal = False;
    }    
    if(grid->hed.grid_size_deg < 0.001 || grid->hed.grid_size_deg > 100) {
        fprintf(stderr, "Header looks funny in %s: grid_size_deg = %.3f\n", grid->fileName, grid->hed.grid_size_deg);
        retVal = False;
    }    
    if(grid->hed.bytes_element < 1 || grid->hed.bytes_element > 16) {
        fprintf(stderr, "Header looks funny in %s: bytes_element = %.3f\n", grid->fileName, grid->hed.bytes_element);
        retVal = False;
    }    
    
    return retVal;
}

    // this swapping requires intimate knowledge of the header
    /*
    char	version[8];
    time_t	obs_time, arch_time;
    double	grid_size_deg, minlat, maxlat, minlon, maxlon;
    data_t	data_type;
    int		bytes_element;
    char	description[64];
     */

void swapHeaderBytes(gridDataType *grid)
{
    byteSwap((unsigned char *) &grid->hed.obs_time, 4);
    byteSwap((unsigned char *) &grid->hed.arch_time, 4);
    byteSwap((unsigned char *) &grid->hed.grid_size_deg, 8);
    byteSwap((unsigned char *) &grid->hed.minlat, 8);
    byteSwap((unsigned char *) &grid->hed.maxlat, 8);
    byteSwap((unsigned char *) &grid->hed.minlon, 8);
    byteSwap((unsigned char *) &grid->hed.maxlon, 8);
    byteSwap((unsigned char *) &grid->hed.data_type, 4);
    byteSwap((unsigned char *) &grid->hed.bytes_element, 4);
    
}

void swapByteOrderLine(unsigned char *line, int length, int size)
{
    int i;
    for(i=0; i<length; i++)
        byteSwap(line+(i*size), size);
}

int openReadArchiveSnowGridfile(gridDataType *grid)
{
    char 	hed[16];
    archSnowGridHeaderType 	*v0_hed;
   
    if(grid->fileName == NULL) {
        fprintf(stderr, "openReadGridfile: no grid filename to open.\n");
        return False;
    }
     
    if(grid->initDone != True) {
        initGrid(grid);
        grid->gridHeaderSize = 16;  // this is just what it is, man
    }

    if ((grid->fp = fopen(grid->fileName, "rb")) == NULL) {
	fprintf(stderr, "openReadGridfile: can't open '%s' file\n", grid->fileName);
	return False;
    }

//#define DUMPFIRST512
#ifdef DUMPFIRST512
    fprintf(stderr, "First 512 bytes of %s\n", grid->fileName);
    unsigned char buff[512];
    if (fread(buff, 512, 1, grid->fp) != 1) 
        exit(1);

    int i;
    for(i=0;i<512;i++) {
        fprintf(stderr, "%u ", buff[i]);
        if(i && !(i % 16))
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
    
    fseek(grid->fp, 0, SEEK_SET);
#endif

   if (fread(hed, 16, 1, grid->fp) != 1) {
      fprintf(stderr,"openReadArchiveSnowGridfile(): Can't read grid file %s header\n", grid->fileName);
      fclose(grid->fp);
      return False;
   }

   v0_hed = (archSnowGridHeaderType *) hed;

   // first check for 32bit binary read on 64bit machine and swap integer bytes if so
   if(is64bitArch() && (v0_hed->nc < 1 || v0_hed->nc > 2000 || v0_hed->ullat > 900 || v0_hed->ullat < -900)) {
       byteSwap((unsigned char *) &v0_hed->ullon, 4);
       byteSwap((unsigned char *) &v0_hed->ullat, 4);
       byteSwap((unsigned char *) &v0_hed->nc, 4);
       byteSwap((unsigned char *) &v0_hed->alen, 4);
       grid->swapByteOrder = True;  // for snow we don't actually have to do this since it's 1 byte data
   }

   /*
typedef struct {
    char	version[8];
    time_t	obs_time, arch_time;
    double	grid_size_deg, minlat, maxlat, minlon, maxlon;
    data_t	data_type;
    int		bytes_element;
    char	description[64];
} gridHeaderType;
*/
   
    // I think that the snow data that comes in is converted into grids without regard to the 
    // whole shift-to-the-southwest thing.  Thus we compensate for the shift that will take
    // place within readGrid() by adding 0.05 to the maxlat and -0.05 to the minlon.
   grid->hed.maxlat = (double) v0_hed->ullat/10.0  + 0.05;  // gotta go with the hardcoded deals
   grid->hed.minlon = -v0_hed->ullon/10.0  - 0.05;
   // how it used to be:
   // grid->hed.maxlat = (double) v0_hed->ullat/10.0; //  - 0.05;  // gotta go with the hardcoded deals
   // grid->hed.minlon = -v0_hed->ullon/10.0; //  + 0.05;
   
   grid->cols = v0_hed->nc;
   grid->rows = v0_hed->alen/grid->cols;
   grid->hed.minlat 	= grid->hed.maxlat - grid->rows * 0.1; 
   grid->hed.maxlon	= grid->hed.minlon + grid->cols * 0.1;
   grid->hed.data_type   = Unsigned_Char;
   grid->hed.bytes_element = 1;
   grid->hed.grid_size_deg = 0.1;
   sprintf(grid->hed.description, "Archive grid file (converted non-standard header)");
   grid->hed.obs_time = 0;

   // we now set this switch so that snow data can be "extended" outside the boundaries of the satellite
   // data.  This was necessary when we discovered that the snow data maps didn't extend far enough south
   // to cover all of Florida.  The actual value for the missing snow data will have to be set elsewhere
   // and the code there will have to handle checking for points outside the snow data bounds.
   grid->allowPtsOutsideBounds = True;
   
   if(!readGrid(grid))
       return False;
   
    // finally, load struct tm 
   struct tm *tm = gmtime((time_t *) &grid->hed.obs_time);
   grid->tm = *tm;  // make a permanent copy
   fclose(grid->fp);

   return True;
}

// for when we just want to peak at the header data
int openReadHeadGridfile(gridDataType *grid)
{

    if(grid->fileName == NULL) {
        fprintf(stderr, "openReadHeadGridfile: no grid filename to open.\n");
        return False;
    }
    
    if(grid->initDone != True)
        initGrid(grid);
     
    if ((grid->fp = fopen(grid->fileName, "rb")) == NULL) {
	fprintf(stderr, "openReadHeadGridfile: can't open '%s' file\n", grid->fileName);
	return False;
    }

    if (fread(&grid->hed, sizeof(gridHeaderType), 1, grid->fp) != 1) {
	fprintf(stderr, "openReadGridfile: Can't read header from '%s'\n", grid->fileName);
	fclose(grid->fp);
	return False;
    }
    
     // are we trying to read a 32-bit file on a 64-bit machine?
    // note that this is a different issue from byte order
    if(grid->hed.is64bitFlag != GRID_64BIT_FLAG_VAL && is64bitArch()) {
        read32bitHeader(grid);
    }
    
    // take care of byte swapping in header here
    if(!checkHeaderSanity(grid)) 
        return False;
    
    // finally, load struct tm 
    struct tm *tm = gmtime((time_t *) &grid->hed.obs_time);
    grid->tm = *tm;  // make a permanent copy

    grid->rows = (int) ((grid->hed.maxlat - grid->hed.minlat)/grid->hed.grid_size_deg + 0.5);
    grid->cols = (int) ((grid->hed.maxlon - grid->hed.minlon)/grid->hed.grid_size_deg + 0.5);
    grid->gridRes = 0.5 * grid->hed.grid_size_deg;  // half grid resolution 
    
    fclose(grid->fp);
    return True;
}

// function that acutally does the low level read of the grid file, along with all the data
// interpretation that goes on.

// Be smart about memory usage -- we're going to recycle the grid->data section so that it
// merely grows (if necessary) between readings of grid files

int readGrid(gridDataType *grid)
{
    double	currLat, currLon;
    grid_t	*g=NULL;
    static char	*line=NULL;
    int		row,col, data_size;
    unsigned char   *uc;
    signed char     *sc;
    unsigned short  *us;
    signed short    *ss;
    unsigned int    *ui;
    signed int      *si;
    unsigned long   *ul;
    signed long     *sl;
    float           *fl;
    double          *du;
    
    /*
    The nature of the grid cell is a tad odd.
    In effect, the outer edges are shrunk in by half a gridsize.  This is due 
    to the fact that a satellite pixel is actually representative of an area and
    not a point.  

    Q: Why isn't it assumed to be in the center of the pixel?  
    A: must be explained by upstream processing.
    
    Here is a depiction of a grid cell:
    
     lon + gridsize/2
       |
       |
    X------
    |  |  |
    |  +--|--- lat - gridsize/2
    |     |
    -------    
    
    where X = [lat,lon] as calculated from grid header
          + = grid centered location
    
    Consider what this means for the four corners of a 0.1 degree grid:
        upper left : [maxlat-0.05, minlon+0.05]
        upper right: [maxlat-0.05, maxlon-0.05]
        lower left : [minlat+0.05, minlon+0.05]
        lower right: [minlat+0.05, maxlon-0.05]

    The header values hed.minlat, hed.maxlat, hed.minlon, hed.maxlon contain 
    values that are *not* centered -- that is they are like X, above.
    
    */
        
    // this should work whether we've done the centered business or not
    grid->rows = (int) ((grid->hed.maxlat - grid->hed.minlat)/grid->hed.grid_size_deg + 0.5);
    grid->cols = (int) ((grid->hed.maxlon - grid->hed.minlon)/grid->hed.grid_size_deg + 0.5);

    // gridRes is the centered distance -- half the cell dimension
    grid->gridRes = 0.5 * grid->hed.grid_size_deg;  // half grid resolution 

    // figure "centered" grid boundaries -- i.e., shift upper left point to the SE, lower right point to the NW
    grid->maxLat = grid->hed.maxlat - grid->gridRes;  
    grid->minLat = grid->hed.minlat + grid->gridRes;  
    grid->minLon = grid->hed.minlon + grid->gridRes;
    grid->maxLon = grid->hed.maxlon - grid->gridRes;

    // gridRes is the centered distance -- half the cell dimension
    grid->gridRes = 0.5 * grid->hed.grid_size_deg;  // half grid resolution 

    // simple check for valid file
//    data_size = grid->hed.bytes_element * grid->rows * grid->cols;    
//    if (fileSize(grid->fp) != (grid->gridHeaderSize + data_size)) {
//	fprintf(stderr, "readGrid: file size seems wrong in %s\n\tgot: %d bytes from O/S, : %d header + %d data = %d total bytes\n", 
//            grid->fileName, fileSize(grid->fp), grid->gridHeaderSize, data_size, grid->gridHeaderSize + data_size);
//	return False;
//    }

    // if we're clipping, set the grid->hed parameters now

    /*
    In an effort to move beyond the whole gridRes, centered vs. not crappola, I'm going to require that
    when a sub window is requested that it is in actual centered coordinates.  
    
    Soon, I hope to be rid of the whole centered vs. not stuff altogether.  But that will involve a
    redefined grid file, which for now is not workable.
    */
    
    if(grid->doClip) {
        int errCount=0;
        
        // check bounds and modify hed variables
        if(grid->maxLat - grid->clipUpperLeftLat < -FLOAT_TOL) {
            if(grid->allowPtsOutsideBounds) 
                grid->clipUpperLeftLat = grid->maxLat;
            else {
                fprintf(stderr, "readGrid: clipping to upper left lat (%.2f) that is outside grid bounds (%.2f) for file %s\n", 
                    grid->clipUpperLeftLat, grid->maxLat, grid->fileName);
                errCount++;
            }
        }    
        
        if(grid->clipLowerRightLat - grid->minLat < -FLOAT_TOL) {  // see comments about missing frontiers, below
            if(grid->allowPtsOutsideBounds) 
                grid->clipLowerRightLat = grid->minLat;
            else {            
                fprintf(stderr, "readGrid: clipping to lower right lat (%.2f) that is outside grid bounds (%.2f) for file %s\n",
                    grid->clipLowerRightLat, grid->minLat, grid->fileName);
                errCount++;
            }
        }                
        
        if(grid->clipUpperLeftLon - grid->minLon < -FLOAT_TOL) {
            if(grid->allowPtsOutsideBounds) 
                grid->clipUpperLeftLon = grid->minLon;
            else {            
                fprintf(stderr, "readGrid: clipping to upper left lon (%.2f) that is outside grid bounds (%.2f) for file %s\n", 
                    grid->clipUpperLeftLon, grid->minLon, grid->fileName);
                errCount++;
            }
        }                
        
        if(grid->maxLon - grid->clipLowerRightLon < -FLOAT_TOL) { // see comments about missing frontiers, below
            if(grid->allowPtsOutsideBounds) 
                grid->clipLowerRightLon = grid->maxLon;
            else {            
                fprintf(stderr, "readGrid: clipping to lower right lon (%.2f) that is outside grid bounds (%.2f) for file %s\n", 
                    grid->clipLowerRightLon, grid->maxLon, grid->fileName);
                errCount++;
            }
        }            
        
        if(errCount) 
            return False;

	// otherwise set the boundaries to the clipped grid
        grid->minLon = grid->clipUpperLeftLon; 
        grid->maxLon = grid->clipLowerRightLon;
        grid->maxLat = grid->clipUpperLeftLat;
        grid->minLat = grid->clipLowerRightLat;
    }
    
    int bytes = grid->hed.bytes_element;
    // in doing all this index math we have to keep in mind that:
    //  o rows and cols are in terms of grid resolution (divide by grid_size_deg)
    //  o offsets need to be multplied by grid->hed.bytes_element
    
    double originalMaxlat = grid->hed.maxlat - grid->gridRes;
    double originalMinlon = grid->hed.minlon + grid->gridRes;
    
    // if we're not clipping, these should go to zero   
    grid->rowSkip =  grid->doClip ? (int)((originalMaxlat - grid->clipUpperLeftLat)/grid->hed.grid_size_deg + 0.5) : 0;
    grid->colSkip =  grid->doClip ? (int)((grid->clipUpperLeftLon - originalMinlon)/grid->hed.grid_size_deg + 0.5) : 0;
    grid->readRows = grid->doClip ? (int)((grid->clipUpperLeftLat - grid->clipLowerRightLat)/grid->hed.grid_size_deg + 1 + 0.5) : grid->rows;
    grid->readCols = grid->doClip ? (int)((grid->clipLowerRightLon - grid->clipUpperLeftLon)/grid->hed.grid_size_deg + 1 + 0.5) : grid->cols;
    
    // now we have to back these off if they're right on the borders (kludgey?)
    if(grid->readRows > grid->rows)
	grid->readRows = grid->rows;
    if(grid->readCols > grid->cols)
	grid->readCols = grid->cols;
    
    int colDiffBytes = (grid->cols - grid->readCols) * bytes;

    
    /*
    double startLon = (grid->doClip ? grid->clipUpperLeftLon - grid->gridRes : grid->hed.minlon);  // + gridRes?
    if(startLon >= grid->hed.maxlon)
        startLon = grid->hed.maxlon - grid->gridRes;
    
    double startLat = (grid->doClip ? grid->clipUpperLeftLat + grid->gridRes : grid->hed.maxlat);
    if(startLat <= grid->hed.minlat)
        startLat = grid->hed.minlat + grid->gridRes;
    */
    
    long skipTo = grid->gridHeaderSize + (grid->cols * grid->rowSkip * bytes) + grid->colSkip * bytes;
    
    // jump to the begining of the data section
    if(fseek(grid->fp, skipTo, SEEK_SET) == -1) {
        fprintf(stderr, "readGrid(): error trying to fseek to %d in grid file %s\n", skipTo, grid->fileName);
        return False;
    }
    
    /*
    fprintf(stderr, "cols=%d\nrows=%d\nreadCols=%d\nreadRows=%d\nrowSkip=%d\ncolSkip=%d\ncolDiffBytes=%d\nskipTo=%d\n",
        grid->cols, grid->rows, grid->readCols, grid->readRows, grid->rowSkip, grid->colSkip, colDiffBytes, skipTo);
    */
    
    // temporary space for reading the current line of a grid file.  From this line
    // the grid rows get filled in according the the data type of the grid file
    if((line = (char *) realloc(line, grid->readCols * bytes)) == NULL) {
	fprintf(stderr, "readGrid: file size seems wrong in %s\n", grid->fileName);
	return False;
    }
 
    // start reading
    // we begin in the upper left hand corner.  Ergo, we're at max latitude and min Longitude.
    // Longitude changes more quickly than latitude, so the 2D reference is grid->data[lat][lon]
        
    // important gridRes point here: the maxlon, minlon type variables are assumed *not* to have
    // the gridRes "centering" factor included.  Weird and confusng but true.  Furthermore, the 
    // gridRes is *subtracted* from minlat and maxlat and *added* to minlon and maxlon, thus implying
    // that the center of the gridRes x gridRes square is southeast of the given point.
    
    // This implies that the eastern and southern fronteirs don't exist.  This is correct.  For example
    // in a grid that goes from upperleft = [40,60] to lowerright = [21,78], there is a mapping from
    // [40,60] southwest to 39.95,60.05 but there is no such mapping for [21,78] since [20.95,78.05]
    // as that would be outside the grid.  Hey, I didn't design it.
    
    // make sure all the grid->data memory allocation is up to snuff this needs to be done after
    // grid->readCols and grid->readRows are calculated
    checkMemory(grid);
    
    // lat and lon are reported in "centered" coordinates
    double startLat = grid->maxLat;
    double startLon = grid->minLon;

    currLat = startLat;  // lat changes slowly
    for (row=0; row<grid->readRows; row++) {
                
        // read next row into temp memory
	if (fread(line, bytes, grid->readCols, grid->fp) != grid->readCols) {
	    fprintf(stderr, "openReadGridfile: read failed on line %d of gridded file %s\n", row+1, grid->fileName);
	    return False;
	}

        
	switch (grid->hed.data_type) {
            case Unsigned_Char:     uc = (unsigned char *) (void *) line; break;
            case Signed_Char:       sc = (signed char *) (void *) line; break;
            case Unsigned_Short:    us = (unsigned short *) (void *) line; break;
            case Signed_Short:      ss = (signed short *) (void *) line; break;
            case Unsigned_Int:      ui = (unsigned int *) (void *) line; break;
            case Signed_Int:        si = (signed int *) (void *) line; break;
            case Unsigned_Long:     ul = (unsigned long *) (void *) line; break;
            case Signed_Long:       sl = (signed long *) (void *) line; break;
            case Float:             fl = (float *) (void *) line; break;
            case Double:            du = (double *) (void *) line; break;
	}
        
        // if we're reading from 32bit machine data, swap byte order
        if(grid->swapByteOrder && grid->hed.bytes_element > 1)
            swapByteOrderLine((unsigned char *) line, grid->readCols, grid->hed.bytes_element);
        
        // see above note on gridRes
        currLon = startLon;  // lon changes quickly
        
	for (g=grid->data[row], col=0; col < grid->readCols; g++, col++) {
	    switch (grid->hed.data_type) {
                case Unsigned_Char:     g->value = *uc++; break;
                case Signed_Char:	g->value = *sc++; break;
                case Unsigned_Short:    g->value = *us++; break;
                case Signed_Short:	g->value = *ss++; break;
                case Unsigned_Int:	g->value = *ui++; break;
                case Signed_Int:	g->value = *si++; break;
                case Unsigned_Long:	g->value = *ul++; break;
                case Signed_Long:	g->value = *sl++; break;
                case Float:		g->value = *fl++; break;
                case Double:            g->value = *du++; break;
	    }

	    g->lat = currLat;
	    g->lon = currLon;

//            if(row == 50 && col == 50)
//                fprintf(stderr, "%s: pixel[50][50] : lat = %.2f  lon = %.2f  val = %.2f\n", grid->fileName, g->lat, g->lon, g->value);

	    currLon += grid->hed.grid_size_deg;
/*
printf("%d %d %.3f %.3f %.2f\n", i, j, g->lat, g->lon,
			g->value);
*/
	}

        if(colDiffBytes > 0)  // wrap around to the begining of the next row in the subwindow
		fseek(grid->fp, colDiffBytes, SEEK_CUR);
        
	currLat -= grid->hed.grid_size_deg;
    }

    return True;
}

// do all the memory checks:
// either allocate or reallocate the grid->data memory
// Things to consider:
//   - initially, we allocate everything (data == NULL)
//   - if the current (cols * bytes_element) is different from the (alloc.bytesPerRow) we need to realloc
//      the whole thing
//   - otherwise, if the number of rows has changed, realloc only the number of rows

int checkMemory(gridDataType *grid)
{
    int row;
    // first check to see if nothing's changed -- the most common case
    
    //fprintf(stderr, "checkMemory() : rows = %d, cols = %d, bytesize = %d, totalBytes = %d\n", 
    //	grid->rows, grid->cols, grid->hed.bytes_element, grid->alloc.totalBytes);

    // alloc.totalBytes is -1 initially so this fails the first time through
    if(grid->readRows * grid->readCols * grid->hed.bytes_element <= grid->alloc.totalBytes)
           return True;
    
    // first we have to allocate *data, then sweep through and allocate **data
    
    // rather than getting clever, we'll just realloc the whole works if anything has
    // changed.
    
    if(grid->carp == debug && grid->data == NULL) {
        fprintf(stderr, "checkMemory: initial grid->data memory allocation.\n");
    }
    
    // if we have to resize, free up first
    if(grid->data != NULL) {
            for (row=0; row<grid->readRows; row++)
                if(grid->data[row] != NULL)
                    free(grid->data[row]);
            free(grid->data);
    }
    
    if((grid->data = (grid_t **) calloc(grid->readRows, sizeof(grid_t *))) == NULL) {
        fprintf(stderr, "checkMemory: grid->data memory allocation failure while processing file %s\n", grid->fileName);
	return False;
    }
    
    // alloc all the columns
    for (row=0; row<grid->readRows; row++)
	if ((grid->data[row] = (grid_t *) malloc(sizeof(grid_t) * (grid->readCols))) == NULL) {
	    fprintf(stderr, "checkMemory: grid->data[] memory allocation failure while processing file %s\n", grid->fileName);
	    return False;
	}
    
    grid->alloc.totalBytes = grid->readRows * grid->readCols * grid->hed.bytes_element;
    
    return True;
}

// initialize the grid struct
// this is done automatically via openReadGridfile()
// and only needs to be done once -- the fileName field
// can be changed and the same struct (and all its allocated memory)
// can be recycled over and over.
void initGrid(gridDataType *grid) 
{ 
    // grid->fileName = NULL;  Ooops! this has to be passed
    grid->doClip = False;
    //grid->isShifted = False;
    grid->fp = NULL;
    grid->data = NULL;
    grid->rows = 0;
    grid->cols = 0;
    grid->alloc.totalBytes = -1;  // this keeps the first totalBytes check from passing in checkMemory()
    grid->alloc.bytesPerRow = 0;
    grid->alloc.numRows = 0;
    grid->alloc.reallocCount = 0;
    grid->gridHeaderSize = GRID_HEADER_SIZE;   // the standard grid header size 
    grid->byteOrder = little;   // assume linux
    grid->swapByteOrder = False;  // we only need to swap bytes if we're reading from a different arch.
    
    // don't init grid->carp as this should be set outside this module    
    
    grid->initDone = True;     // set initDone flag
    grid->carp = quiet;  // set it elsewhere if you want it on
}
        
void copyGridClipData(gridDataType *toGrid, gridDataType *fromGrid)
{
    toGrid->doClip = fromGrid->doClip;
    toGrid->clipUpperLeftLat = fromGrid->clipUpperLeftLat;
    toGrid->clipUpperLeftLon = fromGrid->clipUpperLeftLon;
    toGrid->clipLowerRightLat = fromGrid->clipLowerRightLat;
    toGrid->clipLowerRightLon = fromGrid->clipLowerRightLon;
}


// take a grid, lat & lon and look up the pixel offsets
// we assume here an exact match -- maybe this will need to be 
// relaxed in the future.
// anyway, return True on success, False if point lies outside the grid
//
// Modified to do clipped regions when doClip is True
int latlon2GridPix(gridDataType *grid, double lat, double lon, int *x, int *y)
{
    
    // we need to remember that the maxlat, minlon, etc. values are not "centered"
    // that is, they haven't had the gridRes added/subtracted from them yet.
    double minLat,minLon,maxLat,maxLon;
    
    /*
     * if(grid->doClip) {
        minLon = grid->clipUpperLeftLon; 
        maxLon = grid->clipLowerRightLon;
        maxLat = grid->clipUpperLeftLat;
        minLat = grid->clipLowerRightLat;
    }
    else {
        minLon = grid->hed.minlon + grid->gridRes; 
        maxLon = grid->hed.maxlon - grid->gridRes;
        maxLat = grid->hed.maxlat - grid->gridRes;
        minLat = grid->hed.minlat + grid->gridRes;
    }
    */
    
    if(lat < (grid->minLat - FLOAT_TOL) || 
       lat > (grid->maxLat + FLOAT_TOL) || 
       lon < (grid->minLon - FLOAT_TOL) || 
       lon > (grid->maxLon + FLOAT_TOL))  // outside the range of grid
        return False;
    
    *x = (int) ((lon - grid->minLon)/grid->hed.grid_size_deg + 0.5);
    *y = (int) ((grid->maxLat - lat)/grid->hed.grid_size_deg + 0.5);
    
#ifdef TEST_LATLON2GRID_DISABLED 
#define LATLON_FLOAT_TOL  0.001
    double latDiff = fabs(grid->data[*y][*x].lat - lat);
    double lonDiff = fabs(grid->data[*y][*x].lon - lon);
    if(latDiff > LATLON_FLOAT_TOL || lonDiff > LATLON_FLOAT_TOL) 
            fprintf(stderr, "latlon2GridPix(): input lat, lon != calculated pixel's lat, lon: (%.2f,%.2f) vs. (%.2f, %.2f) @ (%d, %d)\n",
                lat, lon, grid->data[*y][*x].lat, grid->data[*y][*x].lon, *x, *y);
#endif
            
    return True;
}
            


void dumpGrid(gridDataType *grid, int doCsv, int doPixCol, int quiet)
{
    int latpix, lonpix;
    char timeStr[GRID_HEADER_SIZE];   
    char s = doCsv ? ',' : ' ';
    double res = grid->gridRes;

    // grid->tm = gmtime((time_t *) &grid->hed.obs_time);
    strftime(timeStr, GRID_HEADER_SIZE, "%C", &grid->tm);

    if(!quiet) {
      fprintf(stderr, "dumping grid file: %s [%s]\n", grid->fileName, grid->hed.description);
      fprintf(stderr, "\tgrid dimensions = %d lat pts, %d lon pts\n", grid->rows, grid->cols);
      fprintf(stderr, "\tgrid resolution = %.1f\n\tupper left corner:\n\t\tlat = %.2f\n\t\tlon = %.2f\n\tlower right corner:\n\t\tlat = %.2f\n\t\tlon = %.2f\n",
        grid->hed.grid_size_deg, grid->hed.maxlat-res, grid->hed.minlon+res, grid->hed.minlat+res, grid->hed.maxlon-res);
      fprintf(stderr, "\tbytes per element = %d\n", grid->hed.bytes_element);
      if(grid->doClip) {
         fprintf(stderr, "\tclipped region dimensions = %d lat pts, %d lon pts\n", grid->readRows, grid->readCols);
         fprintf(stderr, "\t\tclipped min lat = %.2f\n\t\tclipped max lat = %.2f\n\t\tclipped min lon = %.2f\n\t\tclipped max lon = %.2f\n",
            grid->clipLowerRightLat, grid->clipUpperLeftLat, grid->clipUpperLeftLon, grid->clipLowerRightLon);       
      }
      fprintf(stderr, "\tobs_time = %ld [%s]\n", grid->hed.obs_time, timeStr);
    }
    
    double lat, lon;
    for(latpix=0; latpix<grid->readRows; latpix++) {
        for(lonpix=0; lonpix<grid->readCols; lonpix++) {
          lat = grid->data[latpix][lonpix].lat - grid->gridRes;
          lon = grid->data[latpix][lonpix].lon + grid->gridRes;
 	  if(doPixCol)
            fprintf(stdout, "%d%c%d%c%.2f%c%.2f%c%.3f\n", lonpix, s, latpix, s, lon, s, lat, s, grid->data[latpix][lonpix].value);
	  else
            fprintf(stdout, "%.2f%c%.2f%c%.3f\n", lon, s, lat, s, grid->data[latpix][lonpix].value);
        }
    }
}

void closeGridFile(gridDataType *grid)
{
    if(grid != NULL && grid->fp != NULL)
        fclose(grid->fp);
}

void freeGridData(gridDataType *grid)
{
    int i;
    
    if(grid == NULL || grid->data == NULL)
	return;

    for(i=0;i<grid->rows;i++)
        free(grid->data[i]);

    free(grid->data);

}

// you have to fill in the gridHeaderType *gridHead on these functions first

int gridWriteHeaderFloat(FILE *fp, gridHeaderType *gridHead)
{
   strncpy(gridHead->version, "unCor.v1", 8);
   gridHead->bytes_element = sizeof(float);
   gridHead->data_type = Float;
   return(gridWriteHeader(fp, gridHead));
}

 
int gridWriteHeaderDouble(FILE *fp, gridHeaderType *gridHead)
{
   strncpy(gridHead->version, "unCor.v1", 8);
   gridHead->bytes_element = sizeof(double);
   gridHead->data_type = Double;
   return(gridWriteHeader(fp, gridHead));
}
   
int gridWriteHeader(FILE *fp, gridHeaderType *gridHead)
{
   unsigned char headBuff[GRID_HEADER_SIZE] = {0};
    
   // set archive time
   gridHead->arch_time = time(NULL);
   
   // set 64bit flag
   if(is64bitArch())
    gridHead->is64bitFlag = GRID_64BIT_FLAG_VAL;
   else
    gridHead->is64bitFlag = 0;
     
   // backfill header with nulls
   memcpy(headBuff, (unsigned char *)gridHead, sizeof(gridHeaderType));
   
   // 256 is a convention for header size, I suppose
   fwrite((void *) headBuff, GRID_HEADER_SIZE, 1 , fp);

   return True;
}

int gridWriteDataFloat(FILE *fp, float **data, int rows, int cols)
{
 int latInd;
  
 // fprintf(stderr, "gridWRiteDataFloat(): writing %d rows x %d cols\n", rows, cols);

 for(latInd = 0; latInd < rows; latInd++) { // 0..180, for example
        if(fwrite(data[latInd],sizeof(float),cols,fp) != cols) {
	  fprintf(stderr, "Can't write output.\n");
	  return False;
	}
 }
 
 return True;
}

int gridWriteDataDouble(FILE *fp, double **data, int rows, int cols)
{
 int latInd;
  
 for(latInd = 0; latInd < rows; latInd++) { // 0..180, for example
        if(fwrite(data[latInd],sizeof(double),cols,fp) != cols) {
	  fprintf(stderr, "Can't write output.\n");
	  return False;
	}
 }
 
 return True;
}

int setGridSubwindow(gridDataType *grid, char *str)
{
 char *p=str,*q=str;
 // assume a string like 25.0,-70,17,-42
 // that is, upperLeftLat,upperLeftLon,lowerRtLat,lowerRtLon
    
 // upper left lat
 while(*p != ',' && *p) p++; 
 *p = '\0'; 
 grid->clipUpperLeftLat = atof(q);
 
 // upper left lon
 q = p = p+1;
 while(*p != ',' && *p) p++; 
 *p = '\0'; 
 grid->clipUpperLeftLon = atof(q);
 
 // lower right lat
 q = p = p+1;
 while(*p != ',' && *p) p++; 
 *p = '\0'; 
 grid->clipLowerRightLat = atof(q);
 
 // lower right lon
 q = p = p+1;
 while(*p != ',' && *p) p++; 
 *p = '\0'; 
 grid->clipLowerRightLon = atof(q);
 
 grid->doClip = True;
 
 // now do checks on sanity
 if(grid->clipUpperLeftLat < grid->clipLowerRightLat) {
     fprintf(stderr, "Got upper left lat [%.2f] < lower right lat [%.2f]\n",
        grid->clipUpperLeftLat, grid->clipLowerRightLat);
     return False;
 }
 
 if(grid->clipUpperLeftLon > grid->clipLowerRightLon) {
     fprintf(stderr, "Got upper left lon [%.2f] > lower right lon [%.2f]\n",
        grid->clipUpperLeftLon, grid->clipLowerRightLon);
     return False;
 }
 
 return True;
}

void convertArchiveSnowGridFile(gridDataType *grid)
{
    int latpix, lonpix;

    for(latpix=0; latpix<grid->readRows; latpix++) {
        for(lonpix=0; lonpix<grid->readCols; lonpix++) {
            switch((int) grid->data[latpix][lonpix].value) {
                // mapping between what the new model expects and what the old snow data provides
                case   0  : grid->data[latpix][lonpix].value = 0.0; break;
                case  50  : grid->data[latpix][lonpix].value = 2.0; break;  // land
                case 100  : grid->data[latpix][lonpix].value = 5.0; break;  // clouds => nosnow?
                case 250  : grid->data[latpix][lonpix].value = 4.0; break;  // snow
                default   : fprintf(stderr, "Got snow unknown snow code: %.0f\n", grid->data[latpix][lonpix].value);
            }
        }
    }
}
