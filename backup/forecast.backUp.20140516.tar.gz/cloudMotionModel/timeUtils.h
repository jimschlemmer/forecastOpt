/* 
 * File:   timeUtils.h
 * Author: root
 *
 * Created on September 15, 2006, 1:52 PM
 */

#ifndef _timeUtils_H
#define	_timeUtils_H

#include <time.h>

#define DAYS_1900_1970  25568L  /* days from 1/1/00 to 1/1/1970  */

static char *TU_monthNamesAbbrev[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

static int TU_reg_days[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

static int TU_leap_days[] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

                         // J   F   M   A  ....
static int TU_sumRegDays[] = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};

static int TU_sumLeapDays[] = {0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335};

int isLeap(int year);
time_t timeGm(int year, int month, int mday, int hour, int min, int sec);
char *strfstr(time_t *time);
time_t jdays2secs(double jday);
time_t timeGmDoy(int year, int doy, double decHour);
double secs2jdays(time_t secs);
int getLocalDoy(int year, int doy, double hour, int timeZone);
int getLocalJday(int jday, double hour, int timeZone);
time_t timeStr2gm(char *dateTime);

#endif	/* _timeUtils_H */

