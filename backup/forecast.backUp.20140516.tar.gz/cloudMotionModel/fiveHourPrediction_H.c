#include <stdlib.h>
#include <stdio.h>
#include "time.h"
#include "dirent.h"
#include <sys/stat.h>
#include <string>
#include <cstring>
#include <math.h>
#include <fstream>    // for fstream
#include <iomanip>    // for setw
#include <iostream>   // for cout, endl
#include <sys/types.h>
#include <vector>
#include <dbi/dbi.h>
#include <omp.h>

#include "types.h"
#include "timeUtils.h"
#include "gridded.h"
#include "ioUtils.h"

#define MAXPATH 256

using namespace std;

float  **PredictFrom, **PredictTo, **PredictMix;
TPoint **Movement0;


float **GeneratePredictionFrom(float **actualFrame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth);
float **GeneratePredictionTO(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);
float **GeneratePredictionMix(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto);

TPoint **GenerateMovement(float **firstFrame, float **secondFrame, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int **uniqueMovement);

float roundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}
float RoundTo(float value, int dp) {
return round(value * pow(10, -dp)) / pow(10, -dp);
}

void help(){
cout << "Arguments are not set properly. Please see the following scheme for the arguments:" << endl;
cout << "fiveHourPrediction.out <Location> <configFile> (output)" << endl;
cout << "where:" << endl;
cout << "Location - us-east, us-west, etc; It should be in the same way how it is shown in the database." << endl;
cout << "configFile - configuration file for us-east, us-west, etc." << endl;
cout << "output - the output folder path (optional). It has \"/predictions/\" value by default." << endl;
cout << "Example:" << endl;
cout << "fiveHourPrediction.out us-east us-east-hourly-cloudmotion.conf /predictions/" << endl;
}

int main(int argc, char *argv[]){

float lattitude=-200., longitude=-200., ch;
//char next;
//  dirent** de;
//  DIR* dp;
int i, j, k, l, m, countCol=0, countRow=0, ds=0;
int firstImage, lastImage, DXSample, DYSample, DXCheckArea, DYCheckArea;
float  lattitudeMin=180., longitudeMin=180., lattitudeMax=-180., longitudeMax=-180.;
float **Predict, **PredictGl, ***MapMas, ***clearSky, ***globalIR, **globalData;
TPoint **Movement;
int **uniqueMovement;
TPoint mSample, mCheckArea, pSample, pCheckArea, pMiddle, pCheck, DPoint, tMBE, tRMSE;
double **MSE, **MBE, **pMSE, **pMBE;
double RMSE, ME, pRMSE, pME, totalCount, cloudIndex0[6], cloudIndex[6], CI0, CI, bestMBE, bestRMSE;
char cwd[MAXPATH];

gridDataType gridCorr, gridClear;
initGrid(&gridCorr);
initGrid(&gridClear);
time_t rawtime, ptime, current_time;
struct tm *tm;
char timeStr[256], fromTimeStr[256], toTimeStr[256], ref_time[256] ,valid_time[256], inserted[256];
int year, month, mday, hour, min, sec=0, LookupHours=2, ForecastHours=5;
long int obsTime;
float lat, lon, upperLeftLat, upperLeftLon, lowerRightLat, lowerRightLon;
int latpixMin, lonpixMin;
char yearStr[5], monthStr[3], mdayStr[3], hourStr[3], minStr[3], secStr[3];
string outGridName="", tempGridName="";
string clElement="", clArea="", element="", area="", username="";
bool ifClearSky;

//initialization
DXSample=0;
DYSample=0;
DXCheckArea=0;
DYCheckArea=0;
pSample.x=5;pSample.y=5;
mSample.x=5;mSample.y=5;
pCheckArea.x=7;pCheckArea.y=7;
mCheckArea.x=7;mCheckArea.y=7;

getcwd(cwd,MAXPATH);
string outDirName=cwd; outDirName=outDirName+"/predictions/";
//string glDirName="";
//string clDirName="";
string glFileName1="";
string clFileName1="";
string glFileName2="";
string clFileName2="";
string configFileName="";
string locName;
char* dataName;
char* timeName;

//reading the command line
if (argc>=3){
locName=argv[1];
configFileName=argv[2];
 if (argc==4) outDirName=argv[3];
}
else{
help();
exit(1);
}
outDirName=outDirName+locName+"/";
int status = mkdir(outDirName.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IWOTH  );

//read the config file
string chString, DbName, CorrectedFilesDb, CorrectedSelectArea, ClearskyFilesDb, OutputFilesDb;
int linenum=1, trnum=1;
char linebuf[100000];
bool isFile=false, Verbose=false;
char * pch;

DbName="satmod";
CorrectedFilesDb="corrected_global_grid_files";
ClearskyFilesDb="clearsky_grid_files";
CorrectedSelectArea=locName;
OutputFilesDb="grid_files_cm";
clArea="north_america";
clElement="clearsky_global";
area=locName;

FILE * outGridFile; 
ifstream configFile(configFileName.c_str());
for (linenum=1;configFile.getline(linebuf,100000)!= NULL; linenum++){
  pch = strtok (linebuf,"=");
	trnum=1;
  while (pch != NULL)
  {
	 	if(trnum==1) chString=pch;
		if(trnum==2){ 
		  if (chString=="DbName") DbName=pch;
		  if (chString=="CorrectedFilesDb") CorrectedFilesDb=pch;
		  if (chString=="CorrectedSelectArea") {CorrectedSelectArea=pch; locName=CorrectedSelectArea;}
			if (chString=="CorrectedTimeMin") min=atoi(pch);
			if (chString=="CorrectedTimeSec") sec=atoi(pch);
			if (chString=="ClearskyFilesDb") ClearskyFilesDb=pch;
			if (chString=="ClearskySelectArea") clArea=pch;
			if (chString=="ClearskySelectElement") clElement=pch;
			if (chString=="OutputFilesDb") OutputFilesDb=pch;
			if (chString=="OutputArea") area=pch;
			if (chString=="upperLeftLat") upperLeftLat=atof(pch);
			if (chString=="upperLeftLon") upperLeftLon=atof(pch);
			if (chString=="lowerRightLat") lowerRightLat=atof(pch);
			if (chString=="lowerRightLon") lowerRightLon=atof(pch);
      if (chString=="LookupHours") LookupHours=atoi(pch);
			if (chString=="ForecastHours") ForecastHours=atoi(pch);
			if (chString=="Verbose") Verbose=atoi(pch);
		}
    pch = strtok (NULL, "=");
		trnum++;
  }
}
if (linenum>10)isFile=true;
//ifstream.close;


if(Verbose)cout << "the config file:" << endl;
if(Verbose)cout << "DbName: " << DbName << endl;
if(Verbose)cout << "CorrectedFilesDb: " << CorrectedFilesDb << endl;
if(Verbose)cout << "CorrectedSelectArea: " << locName << endl;
if(Verbose)cout << "min: " << min << endl;
if(Verbose)cout << "sec: " << sec << endl;
if(Verbose)cout << "ClearskyFilesDb: " << ClearskyFilesDb << endl;
if(Verbose)cout << "clArea: " << clArea << endl;
if(Verbose)cout << "clElement: " << clElement << endl;
if(Verbose)cout << "OutputFilesDb: " << OutputFilesDb << endl;
if(Verbose)cout << "area: " << area << endl;
if(Verbose)cout << "upperLeftLat: " << upperLeftLat << endl;
if(Verbose)cout << "upperLeftLon: " << upperLeftLon << endl;
if(Verbose)cout << "lowerRightLat: " << lowerRightLat << endl;
if(Verbose)cout << "lowerRightLon: " << lowerRightLon << endl;
if(Verbose)cout << "Verbose: " << Verbose << endl;


if (!isFile){
cout << "the config file is not correct; using the defaulf settings instead of it...." << endl;
if (locName=="us-east") {
min=15;
sec=0;
}else if (locName=="us-west") {
min=0;
sec=0;
}else if (locName=="hawaii") {
min=0;
sec=0;
}else{
help();
exit(1);
}
}

//cout << area << "  " << min << "  " << sec << endl; 
//cout << DbName << "  " << CorrectedFilesDb << "  " << ClearskyFilesDb << "  " << OutputFilesDb << endl;

//database initialization
  char db_name[20];
  dbi_conn conn;
  dbi_result result,result1;
  long conn_id;
  char conn_id_str[256];

  strcpy(db_name,DbName.c_str());
	//strcpy(db_name,"satmod");
  dbi_initialize(NULL);
  conn = dbi_conn_new("mysql");

  dbi_conn_set_option(conn, "host", "localhost");
  //dbi_conn_set_option(conn, "username", "sergey");
  //dbi_conn_set_option(conn, "password", "masterkey");
  dbi_conn_set_option(conn, "dbname", db_name);
  dbi_conn_set_option(conn, "encoding", "UTF-8");
  //username=dbi_conn_get_option(conn, "username");
  if (dbi_conn_connect(conn) < 0) {
                cout << "Problems opening forecast db" << endl;
								exit(1); 
  }

MapMas = new float **[2];
globalIR = new float **[2];
for (j=0; j<2; j++) {
		MapMas[j] = new float *[1000];
		globalIR[j] = new float *[1000];
    for (i=0;i<1000;i++) {
        MapMas[j][i] = new float[1000];
				globalIR[j][i] = new float[1000];
        for (k=0;k<1000;k++) {
		 				MapMas[j][i][k]=0;
		 				globalIR[j][i][k]=0;
				}
     }
}

clearSky = new float **[3];
for (j=0; j<3; j++) {
		clearSky[j]= new float *[1000];
    for (i=0;i<1000;i++) {
				clearSky[j][i]=new float[1000];
        for (k=0;k<1000;k++) {
						clearSky[j][i][k]=0;
				}
     }
}

Movement= new TPoint *[1000];
Movement0= new TPoint *[1000];
for(i=0;i<1000;i++){
 Movement[i]=new TPoint[1000];
 Movement0[i]=new TPoint[1000];
 for(j=0;j<1000;j++){
        Movement[i][j].x=Movement[i][j].y=0;
 }
}
uniqueMovement= new int *[1000];
for(i=0;i<1000;i++){
 uniqueMovement[i]=new int[1000];
 for(j=0;j<1000;j++){
        uniqueMovement[i][j]=0;
 }
}

Predict= new float *[1000];
PredictGl= new float *[1000];
PredictFrom= new float *[1000];
PredictTo= new float *[1000];
PredictMix= new float *[1000];
for(i=0;i<1000;i++){
 Predict[i]=new float[1000];
 PredictGl[i]=new float[1000];
 PredictFrom[i]=new float[1000];
 PredictTo[i]=new float[1000];
 PredictMix[i]=new float[1000];
 for(j=0;j<1000;j++) 
   {Predict[i][j]=0.5; PredictGl[i][j]=0.5;}
}

MSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MSE[i]=new double[2*DYCheckArea+1];
MBE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MBE[i]=new double[2*DYCheckArea+1];
pMSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) pMSE[i]=new double[2*DYCheckArea+1];
pMBE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) pMBE[i]=new double[2*DYCheckArea+1];
CI0=0; CI=0;


//dbi_conn_query(conn,"SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;");
dbi_conn_query(conn,"START TRANSACTION;");

result1 = dbi_conn_query(conn,"SHOW PROCESSLIST;");
while(dbi_result_next_row(result1)){
 conn_id=dbi_result_get_longlong(result1, "id");
 result=dbi_conn_queryf(conn,"select * from processes where id='%ld' and location='%s';",conn_id,locName.c_str());
 if(dbi_result_next_row(result)){
  if(Verbose)  cout << "the process has already been started" << endl;
dbi_conn_query(conn,"ROLLBACK;");
  dbi_result_free(result);
  dbi_result_free(result1);
  dbi_conn_close(conn);
  dbi_shutdown();
  exit(1);
 }
}

 result = dbi_conn_query(conn,"SELECT CONNECTION_ID();");
while(dbi_result_next_row(result)){
 conn_id=dbi_result_get_longlong(result, "CONNECTION_ID()");
 sprintf(conn_id_str, "%d",conn_id);
}

 time(&ptime);
 tm = gmtime(&ptime);
 strftime(inserted, 256, "%Y-%m-%d %H:%M:%S", tm);
//result1 = dbi_conn_queryf(conn,"insert into processes(id,time_start,location) values('%s','%s','%s');", conn_id_str,inserted,locName.c_str());
result1 = dbi_conn_queryf(conn,"insert into processes(id,time_start,time_end,location) values('%s','%s','%s','%s');", conn_id_str,inserted,inserted,locName.c_str());
//  printf("%2ld \n", dbi_result_get_longlong(result, "CONNECTION_ID()") );

dbi_conn_query(conn,"COMMIT;");

	
if(Verbose)  cout << "current time generator: " << endl;
time(&current_time);
tm = gmtime(&current_time);
year=tm->tm_year+1900;
month=tm->tm_mon+1;
mday=tm->tm_mday;
hour=tm->tm_hour-LookupHours;
if(Verbose)  cout << year << "-" << month << "-" << mday << " " << hour << ":" << min << ":" << sec << endl;
   rawtime = timeGm(year, month, mday, hour, min, sec);
while (rawtime<current_time){
hour++;
//checking presence / consistence of the global and clearsky files for a cloud movement
   rawtime = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&rawtime);
   strftime(ref_time, 256, "%Y-%m-%d %H:%M:%S", tm);
   char stmStr[1024];
   sprintf(stmStr, "select * from %s where valid_time='%s' and area='%s';",CorrectedFilesDb.c_str(),ref_time,CorrectedSelectArea.c_str());

 result=dbi_conn_queryf(conn, stmStr);
 if(dbi_result_next_row(result)){
  glFileName1=dbi_result_get_string_copy(result,"gridFilename");
  if(Verbose) cout << "the global_grid_files for 1: " << glFileName1 << endl; 
 }else{
  if(Verbose) { 
	cout << "there are no entries 1 in the " << CorrectedFilesDb << " for: " << ref_time << endl;
	cout << "SQL query: " << stmStr << endl;
  }
  continue;
 }
dbi_result_free(result);

   rawtime = timeGm(year, month, mday, hour+1, min, sec);
   tm = gmtime(&rawtime);
   strftime(timeStr, 256, "%Y%m%d.%H%M%S", tm);
   strftime(fromTimeStr, 256, "%Y%m%d.%H%M%S", tm);
   strftime(ref_time, 256, "%Y-%m-%d %H:%M:%S", tm);
 result=dbi_conn_queryf(conn,"select * from %s where valid_time='%s' and area='%s';",CorrectedFilesDb.c_str(),ref_time,CorrectedSelectArea.c_str());
 if(dbi_result_next_row(result)){
  glFileName2=dbi_result_get_string_copy(result,"gridFilename");
  if(Verbose) cout << "the global_grid_files for 2: " << glFileName2 << endl; 
 }else{
  if(Verbose) cout << "there are no entries 2 in the " << CorrectedFilesDb << " for: " << ref_time << endl;
  continue;
 }
dbi_result_free(result);
 
   rawtime = timeGm(year, month, mday, hour, min, sec);
   tm = gmtime(&rawtime);
   strftime(timeStr, 256, "%j", tm); 
   result=dbi_conn_queryf(conn,"select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str(),clArea.c_str());	 
 if(dbi_result_next_row(result)){
   clFileName1=dbi_result_get_string_copy(result,"gridFilename");
   if(Verbose) cout << "the clearsky_grid_files for 1: " << clFileName1 << endl;
//printf ("select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,hour,min,clElement.c_str(),clArea.c_str());
 }
 else{
  if(Verbose) cout << "there are no entries 1 in the clearsky_grid_files for: " << ref_time << endl;
	if(Verbose) printf ("select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str()),clArea.c_str();
  continue;
 }
dbi_result_free(result);
 
   rawtime = timeGm(year, month, mday, hour+1, min, sec);
   tm = gmtime(&rawtime);
   strftime(timeStr, 256, "%j", tm); 
   result=dbi_conn_queryf(conn,"select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str(),clArea.c_str());	 
 if(dbi_result_next_row(result)){
   clFileName2=dbi_result_get_string_copy(result,"gridFilename");
   if(Verbose) cout << "the clearsky_grid_files for 2: " << clFileName2 << endl;
//printf ("select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,hour,min,clElement.c_str(),clArea.c_str());
 }
 else{
  if(Verbose) cout << "there are no entries 2 in the clearsky_grid_files for: " << ref_time << endl;
	if(Verbose) printf ("select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str(),clArea.c_str());
  continue;
 } 	 
dbi_result_free(result);


   gridCorr.fileName = (char*)glFileName1.c_str();
   if (!openReadGridfile(&gridCorr)){
  continue;
	 }
	 
   gridClear.fileName = (char*)clFileName1.c_str();
   if (!openReadGridfile(&gridClear)){
  continue;
	 }
	 
   gridCorr.fileName = (char*)glFileName2.c_str();
   if (!openReadGridfile(&gridCorr)){
  continue;
	 }
	 
   gridClear.fileName = (char*)clFileName2.c_str();
   if (!openReadGridfile(&gridClear)){
  continue;
	 }


dbi_conn_query(conn,"START TRANSACTION;");
   ptime = timeGm(year, month, mday, hour+1+1, min, sec);
   tm = gmtime(&ptime);
   strftime(toTimeStr, 256, "%Y%m%d.%H%M%S", tm);
   outGridName=outDirName; outGridName=outGridName+locName+"."+toTimeStr+"."+fromTimeStr+".global.grid";
   result = dbi_conn_queryf(conn,"select element,area,gridFilename from %s where gridFilename='%s';",OutputFilesDb.c_str(),outGridName.c_str());

 if(!result) {
     if(Verbose) cout << "problems doing select" << endl;
     if(Verbose) printf ("select element,area,gridFilename from %s where gridFilename='%s';",OutputFilesDb.c_str(),outGridName.c_str());

  }
 if (dbi_result_next_row(result)){
  if(Verbose) cout << "the file" << outGridName.c_str()  << " already exists" << endl;
dbi_conn_query(conn,"ROLLBACK;");
  continue;
 }
dbi_result_free(result);

 //reach and open actual global irradiance file for t-1   
   gridCorr.fileName = (char*)glFileName1.c_str();
        if (openReadGridfile(&gridCorr)){

                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
                globalIR[0][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;
                MapMas[0][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;						                     
								}
					lattitudeMin=gridCorr.data[0][0].lat;
					longitudeMin=gridCorr.data[0][0].lon;		
        }

   //reach and open actual clearsky file for t-1
   gridClear.fileName = (char*)clFileName1.c_str();
     if (openReadGridfile(&gridClear)){


                for(int latpix=0; latpix<gridClear.readRows; latpix++)
                for(int lonpix=0; lonpix<gridClear.readCols; lonpix++) {				
        lat = gridClear.data[latpix][lonpix].lat;
        lon = gridClear.data[latpix][lonpix].lon;
		if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
		}
//cout << "lat lon pixel numbers: " << latpixMin << ", " << lonpixMin << endl;
//cout << "gridClear latMin, lonMin for gridCorr by pix: " << gridClear.data[latpixMin][lonpixMin].lat << ", " << gridClear.data[latpixMin][lonpixMin].lon << endl;
//cout << "gridClear latMax, lonMax for gridCorr by pix: " << gridClear.data[latpixMin+gridCorr.readRows][lonpixMin+gridCorr.readCols-1].lat << ", " << gridClear.data[latpixMin+gridCorr.readRows][lonpixMin+gridCorr.readCols-1].lon << endl;

                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
		clearSky[0][lonpix][latpix]=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
		if (gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value>0){
                MapMas[0][lonpix][latpix]=MapMas[0][lonpix][latpix]/gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
		}else{MapMas[0][lonpix][latpix]=0;}
		}
	}

if(Verbose) cout << "lattitudeMin=" << lattitudeMin << "   longitudeMin=" << longitudeMin << endl;
	
 //reach and open actual global irradiance file for t0   
   gridCorr.fileName = (char*)glFileName2.c_str();
        if (openReadGridfile(&gridCorr)){
					 			obsTime=gridCorr.hed.obs_time;
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
                globalIR[1][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;
                MapMas[1][lonpix][latpix]=gridCorr.data[latpix][lonpix].value;						                     
								}
                                        lattitudeMin=gridCorr.data[0][0].lat;
                                        longitudeMin=gridCorr.data[0][0].lon;
        }

   //reach and open actual clearsky file for t0
   gridClear.fileName = (char*)clFileName2.c_str();
     if (openReadGridfile(&gridClear)){
                for(int latpix=0; latpix<gridClear.readRows; latpix++)
                for(int lonpix=0; lonpix<gridClear.readCols; lonpix++) {				
        lat = gridClear.data[latpix][lonpix].lat;
        lon = gridClear.data[latpix][lonpix].lon;
				if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
								}
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
		clearSky[1][lonpix][latpix]=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
		if (gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value>0){
                MapMas[1][lonpix][latpix]=MapMas[1][lonpix][latpix]/gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
		}else{MapMas[1][lonpix][latpix]=0;}
		}
	}

if(Verbose) cout << "lattitudeMin=" << lattitudeMin << "   longitudeMin=" << longitudeMin << endl;
	
	countCol=gridCorr.readCols;
	countRow=gridCorr.readRows;
	for(i=0;i<2;i++) for(j=0;j<1000; j++) for(k=0;k<1000;k++){MapMas[i][k][j]=(1-MapMas[i][k][j]);	}

pMiddle.x=countCol/2;
pMiddle.y=countRow/2;

//MOVEMENT generation for 1 hour
 if(Verbose) cout << "Movement generation starts" << endl;
 Movement=GenerateMovement(MapMas[0], MapMas[1], countCol, countRow, mSample, mCheckArea, uniqueMovement);
// cout << "Movement generation ends" << endl;
 if(Verbose)  cout << "5 hour generation starts" << endl;

 time(&ptime); 
 tm = gmtime(&ptime);
 strftime(inserted, 256, "%Y-%m-%d %H:%M:%S", tm);

for(int k=1;k<=ForecastHours;k++) {
ifClearSky=false;
clFileName2="";
int latWidth=0, lonWidth=0; 
   //reach and open actual clearsky files for t1 - t5
   ptime = timeGm(year, month, mday, hour+1+k, min, sec);
   tm = gmtime(&ptime);
   strftime(timeStr, 256, "%j", tm);
   result=dbi_conn_queryf(conn,"select * from %s where doy='%s' and hour='%d' and minute='%d' and element='%s' and area='%s';",ClearskyFilesDb.c_str(),timeStr,tm->tm_hour,min,clElement.c_str(),clArea.c_str());	 
 if(dbi_result_next_row(result)){
   clFileName2=dbi_result_get_string_copy(result,"gridFilename");
	 if(Verbose) cout << "the clearsky_grid_files for forecast: " << clFileName2 << endl;
//cout << "area hour:  " << area << " " << hour+1+k << endl;
 }
        gridClear.fileName = (char*)clFileName2.c_str();
        if (openReadGridfile(&gridClear)){
              for(int latpix=0; latpix<gridClear.readRows; latpix++)
              for(int lonpix=0; lonpix<gridClear.readCols; lonpix++) {				
        lat = gridClear.data[latpix][lonpix].lat;
        lon = gridClear.data[latpix][lonpix].lon;
				if (lat==lattitudeMin && lon==longitudeMin){latpixMin=latpix; lonpixMin=lonpix; break;}
								}			
                for(int latpix=0; latpix<gridCorr.readRows; latpix++)
                for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++) {
		clearSky[2][lonpix][latpix]=gridClear.data[latpixMin+latpix][lonpixMin+lonpix].value;
        lat = gridClear.data[latpixMin+latpix][lonpixMin+lonpix].lat;
        lon = gridClear.data[latpixMin+latpix][lonpixMin+lonpix].lon;		
		if ((lat==upperLeftLat && lon==upperLeftLon)||(lat==upperLeftLat && lon==lowerRightLon)||(lat==lowerRightLat && lon==upperLeftLon)||(lat==lowerRightLat && lon==lowerRightLon))
		if (clearSky[2][lonpix][latpix]>0) ifClearSky=true;
		}
		if (!ifClearSky) {if(Verbose) cout << k << " ifClearSky: " << ifClearSky << endl; continue;}
	  if(Verbose) cout << k << " ifClearSky: " << ifClearSky << endl;
		
 		   		latWidth=gridCorr.readRows;
				lonWidth=gridCorr.readCols;
				strcpy(gridCorr.hed.description, "forecast global irradiance");
				gridCorr.hed.obs_time=obsTime+3600*k;

	
   ptime = timeGm(year, month, mday, hour+1+k, min, sec);
   tm = gmtime(&ptime);	
   strftime(toTimeStr, 256, "%Y%m%d.%H%M%S", tm);
	 strftime(valid_time, 256, "%Y-%m-%d %H:%M:%S", tm);

//MIXED_AVERAGE_smoothing
bool smooth=true;
bool maxto=false;
if(Verbose) cout << k << " GeneratePredictionMix starts" << endl;
 Predict=GeneratePredictionMix(MapMas[1], Movement, countCol, countRow, pSample, pCheckArea, k, smooth, maxto);
if(Verbose) cout << k << " GeneratePredictionMix ends" << endl;

 for(l=0;l<1000;l++)for(m=0;m<1000;m++){
        PredictGl[l][m]=clearSky[2][l][m]*(1-Predict[l][m]);
 }


globalData= new float *[latWidth];
for(int i=0;i<latWidth;i++){
 globalData[i]=new float[lonWidth];
 for(int j=0;j<lonWidth;j++)
   {globalData[i][j]=0;}
}
	
outGridName=outDirName; outGridName=outGridName+locName+"."+toTimeStr+"."+fromTimeStr+".global.grid";
outGridFile=fopen(outGridName.c_str(),"w");

if(Verbose) cout << k << " globalData starts" << endl; 
   for(int latpix=0; latpix<gridCorr.readRows; latpix++)
   for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++){ 
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;
				globalData[latpix][lonpix]=PredictGl[lonpix][latpix];
   }
if(Verbose) cout << k << " globalData output starts" << endl;	 
element="global_irrad";
        result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,glFileName2.c_str(),"CM",inserted);
  if (result){
gridWriteHeaderFloat(outGridFile,&gridCorr.hed);
gridWriteDataFloat(outGridFile,globalData,latWidth,lonWidth);
  }
fclose(outGridFile);
dbi_result_free(result);

outGridName=outDirName; outGridName=outGridName+locName+"."+toTimeStr+"."+fromTimeStr+".cloud.grid";
outGridFile=fopen(outGridName.c_str(),"w");

if(Verbose) cout << k << " cloudData starts" << endl;
   for(int latpix=0; latpix<gridCorr.readRows; latpix++)
   for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++){
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;
                                globalData[latpix][lonpix]=Predict[lonpix][latpix];
   }
strcpy(gridCorr.hed.description, "forecast cloud index");
element="cloud_index";
        result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,glFileName2.c_str(),"CM",inserted);
  if (result){
gridWriteHeaderFloat(outGridFile,&gridCorr.hed);
gridWriteDataFloat(outGridFile,globalData,latWidth,lonWidth);
  }
fclose(outGridFile);
dbi_result_free(result);

outGridName=outDirName; outGridName=outGridName+locName+"."+toTimeStr+"."+fromTimeStr+".windSN.grid";
outGridFile=fopen(outGridName.c_str(),"w");


   for(int latpix=0; latpix<gridCorr.readRows; latpix++)
   for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++){
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;
                                globalData[latpix][lonpix]=Movement[lonpix][latpix].y;
   }
strcpy(gridCorr.hed.description, "forecast wind direction SN");
element="wind_SN";
        result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,glFileName2.c_str(),"CM",inserted);
  if (result){
gridWriteHeaderFloat(outGridFile,&gridCorr.hed);
gridWriteDataFloat(outGridFile,globalData,latWidth,lonWidth);
  }
fclose(outGridFile);
dbi_result_free(result);

outGridName=outDirName; outGridName=outGridName+locName+"."+toTimeStr+"."+fromTimeStr+".windWE.grid";
outGridFile=fopen(outGridName.c_str(),"w");


   for(int latpix=0; latpix<gridCorr.readRows; latpix++)
   for(int lonpix=0; lonpix<gridCorr.readCols; lonpix++){
        lat = gridCorr.data[latpix][lonpix].lat;
        lon = gridCorr.data[latpix][lonpix].lon;
                                globalData[latpix][lonpix]=Movement[lonpix][latpix].x;
   }
strcpy(gridCorr.hed.description, "forecast wind direction WE");
element="wind_WE";
        result = dbi_conn_queryf(conn,"insert into %s(element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,glFileName2.c_str(),"CM",inserted);
  if (result){
gridWriteHeaderFloat(outGridFile,&gridCorr.hed);
gridWriteDataFloat(outGridFile,globalData,latWidth,lonWidth);
  }
fclose(outGridFile);
dbi_result_free(result);

for(int i=0;i<latWidth;i++) {
        delete[] globalData[i];
}
delete[] globalData;

  if(!result) {
     if(Verbose) cout << "problems doing insert in add_grid_files_db" << endl;
     if(Verbose) printf ("insert into %s (element,area,gridFilename,ref_time,valid_time,source_file,model,inserted,user) values('%s','%s','%s','%s','%s','%s','%s','%s',USER());",OutputFilesDb.c_str(),element.c_str(),area.c_str(),outGridName.c_str(),ref_time,valid_time,glFileName2.c_str(),"CM",inserted);  

    //print_db_error(conn);
  }
        }//clearsky exists
	 
} //for k

// cout << "Prediction generation ends" << endl;

dbi_conn_query(conn,"COMMIT;");

} //end while time


//dbi_conn_query(conn,"SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;");
dbi_conn_query(conn,"START TRANSACTION;");
result1 = dbi_conn_queryf(conn,"delete from processes where id='%s';",conn_id_str);
dbi_conn_query(conn,"COMMIT;");


  if (dbi_conn_connect(conn) >= 0) {
   //fprintf(stderr,"Problems opening forecast db\n");
   //print_db_error(conn);
  dbi_result_free(result);  
  dbi_conn_close(conn);
  dbi_shutdown();
  } 
	
// clear variables
for (j=0; j<2; j++) {
    for (i=0; i<1000; i++) {
         delete[] MapMas[j][i];
	 delete[] globalIR[j][i];
    }
    delete[] MapMas[j];
    delete[] globalIR[j];
}
delete[] MapMas;
delete[] globalIR;

for (j=0; j<3; j++) {
    for (i=0; i<1000; i++) {
	delete[] clearSky[j][i];
    }
	delete[] clearSky[j];
}
delete[] clearSky;

for(i=0;i<1000;i++) {
        delete[] Movement[i];
        //delete[] Movement0[i];
        delete[] uniqueMovement[i];
}
delete[] Movement;
//delete[] Movement0;
delete[] uniqueMovement;

for(i=0;i<1000;i++) {
        delete[] Predict[i];
        delete[] PredictGl[i];
        //delete[] PredictFrom[i];
        //delete[] PredictTo[i];
        //delete[] PredictMix[i];
}
delete[] Predict;
delete[] PredictGl;
//delete[] PredictFrom;
//delete[] PredictTo;
//delete[] PredictMix;


for(i=0;i<2*DXCheckArea+1;i++) delete[] MSE[i];
delete[] MSE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] MBE[i];
delete[] MBE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] pMSE[i];
delete[] pMSE;
for(i=0;i<2*DXCheckArea+1;i++) delete[] pMBE[i];
delete[] pMBE;


}


TPoint **GenerateMovement(float **firstFrame, float **secondFrame, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int **uniqueMovement)
{
TPoint pFirst, pSecond, DPoint, bestMSE;
int i,j,totalPoints,i_min,i_max,j_min,j_max;
double bestMSEValue, **MSE;
bool ifMSE,iStop=false,jStop=true,iForward=true,jForward=true;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
int maxMoveX=0, maxMoveY=0;

float ciMean, windMeanSN, windMeanWE, ciVariability, windVariabilitySN, windVariabilityWE,MinCI,MaxCI;
int oppositeCount, nonuniqueCount;
bool ifOpposite=false;
TSite arrayOp;
vector<TSite > OppositeVect;
vector<TSite>::iterator site_it;

//Movement0= new TPoint *[600];
for(i=0;i<600;i++){
 //Movement0[i]=new TPoint[600];
 for(j=0;j<600;j++){
        Movement0[i][j].x=Movement0[i][j].y=0;
 }
}

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

MSE=new double *[2*DXCheckArea+1];
for(i=0;i<2*DXCheckArea+1;i++) MSE[i]=new double[2*DYCheckArea+1];
   

 //specify the initial point on the first frame
   for(pSecond.x=DXSample+DXCheckArea;pSecond.x<countCol-(DXSample+DXCheckArea);pSecond.x++){
   for(pSecond.y=DYSample+DYCheckArea;pSecond.y<countRow-(DYSample+DYCheckArea);pSecond.y++){
   
        //specify the possible related point on the second frame
	//#pragma parallel
	//#pragma shared(MSE,firstFrame,secondFrame)
	//#pragma shared (pSecond,DXCheckArea,DYCheckArea,DXSample,DYSample)
	//#pragma local(pFirst,DPoint)
	//#pragma pfor
        for(pFirst.x=pSecond.x-DXCheckArea;pFirst.x<=pSecond.x+DXCheckArea;pFirst.x++)
        for(pFirst.y=pSecond.y-DYCheckArea;pFirst.y<=pSecond.y+DYCheckArea;pFirst.y++){
             MSE[pFirst.x-pSecond.x+DXCheckArea][pFirst.y-pSecond.y+DYCheckArea]=0;
             //specify the comparison area
             for(DPoint.x=-DXSample;DPoint.x<=DXSample;DPoint.x++)
             for(DPoint.y=-DYSample;DPoint.y<=DYSample;DPoint.y++){
                 //calculate the mean square error along the area for all related points
                 MSE[pFirst.x-pSecond.x+DXCheckArea][pFirst.y-pSecond.y+DYCheckArea]+=pow(firstFrame[pFirst.x+DPoint.x][pFirst.y+DPoint.y]-secondFrame[pSecond.x+DPoint.x][pSecond.y+DPoint.y],2);
             }
        }

        //chooce a best related point if there is and calculate the movement vector for it
        bestMSE.x=DXCheckArea;
        bestMSE.y=DYCheckArea;
        bestMSEValue=countCol*countRow;					 	
				i=0;j=0;i_min=0;i_max=2*DXCheckArea;j_min=0;j_max=2*DYCheckArea;
        iStop=false;jStop=true;iForward=true;jForward=true;
				nonuniqueCount=0;
				//cout << "i=" << i << ";j=" << j  << ";imax=" << i_max << ";jmax=" << j_max << endl;
		while(jStop){
		    if (MSE[i][j]==bestMSEValue) {nonuniqueCount++;}	
        if (MSE[i][j]<bestMSEValue) {
           bestMSEValue=MSE[i][j];
           bestMSE.x=i;
           bestMSE.y=j;
					 nonuniqueCount=0;
        }							 			
				if(iStop){
				   if(jForward){
					    if(j<j_max){j++;
							//cout << "i=" << i << ";j=" << j << "  ";
							}
							else{jForward=false;iStop=false;
							//cout << " i=" << i << ";j=" << j << endl;
							}
					 }
					 else{
					    if(j>j_min){j--;
							//cout << "i=" << i << ";j=" << j << "  ";
							}
							else{jForward=true;iStop=false;
							//cout << " i=" << i << ";j=" << j << endl;
							}					 
					 }
				}
				else{
				   if(iForward){
					    if(i<i_max){i++;
							//cout << "i=" << i << ";j=" << j << "  ";
							}
							else{iForward=false;iStop=true;
							//cout << " i=" << i << ";j=" << j << endl;
							}
					 }
					 else{
					    if(i>i_min){i--;
							//cout << "i=" << i << ";j=" << j << "  ";
							}
							else{iForward=true;iStop=true;
							//cout << " i=" << i << ";j=" << j << endl;
							}					 
					 }				
				}		
				if(i==i_min && j==j_min) {i++;i_min++;j++;j_min++;i_max--;j_max--;iStop=false;iForward=true;jForward=true;}
				if(i==DXCheckArea && j==DYCheckArea) break;
		}
			  j=DYCheckArea;
				for (i=i_min;i<DXCheckArea;i++){   
				if (MSE[i][j]==bestMSEValue) {nonuniqueCount++;}     
				if (MSE[i][j]<bestMSEValue) {
           bestMSEValue=MSE[i][j];
           bestMSE.x=i;
           bestMSE.y=j;
					 nonuniqueCount=0;
        }		
				}
				for (i=i_max;i>DXCheckArea;i--){  
				if (MSE[i][j]==bestMSEValue) {nonuniqueCount++;}      
				if (MSE[i][j]<bestMSEValue) {
           bestMSEValue=MSE[i][j];
           bestMSE.x=i;
           bestMSE.y=j;
					 nonuniqueCount=0;
        }		
				}
				i=DXCheckArea;
				for (j=j_min;j<DYCheckArea;j++){   
				if (MSE[i][j]==bestMSEValue) {nonuniqueCount++;}	     
				if (MSE[i][j]<bestMSEValue) {
           bestMSEValue=MSE[i][j];
           bestMSE.x=i;
           bestMSE.y=j;
					 nonuniqueCount=0;
        }		
				}
				for (j=j_max;j>DYCheckArea;j--){   
				if (MSE[i][j]==bestMSEValue) {nonuniqueCount++;}     
				if (MSE[i][j]<bestMSEValue) {
           bestMSEValue=MSE[i][j];
           bestMSE.x=i;
           bestMSE.y=j;
					 nonuniqueCount=0;
        }		
				}
				if (MSE[DXCheckArea][DYCheckArea]==bestMSEValue){
           bestMSE.x=DXCheckArea;
           bestMSE.y=DYCheckArea;				
				   nonuniqueCount++;
				}
        if (MSE[DXCheckArea][DYCheckArea]<bestMSEValue) {
           bestMSEValue=MSE[DXCheckArea][DYCheckArea];
           bestMSE.x=DXCheckArea;
           bestMSE.y=DYCheckArea;
					 nonuniqueCount=0;
        }		
								
           Movement0[pSecond.x][pSecond.y].x=-bestMSE.x+DXCheckArea;
           if (abs(Movement0[pSecond.x][pSecond.y].x)>abs(maxMoveX)) maxMoveX=Movement0[pSecond.x][pSecond.y].x;
           Movement0[pSecond.x][pSecond.y].y=-bestMSE.y+DYCheckArea;
           if (abs(Movement0[pSecond.x][pSecond.y].y)>abs(maxMoveY)) maxMoveY=Movement0[pSecond.x][pSecond.y].y;
					 uniqueMovement[pSecond.x][pSecond.y]=nonuniqueCount;
   }
   }

for(i=0;i<2*DXCheckArea+1;i++) delete[] MSE[i];
delete[] MSE;


return Movement0;

//for(i=0;i<600;i++) {
//    delete[] Movement0[i];
//}
//delete[] Movement0;

}
                                                                                                                                                                                                                                                                                                                                                                                         

float **GeneratePredictionFrom(float **actualFrame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth)
{
TPoint mapPoint, predictPoint, fromPoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
float **smoothPredict;

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictFrom=new float *[600];
for(i=0;i<600;i++){
// PredictFrom[i]=new float[600];
 for(j=0;j<600;j++){
     PredictFrom[i][j]=0;
 }
}


   for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){

      fromPoint.x=mapPoint.x-Dh*Movement[mapPoint.x][mapPoint.y].x;
      fromPoint.y=mapPoint.y-Dh*Movement[mapPoint.x][mapPoint.y].y;
      
      if(0<=fromPoint.x && fromPoint.x<600)if(0<=fromPoint.y && fromPoint.y<600)
      PredictFrom[mapPoint.x][mapPoint.y]=actualFrame[fromPoint.x][fromPoint.y];

   }



   if(smooth){
        smoothPredict= new float *[600];
        for(i=0;i<600;i++) smoothPredict[i]=new float[600];

        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictFrom[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                        PredictFrom[i][j]=smoothPredict[i][j];
        }

        for(i=0;i<600;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }

   return PredictFrom;

//   for(i=0;i<600;i++) delete[] PredictFrom[i];
//   delete[] PredictFrom;
};



float **GeneratePredictionTO(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto)
{
TPoint mapPoint, predictPoint, fromPoint, closePoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea;
double closeValue;
float **secondPredict, **thirdPredict,  **smoothPredict;
bool **isPredicted, **isSecondPredicted, **isThirdPredicted; 

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictTo=new float *[600];
secondPredict=new float *[600];
thirdPredict=new float *[600];
isPredicted=new bool *[600];
isSecondPredicted=new bool *[600];
isThirdPredicted=new bool *[600];
for(i=0;i<600;i++){
 //PredictTo[i]=new float[600];
 secondPredict[i]=new float[600];
 thirdPredict[i]=new float[600];
 isPredicted[i]=new bool[600];
 isSecondPredicted[i]=new bool[600];
 isThirdPredicted[i]=new bool[600];
 for(j=0;j<600;j++){
     PredictTo[i][j]=0;
     secondPredict[i][j]=0;
     thirdPredict[i][j]=0;
     isPredicted[i][j]=false;
     isSecondPredicted[i][j]=false;
     isThirdPredicted[i][j]=false;
 }
}

   for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
      predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
      predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
      
      if(0<=predictPoint.x && predictPoint.x<600)if(0<=predictPoint.y && predictPoint.y<600)
      if(!isPredicted[predictPoint.x][predictPoint.y]){
        PredictTo[predictPoint.x][predictPoint.y]==0;
        PredictTo[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
        secondPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isSecondPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
        thirdPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isThirdPredicted[predictPoint.x][predictPoint.y]=true;
      }

   }

   if(maxto){
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<599)if(1<=predictPoint.y && predictPoint.y<599)
                if(isSecondPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isSecondPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=secondPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<599)if(1<=predictPoint.y && predictPoint.y<599)
                if(isThirdPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isThirdPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=thirdPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
   }


   if(smooth){
        smoothPredict= new float *[600];
        for(i=0;i<600;i++) smoothPredict[i]=new float[600];

        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictTo[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<599;i++)
        for(j=1;j<599;j++){
                        PredictTo[i][j]=smoothPredict[i][j];
        }
     

        for(i=0;i<600;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }


   for(i=0;i<600;i++){ 
	delete[] secondPredict[i];
	delete[] thirdPredict[i];
	delete[] isPredicted[i];
	delete[] isSecondPredicted[i];
	delete[] isThirdPredicted[i];
   }
   delete[] secondPredict;
   delete[] thirdPredict;
   delete[] isPredicted;
   delete[] isSecondPredicted;
   delete[] isThirdPredicted;


   return PredictTo;

   //for(i=0;i<600;i++) delete[] PredictTo[i];
   //delete[] PredictTo;
};


float **GeneratePredictionMix(float **t0Frame, TPoint **Movement, int countCol, int countRow, TPoint DSample, TPoint DCheckArea, int Dh, bool smooth, bool maxto)
{
TPoint mapPoint, predictPoint, fromPoint, closePoint, checkPoint;
int i,j,k,l;
int DXSample, DYSample, DXCheckArea, DYCheckArea, maxSize=1000;
double closeValue;
float **secondPredict, **thirdPredict,  **smoothPredict;
bool **isPredicted, **isSecondPredicted, **isThirdPredicted;

DXSample=DSample.x;
DYSample=DSample.y;
DXCheckArea=DCheckArea.x;
DYCheckArea=DCheckArea.y;

//PredictTo=new float *[600];
//PredictFrom=new float *[600];
//PredictMix=new float *[600];
secondPredict=new float *[maxSize];
thirdPredict=new float *[maxSize];
isPredicted=new bool *[maxSize];
isSecondPredicted=new bool *[maxSize];
isThirdPredicted=new bool *[maxSize];
for(i=0;i<maxSize;i++){
 //PredictTo[i]=new float[600];
 //PredictFrom[i]=new float[600];
 //PredictMix[i]=new float[600];
 secondPredict[i]=new float[maxSize];
 thirdPredict[i]=new float[maxSize];
 isPredicted[i]=new bool[maxSize];
 isSecondPredicted[i]=new bool[maxSize];
 isThirdPredicted[i]=new bool[maxSize];
 for(j=0;j<maxSize;j++){
     PredictTo[i][j]=t0Frame[i][j];
     PredictFrom[i][j]=t0Frame[i][j];
     PredictMix[i][j]=t0Frame[i][j];
     secondPredict[i][j]=0;
     thirdPredict[i][j]=0;
     isPredicted[i][j]=false;
     isSecondPredicted[i][j]=false;
     isThirdPredicted[i][j]=false;
 }
}

//with  boundaries
   //for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
   //for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){

//without boundaries
   for(mapPoint.x=0;mapPoint.x<countCol;mapPoint.x++)
   for(mapPoint.y=0;mapPoint.y<countRow;mapPoint.y++){

			if(mapPoint.x<DXSample+DXCheckArea && mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=DYSample+DYCheckArea;			  
			}
			else if(mapPoint.x<DXSample+DXCheckArea && mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;				 	  
			}
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea) && mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=DYSample+DYCheckArea;	  
			}
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea) && mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;	  
			} 			
			else if(mapPoint.x<DXSample+DXCheckArea){
			 checkPoint.x=DXSample+DXCheckArea; checkPoint.y=mapPoint.y;				 
			}	
			else if(mapPoint.x>=countCol-(DXSample+DXCheckArea)){
			 checkPoint.x=countCol-(DXSample+DXCheckArea)-1; checkPoint.y=mapPoint.y;		 
			}
			else if(mapPoint.y<DYSample+DYCheckArea){
			 checkPoint.x=mapPoint.x; checkPoint.y=DYSample+DYCheckArea;				 
			}	
			else if(mapPoint.y>=countRow-(DYSample+DYCheckArea)){
			 checkPoint.x=mapPoint.x; checkPoint.y=countRow-(DYSample+DYCheckArea)-1;
			}
			else{
			 checkPoint.x=mapPoint.x; checkPoint.y=mapPoint.y;
      }			
       predictPoint.x=mapPoint.x+Dh*Movement[checkPoint.x][checkPoint.y].x;
       predictPoint.y=mapPoint.y+Dh*Movement[checkPoint.x][checkPoint.y].y;
       fromPoint.x=mapPoint.x-Dh*Movement[checkPoint.x][checkPoint.y].x;
       fromPoint.y=mapPoint.y-Dh*Movement[checkPoint.x][checkPoint.y].y;

			
      if(0<=predictPoint.x && predictPoint.x<maxSize)if(0<=predictPoint.y && predictPoint.y<maxSize)
      if(!isPredicted[predictPoint.x][predictPoint.y]){
        PredictTo[predictPoint.x][predictPoint.y]==0;
        PredictTo[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
  	secondPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isSecondPredicted[predictPoint.x][predictPoint.y]=true;
      }
      else if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
        thirdPredict[predictPoint.x][predictPoint.y]=t0Frame[mapPoint.x][mapPoint.y];
        isThirdPredicted[predictPoint.x][predictPoint.y]=true;
      }
			
      if(0<=fromPoint.x && fromPoint.x<maxSize)if(0<=fromPoint.y && fromPoint.y<maxSize) 
			PredictFrom[mapPoint.x][mapPoint.y]=t0Frame[fromPoint.x][fromPoint.y];
			PredictMix[mapPoint.x][mapPoint.y]=PredictFrom[mapPoint.x][mapPoint.y];
   }

   if(maxto){
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<maxSize-1)if(1<=predictPoint.y && predictPoint.y<maxSize-1)
                if(isSecondPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=secondPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isSecondPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isSecondPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=secondPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
        for(mapPoint.x=DXSample+DXCheckArea;mapPoint.x<countCol-(DXSample+DXCheckArea);mapPoint.x++)
        for(mapPoint.y=DYSample+DYCheckArea;mapPoint.y<countRow-(DYSample+DYCheckArea);mapPoint.y++){
                predictPoint.x=mapPoint.x+Dh*Movement[mapPoint.x][mapPoint.y].x;
                predictPoint.y=mapPoint.y+Dh*Movement[mapPoint.x][mapPoint.y].y;
                if(1<=predictPoint.x && predictPoint.x<maxSize-1)if(1<=predictPoint.y && predictPoint.y<maxSize-1)
                if(isThirdPredicted[predictPoint.x][predictPoint.y]){
                   closeValue=1;
                   for(i=-1;i<=1;i++)
                   for(j=-1;j<=1;j++){
                     if(i==0 && j==0){ continue;}
                     else{
                        if(!isPredicted[predictPoint.x+i][predictPoint.y+j])
                        if(pow(closeValue,2)>=pow(thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j],2)){
                             closePoint.x=predictPoint.x+i;
                             closePoint.y=predictPoint.y+j;
                             closeValue=thirdPredict[predictPoint.x][predictPoint.y]-t0Frame[mapPoint.x+i][mapPoint.y+j];
                             isThirdPredicted[predictPoint.x][predictPoint.y]=false;
                        }
                     }
                   }
                   if(!isThirdPredicted[predictPoint.x][predictPoint.y]){
                        PredictTo[closePoint.x][closePoint.y]=thirdPredict[predictPoint.x][predictPoint.y];
                        isPredicted[closePoint.x][closePoint.y]=true;
                   }
                }
        }
   }

   for(mapPoint.x=DXSample;mapPoint.x<countCol-DXSample;mapPoint.x++)
   for(mapPoint.y=DYSample;mapPoint.y<countRow-DYSample;mapPoint.y++){
         if(PredictTo[mapPoint.x][mapPoint.y]>0 && PredictMix[mapPoint.x][mapPoint.y]>0) PredictMix[mapPoint.x][mapPoint.y]=(PredictMix[mapPoint.x][mapPoint.y]+PredictTo[mapPoint.x][mapPoint.y])/2;
         if(PredictTo[mapPoint.x][mapPoint.y]>0 && PredictMix[mapPoint.x][mapPoint.y]==0) PredictMix[mapPoint.x][mapPoint.y]=PredictTo[mapPoint.x][mapPoint.y];
   } 

   if(smooth){
        smoothPredict= new float *[maxSize];
        for(i=0;i<maxSize;i++) smoothPredict[i]=new float[maxSize];

        for(i=1;i<maxSize-1;i++)
        for(j=1;j<maxSize-1;j++){
                                smoothPredict[i][j]=0;
                                for(k=-1;k<=1;k++) for(l=-1;l<=1;l++) smoothPredict[i][j]+=PredictMix[i+k][j+l];
                                smoothPredict[i][j]=smoothPredict[i][j]/9;

        }
        for(i=1;i<maxSize-1;i++)
        for(j=1;j<maxSize-1;j++){
                        PredictMix[i][j]=smoothPredict[i][j];
        }

        for(i=0;i<maxSize;i++) delete[] smoothPredict[i];
        delete[] smoothPredict;
   }


   for(i=0;i<maxSize;i++){ 
	//delete[] PredictTo[i];
	//delete[] PredictFrom[i];
	delete[] secondPredict[i];
	delete[] thirdPredict[i];
	delete[] isPredicted[i];
	delete[] isSecondPredicted[i];
	delete[] isThirdPredicted[i];
   }
   //delete[] PredictTo;
   //delete[] PredictFrom;
   delete[] secondPredict;
   delete[] thirdPredict;
   delete[] isPredicted;
   delete[] isSecondPredicted;
   delete[] isThirdPredicted;

   return PredictMix;

   //for(i=0;i<600;i++) delete[] PredictMix[i];
   //delete[] PredictMix;

}

