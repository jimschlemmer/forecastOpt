/* 
 * File:   carp.h
 * Author: root
 *
 * Created on May 15, 2006, 4:19 PM
 */

#ifndef _carp_H
#define	_carp_H


typedef enum { quiet, verbose, debug } carpType;


#endif	/* _carp_H */

