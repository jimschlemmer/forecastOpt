/* 
 * File:   gredDateTime.h
 * Author: root
 *
 * Created on September 17, 2006, 12:34 PM
 */

/* data structure to track time/date changes in grid headers */

#ifndef _gridDateTime_H
#define	_gridDateTime_H

#include "gridded.h"  // need def of satelliteType

// typedef
typedef struct {
    int year, month, day, hour, min, doy;
    time_t obs_time;
} dateTimeType;

// protos  
void initDateTime(dateTimeType *dt);
int newMonth(dateTimeType *prev, dateTimeType *curr);
int checkTimeSequence(dateTimeType *prev, dateTimeType *curr);
void updateDateTime(dateTimeType *prev, dateTimeType *curr);
int isDateTimeSet(dateTimeType *dt);
char *dtToString(dateTimeType *dt);
int diffMinutes(dateTimeType *dt1, dateTimeType *dt2);
int diffHours(dateTimeType *dt1, dateTimeType *dt2);
int incrementHour(dateTimeType *dt);
int incrementDay(dateTimeType *dt);
int incrementMonth(dateTimeType *dt);
int decrementHour(dateTimeType *dt);
int decrementDay(dateTimeType *dt);
int decrementMonth(dateTimeType *dt);
int getGridDateTime(gridDataType *grid, dateTimeType *dt, float time_adj);
void setObsTime(dateTimeType *dt);
void setToJan1(dateTimeType *dt, int year);
void setDateTime(dateTimeType *dt, int year, int month, int mday, int hour, int min);
char *dtToStringCsv(dateTimeType *dt);
int addHours(dateTimeType *dt, int hrs);
int dateTimeSanityCheck(dateTimeType *dt);
int loadDateFromFile(dateTimeType *dt, char *fileName);
int saveDateToFile(dateTimeType *dt, char *fileName);
int setDateTimeFromObs(dateTimeType *dt);
int decrementNumDays(dateTimeType *dt, int n);
int incrementMinutes(dateTimeType *dt, int minutes);
int parseArchDates(dateTimeType *dts, dateTimeType *dte, char *optarg);

#endif	/* _gredDateTime_H */

